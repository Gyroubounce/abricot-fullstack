(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "apiRequest",
    ()=>apiRequest
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const BASE_URL = ("TURBOPACK compile-time value", "http://localhost:8000");
async function apiRequest(endpoint, options = {}) {
    const { method = "GET", body } = options;
    try {
        const res = await fetch(`${BASE_URL}${endpoint}`, {
            method,
            headers: body ? {
                "Content-Type": "application/json"
            } : undefined,
            credentials: "include",
            body: body ? JSON.stringify(body) : undefined
        });
        const json = await res.json();
        if (!res.ok) {
            return {
                data: null,
                error: json.message || `Erreur ${res.status}`
            };
        }
        return {
            data: json.data,
            error: null
        };
    } catch  {
        return {
            data: null,
            error: "Erreur réseau. Vérifiez votre connexion."
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/api/projects.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addContributor",
    ()=>addContributor,
    "createProject",
    ()=>createProject,
    "deleteProject",
    ()=>deleteProject,
    "fetchProject",
    ()=>fetchProject,
    "fetchProjectTasks",
    ()=>fetchProjectTasks,
    "fetchProjects",
    ()=>fetchProjects,
    "removeContributor",
    ()=>removeContributor,
    "updateProject",
    ()=>updateProject
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
;
async function fetchProjects() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])("/projects");
}
async function fetchProject(projectId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}`);
}
async function createProject(name, description, contributors// ✅ Ajouter ce paramètre
) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])("/projects", {
        method: "POST",
        body: {
            name,
            description,
            contributors
        }
    });
}
async function updateProject(projectId, name, description) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}`, {
        method: "PUT",
        body: {
            name,
            description
        }
    });
}
async function deleteProject(projectId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}`, {
        method: "DELETE"
    });
}
async function addContributor(projectId, email) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/contributors`, {
        method: "POST",
        body: {
            email
        }
    });
}
async function removeContributor(projectId, userId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/contributors/${userId}`, {
        method: "DELETE"
    });
}
async function fetchProjectTasks(projectId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks`);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useProjects.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useProjects",
    ()=>useProjects
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/projects.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useAuth.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function useProjects() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "cb915cc7e0bd634ef620f1c3ffbf16b3d600a7aa69fadd7f0d5095773233e695") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb915cc7e0bd634ef620f1c3ffbf16b3d600a7aa69fadd7f0d5095773233e695";
    }
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [projects, setProjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "useProjects[fetchProjects]": async ()=>{
                setLoading(true);
                setError(null);
                const { data, error: err } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchProjects"])();
                if (err || !data) {
                    setError(err ?? "Erreur lors du chargement des projets");
                    setLoading(false);
                    return;
                }
                const projectsWithStats = await Promise.all(data.projects.map(_useProjectsFetchProjectsDataProjectsMap));
                setProjects(projectsWithStats);
                setLoading(false);
            }
        })["useProjects[fetchProjects]"];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const fetchProjects = t1;
    let t2;
    if ($[3] !== user?.id) {
        t2 = async function createProject(name, description, contributors) {
            if (!user?.id) {
                throw new Error("Utilisateur non authentifi\xE9");
            }
            const uniqueContributors = contributors ?? [];
            const { data: data_0, error: err_0 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProject"])(name, description, uniqueContributors);
            if (err_0 || !data_0) {
                throw new Error(err_0 ?? "Erreur lors de la cr\xE9ation");
            }
            return data_0.project.id;
        };
        $[3] = user?.id;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const createProject = t2;
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = async function addContributor(projectId, email) {
            const { error: err_1 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addContributor"])(projectId, email);
            if (err_1) {
                throw new Error(err_1);
            }
            await fetchProjects();
        };
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const addContributor = t3;
    let t4;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = async function deleteProject(projectId_0) {
            const { error: error_0 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteProject"])(projectId_0);
            if (error_0) {
                throw new Error(error_0);
            }
            setProjects({
                "useProjects[deleteProject > setProjects()]": (prev)=>prev.filter({
                        "useProjects[deleteProject > setProjects() > prev.filter()]": (p)=>p.id !== projectId_0
                    }["useProjects[deleteProject > setProjects() > prev.filter()]"])
            }["useProjects[deleteProject > setProjects()]"]);
        };
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const deleteProject = t4;
    let t5;
    if ($[7] !== createProject || $[8] !== error || $[9] !== loading || $[10] !== projects) {
        t5 = {
            projects,
            loading,
            error,
            fetchProjects,
            createProject,
            addContributor,
            deleteProject
        };
        $[7] = createProject;
        $[8] = error;
        $[9] = loading;
        $[10] = projects;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    return t5;
}
_s(useProjects, "UNqomK9kSRMxUJ5mQmMybh1HwFo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
async function _useProjectsFetchProjectsDataProjectsMap(project) {
    const { data: taskData } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchProjectTasks"])(project.id);
    const tasks = taskData?.tasks ?? [];
    const completedTasks = tasks.filter(_useProjectsFetchProjectsDataProjectsMapTasksFilter).length;
    const totalTasks = tasks.length;
    const progression = totalTasks > 0 ? Math.round(completedTasks / totalTasks * 100) : 0;
    return {
        ...project,
        tasks,
        completedTasks,
        totalTasks,
        progression
    };
}
function _useProjectsFetchProjectsDataProjectsMapTasksFilter(t) {
    return t.status === "DONE";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useApi.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useTask.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTask",
    ()=>useTask
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useApi.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function useTask() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "9359eef17f6d4965126c435117eba046603400698ec4366a4966781cc46cd579") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9359eef17f6d4965126c435117eba046603400698ec4366a4966781cc46cd579";
    }
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = async function createTaskAPI(projectId, data) {
            setLoading(true);
            setError(null);
            const { error: err } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks`, {
                method: "POST",
                body: data
            });
            if (err) {
                setError(err);
                setLoading(false);
                return null;
            }
            setLoading(false);
            return true;
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const createTaskAPI = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = async function updateTaskAPI(projectId_0, taskId, data_0) {
            setLoading(true);
            setError(null);
            const { error: err_0 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId_0}/tasks/${taskId}`, {
                method: "PUT",
                body: data_0
            });
            if (err_0) {
                setError(err_0);
                setLoading(false);
                return null;
            }
            setLoading(false);
            return true;
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const updateTaskAPI = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = async function deleteTaskAPI(projectId_1, taskId_0) {
            setLoading(true);
            setError(null);
            const { error: err_1 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId_1}/tasks/${taskId_0}`, {
                method: "DELETE"
            });
            if (err_1) {
                setError(err_1);
                setLoading(false);
                return null;
            }
            setLoading(false);
            return true;
        };
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const deleteTaskAPI = t2;
    let t3;
    if ($[4] !== error || $[5] !== loading) {
        t3 = {
            loading,
            error,
            createTaskAPI,
            updateTaskAPI,
            deleteTaskAPI
        };
        $[4] = error;
        $[5] = loading;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    return t3;
}
_s(useTask, "Iz3ozxQ+abMaAIcGIvU8cKUcBeo=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/sanitizeAssignees.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// /hooks/sanitizeAssignees.ts
__turbopack_context__.s([
    "sanitizeAssigneeIds",
    ()=>sanitizeAssigneeIds
]);
function sanitizeAssigneeIds(assigneeIds, members) {
    const memberIds = members.map((m)=>m.user.id);
    return assigneeIds.filter((id)=>memberIds.includes(id)) // owner exclu automatiquement
    .filter((id, index, self)=>self.indexOf(id) === index); // pas de doublons
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useProject.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useProject",
    ()=>useProject
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/projects.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useTask$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useTask.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$sanitizeAssignees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/sanitizeAssignees.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
// ---------------------------------------------------------
// 🔥 Nettoyage des assignees invalides (owner exclu)
// ---------------------------------------------------------
function sanitizeTaskAssignees(tasks, members) {
    const memberIds = members.map((m)=>m.user.id);
    return tasks.map((task)=>({
            ...task,
            assignees: task.assignees.filter((a)=>memberIds.includes(a.user.id))
        }));
}
function useProject(projectId) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(25);
    if ($[0] !== "d54d01e30a9639a0de352ee6cfe935e65c2af2c43cc7b87b7b38322e54c74b63") {
        for(let $i = 0; $i < 25; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d54d01e30a9639a0de352ee6cfe935e65c2af2c43cc7b87b7b38322e54c74b63";
    }
    const [project, setProject] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { createTaskAPI, updateTaskAPI, deleteTaskAPI } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useTask$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTask"])();
    let t0;
    if ($[1] !== projectId) {
        t0 = ({
            "useProject[fetchProject]": async ()=>{
                setLoading(true);
                setError(null);
                const { data: projectData, error: projectErr } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchProject"])(projectId);
                if (projectErr || !projectData) {
                    setError(projectErr ?? "Projet introuvable");
                    setLoading(false);
                    return;
                }
                const { data: taskData } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchProjectTasks"])(projectId);
                const safeMembers = projectData.project.members ?? [];
                const safeTasks = sanitizeTaskAssignees(taskData?.tasks ?? [], safeMembers);
                setProject({
                    ...projectData.project,
                    members: safeMembers,
                    tasks: safeTasks
                });
                setLoading(false);
            }
        })["useProject[fetchProject]"];
        $[1] = projectId;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const fetchProject = t0;
    let t1;
    if ($[3] !== createTaskAPI || $[4] !== fetchProject || $[5] !== project || $[6] !== projectId) {
        t1 = async function createTask(title, description, dueDate, assigneeIds, status, priority) {
            if (!project) {
                return;
            }
            const safeAssignees = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$sanitizeAssignees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sanitizeAssigneeIds"])(assigneeIds, project.members);
            const isoDate = dueDate && dueDate.trim() !== "" ? new Date(dueDate).toISOString() : null;
            await createTaskAPI(projectId, {
                title,
                description,
                dueDate: isoDate,
                assigneeIds: safeAssignees,
                status,
                priority
            });
            await fetchProject();
        };
        $[3] = createTaskAPI;
        $[4] = fetchProject;
        $[5] = project;
        $[6] = projectId;
        $[7] = t1;
    } else {
        t1 = $[7];
    }
    const createTask = t1;
    let t2;
    if ($[8] !== fetchProject || $[9] !== project || $[10] !== projectId || $[11] !== updateTaskAPI) {
        t2 = async function updateTask(taskId, data) {
            if (!project) {
                return;
            }
            const safeAssignees_0 = data.assigneeIds ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$sanitizeAssignees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sanitizeAssigneeIds"])(data.assigneeIds, project.members) : undefined;
            await updateTaskAPI(projectId, taskId, {
                ...data,
                ...safeAssignees_0 ? {
                    assigneeIds: safeAssignees_0
                } : {}
            });
            await fetchProject();
        };
        $[8] = fetchProject;
        $[9] = project;
        $[10] = projectId;
        $[11] = updateTaskAPI;
        $[12] = t2;
    } else {
        t2 = $[12];
    }
    const updateTask = t2;
    let t3;
    if ($[13] !== deleteTaskAPI || $[14] !== fetchProject || $[15] !== projectId) {
        t3 = async function deleteTask(taskId_0) {
            await deleteTaskAPI(projectId, taskId_0);
            await fetchProject();
        };
        $[13] = deleteTaskAPI;
        $[14] = fetchProject;
        $[15] = projectId;
        $[16] = t3;
    } else {
        t3 = $[16];
    }
    const deleteTask = t3;
    let t4;
    if ($[17] !== createTask || $[18] !== deleteTask || $[19] !== error || $[20] !== fetchProject || $[21] !== loading || $[22] !== project || $[23] !== updateTask) {
        t4 = {
            project,
            loading,
            error,
            fetchProject,
            updateProject: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateProject"],
            addContributor: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addContributor"],
            removeContributor: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeContributor"],
            createTask,
            updateTask,
            deleteTask
        };
        $[17] = createTask;
        $[18] = deleteTask;
        $[19] = error;
        $[20] = fetchProject;
        $[21] = loading;
        $[22] = project;
        $[23] = updateTask;
        $[24] = t4;
    } else {
        t4 = $[24];
    }
    return t4;
}
_s(useProject, "+m5/37aBJAgUlZS1GjvbQ9NvVws=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useTask$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTask"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useModal.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useModal",
    ()=>useModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useModal() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "dcb9475c53dcb8c3bf3fd696417f973ef49db524180eca58b087d6d6c7455971") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "dcb9475c53dcb8c3bf3fd696417f973ef49db524180eca58b087d6d6c7455971";
    }
    const [activeModal, setActiveModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = function openModal(name) {
            setActiveModal(name);
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const openModal = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = function closeModal() {
            setActiveModal(null);
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const closeModal = t1;
    let t2;
    if ($[3] !== activeModal) {
        t2 = function isOpen(name_0) {
            return activeModal === name_0;
        };
        $[3] = activeModal;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const isOpen = t2;
    let t3;
    if ($[5] !== activeModal || $[6] !== isOpen) {
        t3 = {
            activeModal,
            openModal,
            closeModal,
            isOpen
        };
        $[5] = activeModal;
        $[6] = isOpen;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    return t3;
}
_s(useModal, "kAcpyZCE6YA2McoeUdamFLX5os8=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/Button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
// src/components/ui/Button.tsx
"use client";
;
;
const variants = {
    "voir": "text-xs bg-btn-black w-30.25 h-12.5 text-text-white hover:text-brand-dark hover:bg-bg-content hover:border border-brand-dark focus:ring-2 focus:ring-brand-dark rounded-md transition",
    "creer-projet": "px-4 py-2 w-45.25 h-12.5 rounded-md bg-btn-2-Black text-white text-[16px] hover:text-brand-dark hover:bg-bg-content hover:border border-brand-dark transition",
    "creer-tache": "w-35.25 h-12.5 bg-btn-black text-text-white text-sm rounded-[10px] hover:text-brand-dark hover:bg-bg-content border border-brand-dark transition"
};
function Button(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "81e098c372daa21abd5d28d6af1f1c4f4ce27ca90c6a7e764e71161e1d253c47") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "81e098c372daa21abd5d28d6af1f1c4f4ce27ca90c6a7e764e71161e1d253c47";
    }
    const { variant: t1, children, onClick, type: t2, disabled, className: t3, ariaLabel } = t0;
    const variant = t1 === undefined ? "voir" : t1;
    const type = t2 === undefined ? "button" : t2;
    const className = t3 === undefined ? "" : t3;
    const t4 = `${variants[variant]} disabled:opacity-50 ${className}`;
    let t5;
    if ($[1] !== ariaLabel || $[2] !== children || $[3] !== disabled || $[4] !== onClick || $[5] !== t4 || $[6] !== type) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: type,
            onClick: onClick,
            disabled: disabled,
            "aria-label": ariaLabel,
            className: t4,
            children: children
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/Button.tsx",
            lineNumber: 43,
            columnNumber: 10
        }, this);
        $[1] = ariaLabel;
        $[2] = children;
        $[3] = disabled;
        $[4] = onClick;
        $[5] = t4;
        $[6] = type;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    return t5;
}
_c = Button;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/icons/IAIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>IAIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
function IAIcon(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "51db36b1097a54992ca407f97bd6567214c17298be0cfbbda353f07bbddb01c4") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "51db36b1097a54992ca407f97bd6567214c17298be0cfbbda353f07bbddb01c4";
    }
    const { className } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M8.24333 0.574802C8.60336 -0.19163 9.69352 -0.19163 10.0535 0.574802L12.351 5.46554C12.4501 5.67658 12.6199 5.84634 12.8309 5.94548L17.7216 8.2429C18.4881 8.60293 18.4881 9.69309 17.7216 10.0531L12.8309 12.3505C12.6199 12.4497 12.4501 12.6194 12.351 12.8305L10.0535 17.7212C9.69352 18.4876 8.60336 18.4876 8.24333 17.7212L5.9459 12.8305C5.84677 12.6194 5.677 12.4497 5.46597 12.3505L0.575229 10.0531C-0.191203 9.69309 -0.191203 8.60293 0.575229 8.2429L5.46597 5.94547C5.677 5.84634 5.84677 5.67658 5.9459 5.46554L8.24333 0.574802Z"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/IAIcon.tsx",
            lineNumber: 16,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== className) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: className,
            width: "19",
            height: "19",
            viewBox: "0 0 19 19",
            fill: "currentColor",
            xmlns: "http://www.w3.org/2000/svg",
            children: t1
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/IAIcon.tsx",
            lineNumber: 23,
            columnNumber: 10
        }, this);
        $[2] = className;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_c = IAIcon;
var _c;
__turbopack_context__.k.register(_c, "IAIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/project/ProjectHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowLeftIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeftIcon$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/@heroicons/react/24/outline/esm/ArrowLeftIcon.js [app-client] (ecmascript) <export default as ArrowLeftIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$IAIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/IAIcon.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
function ProjectHeader(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(67);
    if ($[0] !== "3842f29acc8bc58af9d07f83d54476e6e1d7c608eb87282549e9650fbf5f82b5") {
        for(let $i = 0; $i < 67; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "3842f29acc8bc58af9d07f83d54476e6e1d7c608eb87282549e9650fbf5f82b5";
    }
    const { project, isOwner, onBack, onEditProject, onCreateTask, onCreateAITask } = t0;
    const owner = project.owner;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[1] !== isOwner || $[2] !== onBack || $[3] !== onCreateAITask || $[4] !== onCreateTask || $[5] !== onEditProject || $[6] !== owner || $[7] !== project.description || $[8] !== project.members || $[9] !== project.name) {
        const contributors = project.members.map(_ProjectHeaderProjectMembersMap);
        t8 = "flex flex-col gap-6";
        let t10;
        if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowLeftIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeftIcon$3e$__["ArrowLeftIcon"], {
                className: "h-4 w-4 text-btn-black hover:text-brand-dark"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 48,
                columnNumber: 13
            }, this);
            $[19] = t10;
        } else {
            t10 = $[19];
        }
        let t11;
        if ($[20] !== onBack) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: onBack,
                className: "w-14 h-14 flex items-center justify-center border border-system-neutral rounded-md bg-bg-content hover:border-brand-dark transition",
                "aria-label": "Retour aux projets",
                children: t10
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 55,
                columnNumber: 13
            }, this);
            $[20] = onBack;
            $[21] = t11;
        } else {
            t11 = $[21];
        }
        let t12;
        if ($[22] !== project.name) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "font-semibold text-[24px] text-text-primary",
                children: project.name
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 63,
                columnNumber: 13
            }, this);
            $[22] = project.name;
            $[23] = t12;
        } else {
            t12 = $[23];
        }
        let t13;
        if ($[24] !== isOwner || $[25] !== onEditProject) {
            t13 = isOwner && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: onEditProject,
                className: "text-sm text-brand-dark underline hover:text-btn-black transition",
                children: "modifier"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 71,
                columnNumber: 24
            }, this);
            $[24] = isOwner;
            $[25] = onEditProject;
            $[26] = t13;
        } else {
            t13 = $[26];
        }
        let t14;
        if ($[27] !== t12 || $[28] !== t13) {
            t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    t12,
                    t13
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 80,
                columnNumber: 13
            }, this);
            $[27] = t12;
            $[28] = t13;
            $[29] = t14;
        } else {
            t14 = $[29];
        }
        let t15;
        if ($[30] !== project.description) {
            t15 = project.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-[18px] text-text-secondary",
                children: project.description
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 89,
                columnNumber: 36
            }, this);
            $[30] = project.description;
            $[31] = t15;
        } else {
            t15 = $[31];
        }
        let t16;
        if ($[32] !== t14 || $[33] !== t15) {
            t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-0.5",
                children: [
                    t14,
                    t15
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 97,
                columnNumber: 13
            }, this);
            $[32] = t14;
            $[33] = t15;
            $[34] = t16;
        } else {
            t16 = $[34];
        }
        let t17;
        if ($[35] !== t11 || $[36] !== t16) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    t11,
                    t16
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 106,
                columnNumber: 13
            }, this);
            $[35] = t11;
            $[36] = t16;
            $[37] = t17;
        } else {
            t17 = $[37];
        }
        let t18;
        if ($[38] !== onCreateTask) {
            t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "creer-tache",
                onClick: onCreateTask,
                ariaLabel: "Cr\xE9er une nouvelle t\xE2che",
                children: "Créer une tâche"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 115,
                columnNumber: 13
            }, this);
            $[38] = onCreateTask;
            $[39] = t18;
        } else {
            t18 = $[39];
        }
        let t19;
        if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
            t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$IAIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "w-4 h-4 shrink-0",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 123,
                columnNumber: 13
            }, this);
            $[40] = t19;
        } else {
            t19 = $[40];
        }
        let t20;
        if ($[41] !== onCreateAITask) {
            t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: onCreateAITask,
                className: "flex items-center justify-center gap-1 w-23.5 h-12.5 bg-brand-dark text-text-white text-sm rounded-[10px] hover:bg-bg-content hover:text-brand-dark border border-brand-dark transition",
                "aria-label": "G\xE9n\xE9rer des t\xE2ches avec l'IA",
                children: [
                    t19,
                    "IA"
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 130,
                columnNumber: 13
            }, this);
            $[41] = onCreateAITask;
            $[42] = t20;
        } else {
            t20 = $[42];
        }
        let t21;
        if ($[43] !== t18 || $[44] !== t20) {
            t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2 shrink-0",
                children: [
                    t18,
                    t20
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 138,
                columnNumber: 13
            }, this);
            $[43] = t18;
            $[44] = t20;
            $[45] = t21;
        } else {
            t21 = $[45];
        }
        if ($[46] !== t17 || $[47] !== t21) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-start justify-between gap-4",
                children: [
                    t17,
                    t21
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                lineNumber: 146,
                columnNumber: 12
            }, this);
            $[46] = t17;
            $[47] = t21;
            $[48] = t9;
        } else {
            t9 = $[48];
        }
        t6 = "bg-bg-grey-light rounded-[10px] px-8 py-3";
        t7 = "contributors-title";
        t4 = "flex items-center justify-between gap-4";
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            id: "contributors-title",
            className: "font-semibold text-text-primary text-lg",
            children: [
                "Contributeurs",
                " ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-base text-text-secondary ml-1",
                    children: [
                        contributors.length,
                        " personnes"
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                    lineNumber: 156,
                    columnNumber: 108
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
            lineNumber: 156,
            columnNumber: 10
        }, this);
        t1 = "flex flex-row flex-wrap gap-3";
        t2 = "Liste des contributeurs";
        let t22;
        if ($[49] !== owner) {
            t22 = ({
                "ProjectHeader[contributors.map()]": (user)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `w-6.75 h-6.75 rounded-full flex items-center justify-center shrink-0 ${user.id === owner.id ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `text-[10px] ${user.id === owner.id ? "text-text-primary" : "text-text-secondary"}`,
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(user.name)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                                    lineNumber: 162,
                                    columnNumber: 261
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                                lineNumber: 162,
                                columnNumber: 108
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `text-sm px-2 py-0.5 rounded-full ${user.id === owner.id ? "bg-brand-light text-brand-dark" : "bg-bg-grey-border text-text-secondary"}`,
                                children: user.id === owner.id ? "Propri\xE9taire" : user.name
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                                lineNumber: 162,
                                columnNumber: 400
                            }, this)
                        ]
                    }, user.id, true, {
                        fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
                        lineNumber: 162,
                        columnNumber: 54
                    }, this)
            })["ProjectHeader[contributors.map()]"];
            $[49] = owner;
            $[50] = t22;
        } else {
            t22 = $[50];
        }
        t3 = contributors.map(t22);
        $[1] = isOwner;
        $[2] = onBack;
        $[3] = onCreateAITask;
        $[4] = onCreateTask;
        $[5] = onEditProject;
        $[6] = owner;
        $[7] = project.description;
        $[8] = project.members;
        $[9] = project.name;
        $[10] = t1;
        $[11] = t2;
        $[12] = t3;
        $[13] = t4;
        $[14] = t5;
        $[15] = t6;
        $[16] = t7;
        $[17] = t8;
        $[18] = t9;
    } else {
        t1 = $[10];
        t2 = $[11];
        t3 = $[12];
        t4 = $[13];
        t5 = $[14];
        t6 = $[15];
        t7 = $[16];
        t8 = $[17];
        t9 = $[18];
    }
    let t10;
    if ($[51] !== t1 || $[52] !== t2 || $[53] !== t3) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
            className: t1,
            "aria-label": t2,
            children: t3
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
            lineNumber: 201,
            columnNumber: 11
        }, this);
        $[51] = t1;
        $[52] = t2;
        $[53] = t3;
        $[54] = t10;
    } else {
        t10 = $[54];
    }
    let t11;
    if ($[55] !== t10 || $[56] !== t4 || $[57] !== t5) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t4,
            children: [
                t5,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
            lineNumber: 211,
            columnNumber: 11
        }, this);
        $[55] = t10;
        $[56] = t4;
        $[57] = t5;
        $[58] = t11;
    } else {
        t11 = $[58];
    }
    let t12;
    if ($[59] !== t11 || $[60] !== t6 || $[61] !== t7) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: t6,
            "aria-labelledby": t7,
            children: t11
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
            lineNumber: 221,
            columnNumber: 11
        }, this);
        $[59] = t11;
        $[60] = t6;
        $[61] = t7;
        $[62] = t12;
    } else {
        t12 = $[62];
    }
    let t13;
    if ($[63] !== t12 || $[64] !== t8 || $[65] !== t9) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t8,
            children: [
                t9,
                t12
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/project/ProjectHeader.tsx",
            lineNumber: 231,
            columnNumber: 11
        }, this);
        $[63] = t12;
        $[64] = t8;
        $[65] = t9;
        $[66] = t13;
    } else {
        t13 = $[66];
    }
    return t13;
}
_c = ProjectHeader;
function _ProjectHeaderProjectMembersMap(m) {
    return m.user;
}
var _c;
__turbopack_context__.k.register(_c, "ProjectHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/icons/ListIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ListIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
function ListIcon(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "f4f683f06a3b04e24be17b5104ca07f1471f2aef62a712b6bac31953c9a3b325") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f4f683f06a3b04e24be17b5104ca07f1471f2aef62a712b6bac31953c9a3b325";
    }
    const { className } = t0;
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M15.1111 7.82222C14.5778 7.82222 14.2222 8.17778 14.2222 8.71111V13.6889C14.2222 13.9556 13.9556 14.2222 13.6889 14.2222H2.31111C2.04444 14.2222 1.77778 13.9556 1.77778 13.6889V2.31111C1.77778 2.04444 2.04444 1.77778 2.31111 1.77778H10.8444C11.3778 1.77778 11.7333 1.42222 11.7333 0.888889C11.7333 0.355556 11.3778 0 10.8444 0H2.31111C1.06667 0 0 1.06667 0 2.31111V13.6889C0 14.9333 1.06667 16 2.31111 16H13.6889C14.9333 16 16 14.9333 16 13.6889V8.71111C16 8.26667 15.6444 7.82222 15.1111 7.82222Z"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/ListIcon.tsx",
            lineNumber: 17,
            columnNumber: 10
        }, this);
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M6.84435 7.11113C6.48879 6.75558 5.95546 6.84447 5.5999 7.20002C5.33324 7.46669 5.33324 8.00002 5.5999 8.35558L7.55546 10.4C7.73324 10.5778 7.91101 10.6667 8.17768 10.6667C8.44435 10.6667 8.62212 10.5778 8.7999 10.4L14.8443 4.1778C15.1999 3.82224 15.1999 3.28891 14.8443 2.93335C14.4888 2.5778 13.9555 2.5778 13.5999 2.93335L8.17768 8.53335L6.84435 7.11113Z"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/ListIcon.tsx",
            lineNumber: 18,
            columnNumber: 10
        }, this);
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    let t3;
    if ($[3] !== className) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: className,
            width: "16",
            height: "16",
            viewBox: "0 0 16 16",
            fill: "currentColor",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                t1,
                t2
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/icons/ListIcon.tsx",
            lineNumber: 27,
            columnNumber: 10
        }, this);
        $[3] = className;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    return t3;
}
_c = ListIcon;
var _c;
__turbopack_context__.k.register(_c, "ListIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/icons/CalenderIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CalenderIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
function CalenderIcon(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "893590dfb6ab043c9899da5fa5e55fadd712478904f4f80e859841e187049f45") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "893590dfb6ab043c9899da5fa5e55fadd712478904f4f80e859841e187049f45";
    }
    const { className } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M4.42285 0C4.10746 0 3.8457 0.261761 3.8457 0.577148V1.17871C1.39505 1.38897 0 2.96789 0 5.57715V12.1152C0 14.9229 1.61522 16.538 4.42285 16.5381H10.5771C13.3847 16.538 15 14.9229 15 12.1152V5.57715C15 2.96794 13.6049 1.38901 11.1543 1.17871V0.577148C11.1543 0.261782 10.8925 3.47543e-05 10.5771 0C10.2618 0 10 0.261761 10 0.577148V1.15332H5V0.577148C5 0.261793 4.7382 5.25452e-05 4.42285 0ZM13.8457 12.1152C13.8457 14.3152 12.777 15.3847 10.5771 15.3848H4.42285C2.22293 15.3847 1.15332 14.3152 1.15332 12.1152V6.60742H13.8457V12.1152ZM10.4844 11.4082C10.1998 11.2852 9.86186 11.3541 9.64648 11.5693C9.61572 11.6078 9.57679 11.6461 9.55371 11.6846C9.52294 11.7307 9.49976 11.7771 9.48438 11.8232C9.46134 11.8693 9.44616 11.9159 9.43848 11.9697C9.43082 12.0157 9.42288 12.0693 9.42285 12.1152C9.42285 12.3152 9.50802 12.516 9.64648 12.6621C9.7926 12.8003 9.99256 12.8848 10.1924 12.8848C10.2923 12.8848 10.3922 12.8616 10.4844 12.8232C10.5765 12.7848 10.6615 12.7312 10.7383 12.6621C10.8075 12.5852 10.8619 12.5081 10.9004 12.4082C10.9389 12.3159 10.9619 12.2152 10.9619 12.1152C10.9618 11.9153 10.8767 11.7154 10.7383 11.5693C10.6614 11.5001 10.5766 11.4466 10.4844 11.4082ZM10.0381 8.66895C9.99208 8.67665 9.94639 8.69283 9.90039 8.71582C9.85434 8.73117 9.80777 8.75352 9.76172 8.78418C9.72332 8.8149 9.68489 8.84623 9.64648 8.87695C9.61572 8.9154 9.57679 8.95374 9.55371 8.99219C9.52294 9.03834 9.49976 9.08471 9.48438 9.13086C9.46134 9.17696 9.44616 9.22343 9.43848 9.26953C9.43081 9.32318 9.42288 9.3692 9.42285 9.42285C9.42285 9.62285 9.50802 9.82357 9.64648 9.96973C9.7926 10.108 9.99256 10.1924 10.1924 10.1924C10.2923 10.1924 10.3922 10.1693 10.4844 10.1309C10.5765 10.0925 10.6614 10.0388 10.7383 9.96973C10.8075 9.89286 10.8619 9.80804 10.9004 9.71582C10.9389 9.62351 10.9619 9.52285 10.9619 9.42285C10.9618 9.22293 10.8767 9.02305 10.7383 8.87695C10.6614 8.80777 10.5766 8.75426 10.4844 8.71582C10.3459 8.65431 10.1919 8.63818 10.0381 8.66895ZM8.0459 8.87695C7.83052 8.66172 7.48485 8.59282 7.20801 8.71582C7.10806 8.75426 7.03098 8.80778 6.9541 8.87695C6.8157 9.02304 6.73055 9.22294 6.73047 9.42285C6.73047 9.4767 6.7384 9.5233 6.74609 9.57715C6.75379 9.62325 6.76894 9.66972 6.79199 9.71582C6.80733 9.76177 6.83074 9.80757 6.86133 9.85352C6.8921 9.89198 6.92333 9.93126 6.9541 9.96973C7.03091 10.0388 7.10815 10.0925 7.20801 10.1309C7.30023 10.1693 7.4001 10.1924 7.5 10.1924C7.69983 10.1924 7.89978 10.108 8.0459 9.96973C8.07667 9.93126 8.1079 9.89198 8.13867 9.85352C8.16927 9.80756 8.19266 9.76177 8.20801 9.71582C8.23106 9.66972 8.2462 9.62325 8.25391 9.57715C8.2616 9.5233 8.26953 9.4767 8.26953 9.42285C8.26949 9.32299 8.2464 9.22305 8.20801 9.13086C8.16955 9.03855 8.11513 8.95388 8.0459 8.87695ZM10 2.88477C10.0001 3.20009 10.2618 3.46191 10.5771 3.46191C10.8925 3.46188 11.1542 3.20007 11.1543 2.88477V2.33789C12.9266 2.51306 13.806 3.53533 13.8418 5.4541H1.15723C1.193 3.53528 2.07336 2.51303 3.8457 2.33789V2.88477C3.84578 3.20009 4.10751 3.46191 4.42285 3.46191C4.73815 3.46186 4.99992 3.20006 5 2.88477V2.30762H10V2.88477Z"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/CalenderIcon.tsx",
            lineNumber: 16,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== className) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: className,
            width: "15",
            height: "17",
            viewBox: "0 0 15 17",
            fill: "currentColor",
            xmlns: "http://www.w3.org/2000/svg",
            children: t1
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/CalenderIcon.tsx",
            lineNumber: 23,
            columnNumber: 10
        }, this);
        $[2] = className;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_c = CalenderIcon;
var _c;
__turbopack_context__.k.register(_c, "CalenderIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/project/ProjectFilters.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectFilters
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/@heroicons/react/24/outline/esm/MagnifyingGlassIcon.js [app-client] (ecmascript) <export default as MagnifyingGlassIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$ListIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/ListIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CalenderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/CalenderIcon.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
function ProjectFilters(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(47);
    if ($[0] !== "cdd1e93fa34230fa68770fe9b34dc764e305a537a28c5a2b431de0432ad50f70") {
        for(let $i = 0; $i < 47; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cdd1e93fa34230fa68770fe9b34dc764e305a537a28c5a2b431de0432ad50f70";
    }
    const { view, setView, filterStatus, setFilterStatus, search, setSearch } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            id: "tasks-title",
            className: "font-semibold text-text-primary text-lg",
            children: "Tâches"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 35,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const t2 = view === "list" ? "Par ordre de priorit\xE9" : "Par ordre d'\xE9ch\xE9ance";
    let t3;
    if ($[2] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-base text-text-secondary",
            children: t2
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 43,
            columnNumber: 10
        }, this);
        $[2] = t2;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    let t4;
    if ($[4] !== setView) {
        t4 = ({
            "ProjectFilters[<button>.onClick]": ()=>setView("list")
        })["ProjectFilters[<button>.onClick]"];
        $[4] = setView;
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const t5 = `px-4 py-2 w-23.5 h-11.25 rounded-md flex items-center gap-3 text-sm transition ${view === "list" ? "bg-brand-light text-brand-dark" : "bg-white text-brand-dark hover:bg-brand-light"}`;
    let t6;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$ListIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: "w-4 h-4",
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 62,
            columnNumber: 10
        }, this);
        $[6] = t6;
    } else {
        t6 = $[6];
    }
    let t7;
    if ($[7] !== t4 || $[8] !== t5) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: t4,
            className: t5,
            children: [
                t6,
                "Liste"
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 69,
            columnNumber: 10
        }, this);
        $[7] = t4;
        $[8] = t5;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] !== setView) {
        t8 = ({
            "ProjectFilters[<button>.onClick]": ()=>setView("calendar")
        })["ProjectFilters[<button>.onClick]"];
        $[10] = setView;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    const t9 = `px-3 py-2 rounded-md flex items-center gap-3 text-sm transition ${view === "calendar" ? "bg-brand-light text-brand-dark" : "bg-white text-brand-dark hover:bg-brand-light"}`;
    let t10;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CalenderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: "w-5 h-5 shrink-0",
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 89,
            columnNumber: 11
        }, this);
        $[12] = t10;
    } else {
        t10 = $[12];
    }
    let t11;
    if ($[13] !== t8 || $[14] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: t8,
            className: t9,
            children: [
                t10,
                "Calendrier"
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 96,
            columnNumber: 11
        }, this);
        $[13] = t8;
        $[14] = t9;
        $[15] = t11;
    } else {
        t11 = $[15];
    }
    let t12;
    if ($[16] !== t11 || $[17] !== t7) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-3",
            role: "group",
            "aria-label": "Mode d'affichage",
            children: [
                t7,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 105,
            columnNumber: 11
        }, this);
        $[16] = t11;
        $[17] = t7;
        $[18] = t12;
    } else {
        t12 = $[18];
    }
    let t13;
    if ($[19] !== setFilterStatus) {
        t13 = ({
            "ProjectFilters[<select>.onChange]": (e)=>setFilterStatus(e.target.value)
        })["ProjectFilters[<select>.onChange]"];
        $[19] = setFilterStatus;
        $[20] = t13;
    } else {
        t13 = $[20];
    }
    let t14;
    let t15;
    let t16;
    let t17;
    let t18;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "ALL",
            children: "Statut"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 128,
            columnNumber: 11
        }, this);
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "TODO",
            children: "À faire"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 129,
            columnNumber: 11
        }, this);
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "IN_PROGRESS",
            children: "En cours"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 130,
            columnNumber: 11
        }, this);
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "DONE",
            children: "Terminée"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 131,
            columnNumber: 11
        }, this);
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "CANCELLED",
            children: "Annulée"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 132,
            columnNumber: 11
        }, this);
        $[21] = t14;
        $[22] = t15;
        $[23] = t16;
        $[24] = t17;
        $[25] = t18;
    } else {
        t14 = $[21];
        t15 = $[22];
        t16 = $[23];
        t17 = $[24];
        t18 = $[25];
    }
    let t19;
    if ($[26] !== filterStatus || $[27] !== t13) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
            value: filterStatus,
            onChange: t13,
            className: "w-38 h-15.75 text-sm border border-system-neutral rounded-md bg-bg-content text-text-secondary transition pr-8 text-center appearance-none cursor-pointer",
            "aria-label": "Filtrer par statut",
            children: [
                t14,
                t15,
                t16,
                t17,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 147,
            columnNumber: 11
        }, this);
        $[26] = filterStatus;
        $[27] = t13;
        $[28] = t19;
    } else {
        t19 = $[28];
    }
    let t20;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: "absolute right-5 top-1/2 -translate-y-1/2 h-7 w-7 text-text-secondary pointer-events-none",
            viewBox: "0 0 20 20",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: 0.8,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M5 8l5 5 5-5"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
                lineNumber: 156,
                columnNumber: 190
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 156,
            columnNumber: 11
        }, this);
        $[29] = t20;
    } else {
        t20 = $[29];
    }
    let t21;
    if ($[30] !== t19) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative",
            children: [
                t19,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 163,
            columnNumber: 11
        }, this);
        $[30] = t19;
        $[31] = t21;
    } else {
        t21 = $[31];
    }
    let t22;
    if ($[32] !== setSearch) {
        t22 = ({
            "ProjectFilters[<input>.onChange]": (e_0)=>setSearch(e_0.target.value)
        })["ProjectFilters[<input>.onChange]"];
        $[32] = setSearch;
        $[33] = t22;
    } else {
        t22 = $[33];
    }
    let t23;
    if ($[34] !== search || $[35] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "search",
            value: search,
            onChange: t22,
            placeholder: "Rechercher une t\xE2che",
            className: "w-70.75 h-15.75 pl-6 pr-8 py-1.5 text-xs border border-system-neutral rounded-md bg-bg-content text-text-primary transition",
            "aria-label": "Rechercher une t\xE2che"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 181,
            columnNumber: 11
        }, this);
        $[34] = search;
        $[35] = t22;
        $[36] = t23;
    } else {
        t23 = $[36];
    }
    let t24;
    if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__["MagnifyingGlassIcon"], {
            className: "absolute right-8 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-text-secondary pointer-events-none",
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 190,
            columnNumber: 11
        }, this);
        $[37] = t24;
    } else {
        t24 = $[37];
    }
    let t25;
    if ($[38] !== t23) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative",
            children: [
                t23,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 197,
            columnNumber: 11
        }, this);
        $[38] = t23;
        $[39] = t25;
    } else {
        t25 = $[39];
    }
    let t26;
    if ($[40] !== t12 || $[41] !== t21 || $[42] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-2 flex-wrap",
            children: [
                t12,
                t21,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 205,
            columnNumber: 11
        }, this);
        $[40] = t12;
        $[41] = t21;
        $[42] = t25;
        $[43] = t26;
    } else {
        t26 = $[43];
    }
    let t27;
    if ($[44] !== t26 || $[45] !== t3) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "bg-bg-content rounded-[10px] shadow-card px-6 py-5 flex flex-col gap-4",
            "aria-labelledby": "tasks-title",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col",
                children: [
                    t1,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between flex-wrap gap-3",
                        children: [
                            t3,
                            t26
                        ]
                    }, void 0, true, {
                        fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
                        lineNumber: 215,
                        columnNumber: 168
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
                lineNumber: 215,
                columnNumber: 133
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectFilters.tsx",
            lineNumber: 215,
            columnNumber: 11
        }, this);
        $[44] = t26;
        $[45] = t3;
        $[46] = t27;
    } else {
        t27 = $[46];
    }
    return t27;
}
_c = ProjectFilters;
var _c;
__turbopack_context__.k.register(_c, "ProjectFilters");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/utils/format.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatDate",
    ()=>formatDate,
    "formatDateInput",
    ()=>formatDateInput,
    "formatDateTime",
    ()=>formatDateTime
]);
function formatDate(dateStr) {
    if (!dateStr) return "";
    return new Date(dateStr).toLocaleDateString("fr-FR", {
        day: "numeric",
        month: "long"
    });
}
function formatDateTime(dateStr) {
    if (!dateStr) return "";
    return new Date(dateStr).toLocaleDateString("fr-FR", {
        day: "numeric",
        month: "long",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
    });
}
function formatDateInput(dateStr) {
    if (!dateStr) return "";
    return dateStr.split("T")[0];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/utils/task.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "priorityLabel",
    ()=>priorityLabel,
    "priorityOrder",
    ()=>priorityOrder,
    "statusColor",
    ()=>statusColor,
    "statusLabel",
    ()=>statusLabel
]);
const statusLabel = {
    TODO: "À faire",
    IN_PROGRESS: "En cours",
    DONE: "Terminée",
    CANCELLED: "Annulée"
};
const statusColor = {
    TODO: "bg-system-error text-text-error",
    IN_PROGRESS: "bg-brand-light text-brand-dark",
    DONE: "bg-system-success text-text-success",
    CANCELLED: "bg-system-neutral text-text-secondary"
};
const priorityLabel = {
    LOW: "Basse",
    MEDIUM: "Moyenne",
    HIGH: "Haute",
    URGENT: "Urgente"
};
const priorityOrder = {
    URGENT: 0,
    HIGH: 1,
    MEDIUM: 2,
    LOW: 3
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/api/tasks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createComment",
    ()=>createComment,
    "createTask",
    ()=>createTask,
    "deleteTask",
    ()=>deleteTask,
    "updateTask",
    ()=>updateTask
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
;
async function createTask(projectId, title, description, dueDate, assigneeIds, status, priority) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks`, {
        method: "POST",
        body: {
            title,
            description,
            priority,
            dueDate: dueDate || null,
            assigneeIds
        }
    });
}
async function updateTask(projectId, taskId, data) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks/${taskId}`, {
        method: "PATCH",
        body: {
            ...data,
            dueDate: data.dueDate || null
        }
    });
}
async function deleteTask(projectId, taskId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks/${taskId}`, {
        method: "DELETE"
    });
}
async function createComment(projectId, taskId, content) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks/${taskId}/comments`, {
        method: "POST",
        body: {
            content
        }
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/forms/CommentForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommentForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useAuth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$tasks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/tasks.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function CommentForm(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(27);
    if ($[0] !== "440470cab235e20878a0de98ebafe8d5dad27ac21f3429b2de6d58c215d97e45") {
        for(let $i = 0; $i < 27; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "440470cab235e20878a0de98ebafe8d5dad27ac21f3429b2de6d58c215d97e45";
    }
    const { projectId, taskId, onRefresh } = t0;
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    if ($[1] !== content || $[2] !== onRefresh || $[3] !== projectId || $[4] !== taskId || $[5] !== user) {
        t1 = async function handleSubmit(e) {
            e.preventDefault();
            if (!content.trim() || !user) {
                return;
            }
            setSubmitting(true);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$tasks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createComment"])(projectId, taskId, content.trim());
            setContent("");
            setSubmitting(false);
            onRefresh();
        };
        $[1] = content;
        $[2] = onRefresh;
        $[3] = projectId;
        $[4] = taskId;
        $[5] = user;
        $[6] = t1;
    } else {
        t1 = $[6];
    }
    const handleSubmit = t1;
    const t2 = user?.name ?? "";
    let t3;
    if ($[7] !== t2) {
        t3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(t2);
        $[7] = t2;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-6 h-6 rounded-full bg-brand-light flex items-center justify-center shrink-0",
            "aria-hidden": "true",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[10px] font-semibold text-text-primary",
                children: t3
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/forms/CommentForm.tsx",
                lineNumber: 65,
                columnNumber: 124
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/CommentForm.tsx",
            lineNumber: 65,
            columnNumber: 10
        }, this);
        $[9] = t3;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "CommentForm[<input>.onChange]": (e_0)=>setContent(e_0.target.value)
        })["CommentForm[<input>.onChange]"];
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    let t6;
    if ($[12] !== content) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "text",
            value: content,
            onChange: t5,
            placeholder: "Ajouter un commentaire...",
            className: "flex-1 h-20.75 text-[10px] text-police-black border border-system-neutral rounded-[8px] px-3 py-2 bg-bg-dashboard transition placeholder:text-[10px] placeholder:text-text-secondary",
            "aria-label": "Nouveau commentaire"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/CommentForm.tsx",
            lineNumber: 82,
            columnNumber: 10
        }, this);
        $[12] = content;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    let t7;
    if ($[14] !== t4 || $[15] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-2",
            children: [
                t4,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/CommentForm.tsx",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[14] = t4;
        $[15] = t6;
        $[16] = t7;
    } else {
        t7 = $[16];
    }
    let t8;
    if ($[17] !== content || $[18] !== submitting) {
        t8 = submitting || !content.trim();
        $[17] = content;
        $[18] = submitting;
        $[19] = t8;
    } else {
        t8 = $[19];
    }
    const t9 = submitting ? "..." : "Envoyer";
    let t10;
    if ($[20] !== t8 || $[21] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-end",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "submit",
                disabled: t8,
                className: "w-52.25 h-12.5 text-xs bg-btn-black text-white rounded-[8px] hover:opacity-90 transition disabled:opacity-50",
                children: t9
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/forms/CommentForm.tsx",
                lineNumber: 109,
                columnNumber: 45
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/CommentForm.tsx",
            lineNumber: 109,
            columnNumber: 11
        }, this);
        $[20] = t8;
        $[21] = t9;
        $[22] = t10;
    } else {
        t10 = $[22];
    }
    let t11;
    if ($[23] !== handleSubmit || $[24] !== t10 || $[25] !== t7) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: handleSubmit,
            className: "flex flex-col gap-2 mt-2",
            children: [
                t7,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/CommentForm.tsx",
            lineNumber: 118,
            columnNumber: 11
        }, this);
        $[23] = handleSubmit;
        $[24] = t10;
        $[25] = t7;
        $[26] = t11;
    } else {
        t11 = $[26];
    }
    return t11;
}
_s(CommentForm, "x5uw8oW7Y5YnE5AHND5jKABh970=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
_c = CommentForm;
var _c;
__turbopack_context__.k.register(_c, "CommentForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/projects/TaskCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TaskCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChevronDownIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/@heroicons/react/24/outline/esm/ChevronDownIcon.js [app-client] (ecmascript) <export default as ChevronDownIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChevronUpIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUpIcon$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/@heroicons/react/24/outline/esm/ChevronUpIcon.js [app-client] (ecmascript) <export default as ChevronUpIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/task.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CalenderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/CalenderIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$CommentForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/forms/CommentForm.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function TaskCard(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(61);
    if ($[0] !== "9081889396cae0161eef6e8b513c87fc29d7e37048687355af372dacc75ce96b") {
        for(let $i = 0; $i < 61; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9081889396cae0161eef6e8b513c87fc29d7e37048687355af372dacc75ce96b";
    }
    const { task, ownerId, onDelete, onEdit, onStatusChange, onRefresh } = t0;
    const [menuOpen, setMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [commentsOpen, setCommentsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const menuRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t1;
    let t2;
    if ($[1] !== menuOpen) {
        t1 = ({
            "TaskCard[useEffect()]": ()=>{
                const handleClickOutside = function handleClickOutside(e) {
                    if (menuRef.current && !menuRef.current.contains(e.target)) {
                        setMenuOpen(false);
                    }
                };
                if (menuOpen) {
                    document.addEventListener("mousedown", handleClickOutside);
                }
                return ()=>document.removeEventListener("mousedown", handleClickOutside);
            }
        })["TaskCard[useEffect()]"];
        t2 = [
            menuOpen
        ];
        $[1] = menuOpen;
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    const t3 = `Tâche : ${task.title}`;
    let t4;
    if ($[4] !== task.title) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "font-semibold text-police-black text-lg truncate",
            children: task.title
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 67,
            columnNumber: 10
        }, this);
        $[4] = task.title;
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const t5 = `text-sm px-2.5 py-0.5 rounded-full shrink-0 ${__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusColor"][task.status]}`;
    const t6 = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusLabel"][task.status];
    let t7;
    if ($[6] !== t5 || $[7] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: t5,
            children: t6
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 77,
            columnNumber: 10
        }, this);
        $[6] = t5;
        $[7] = t6;
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] !== t4 || $[10] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-2 flex-wrap",
            children: [
                t4,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 86,
            columnNumber: 10
        }, this);
        $[9] = t4;
        $[10] = t7;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== task.description) {
        t9 = task.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm text-text-secondary line-clamp-2",
            children: task.description
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 95,
            columnNumber: 30
        }, this);
        $[12] = task.description;
        $[13] = t9;
    } else {
        t9 = $[13];
    }
    let t10;
    if ($[14] !== t8 || $[15] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col flex-1 min-w-0 gap-1",
            children: [
                t8,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 103,
            columnNumber: 11
        }, this);
        $[14] = t8;
        $[15] = t9;
        $[16] = t10;
    } else {
        t10 = $[16];
    }
    let t11;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: {
                "TaskCard[<button>.onClick]": ()=>setMenuOpen(_TaskCardButtonOnClickSetMenuOpen)
            }["TaskCard[<button>.onClick]"],
            className: "flex justify-center items-center pb-2.5 text-lg rounded-[10px] w-14.25 h-14.25 text-police-grey border border-bg-grey-border hover:border-brand-dark hover:text-brand-dark transition",
            "aria-label": "Options de la t\xE2che",
            "aria-expanded": "false",
            "aria-haspopup": "menu",
            children: "..."
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 112,
            columnNumber: 11
        }, this);
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    if ($[18] !== menuOpen || $[19] !== onDelete || $[20] !== onEdit || $[21] !== onStatusChange || $[22] !== task) {
        t12 = menuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            role: "menu",
            className: "absolute right-0 top-7 z-20 bg-bg-content border border-system-neutral rounded-[8px] shadow-modal w-30 py-3 overflow-hidden",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-center gap-2",
                    children: [
                        "TODO",
                        "IN_PROGRESS",
                        "DONE",
                        "CANCELLED"
                    ].filter({
                        "TaskCard[(anonymous)()]": (s)=>s !== task.status
                    }["TaskCard[(anonymous)()]"]).map({
                        "TaskCard[(anonymous)()]": (s_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                role: "menuitem",
                                onClick: {
                                    "TaskCard[(anonymous)() > <button>.onClick]": ()=>{
                                        onStatusChange(task.id, s_0);
                                        setMenuOpen(false);
                                    }
                                }["TaskCard[(anonymous)() > <button>.onClick]"],
                                className: `w-fit px-2 py-1 text-xs rounded-full transition ${__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusColor"][s_0]} status-hover`,
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusLabel"][s_0]
                            }, s_0, false, {
                                fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                lineNumber: 124,
                                columnNumber: 45
                            }, this)
                    }["TaskCard[(anonymous)()]"])
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                    lineNumber: 121,
                    columnNumber: 176
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
                    className: "my-2 border-system-neutral",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                    lineNumber: 130,
                    columnNumber: 45
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            role: "menuitem",
                            onClick: {
                                "TaskCard[<button>.onClick]": ()=>{
                                    onEdit(task);
                                    setMenuOpen(false);
                                }
                            }["TaskCard[<button>.onClick]"],
                            className: "w-fit px-2 py-1 text-xs text-brand-dark underline hover:text-text-primary transition",
                            children: "Modifier"
                        }, void 0, false, {
                            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                            lineNumber: 130,
                            columnNumber: 159
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            role: "menuitem",
                            onClick: {
                                "TaskCard[<button>.onClick]": ()=>{
                                    onDelete(task.id);
                                    setMenuOpen(false);
                                }
                            }["TaskCard[<button>.onClick]"],
                            className: "w-fit px-2 py-1 text-xs text-text-error hover:underline transition",
                            children: "Supprimer"
                        }, void 0, false, {
                            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                            lineNumber: 135,
                            columnNumber: 156
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                    lineNumber: 130,
                    columnNumber: 109
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 121,
            columnNumber: 23
        }, this);
        $[18] = menuOpen;
        $[19] = onDelete;
        $[20] = onEdit;
        $[21] = onStatusChange;
        $[22] = task;
        $[23] = t12;
    } else {
        t12 = $[23];
    }
    let t13;
    if ($[24] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative shrink-0",
            ref: menuRef,
            children: [
                t11,
                t12
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 152,
            columnNumber: 11
        }, this);
        $[24] = t12;
        $[25] = t13;
    } else {
        t13 = $[25];
    }
    let t14;
    if ($[26] !== t10 || $[27] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-start justify-between gap-3 mb-4",
            children: [
                t10,
                t13
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 160,
            columnNumber: 11
        }, this);
        $[26] = t10;
        $[27] = t13;
        $[28] = t14;
    } else {
        t14 = $[28];
    }
    let t15;
    if ($[29] !== task.dueDate) {
        t15 = task.dueDate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-1.5 text-xs text-text-secondary mb-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "Échéance :"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                    lineNumber: 169,
                    columnNumber: 103
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CalenderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: "h-3.75 w-3.75 text-text-primary",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                    lineNumber: 169,
                    columnNumber: 126
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("time", {
                    dateTime: task.dueDate,
                    className: "text-text-primary",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(task.dueDate)
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                    lineNumber: 169,
                    columnNumber: 205
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 169,
            columnNumber: 27
        }, this);
        $[29] = task.dueDate;
        $[30] = t15;
    } else {
        t15 = $[30];
    }
    let t16;
    if ($[31] !== ownerId || $[32] !== task.assignees) {
        t16 = task.assignees.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-2 text-xs text-text-secondary mb-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "Assigné à :"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                    lineNumber: 177,
                    columnNumber: 114
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-1.5 flex-wrap",
                    children: task.assignees.map({
                        "TaskCard[task.assignees.map()]": (a)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `w-6.75 h-6.75 rounded-full flex items-center justify-center ${a.user.id === ownerId ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                        title: a.user.name,
                                        "aria-label": a.user.name,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: `text-[10px] ${a.user.id === ownerId ? "text-text-primary" : "text-text-secondary"}`,
                                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(a.user.name)
                                        }, void 0, false, {
                                            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                            lineNumber: 178,
                                            columnNumber: 292
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                        lineNumber: 178,
                                        columnNumber: 102
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `text-sm px-2 py-0.5 rounded-full ${a.user.id === ownerId ? "bg-brand-light text-text-primary" : "bg-bg-grey-border text-text-secondary"}`,
                                        children: a.user.name
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                        lineNumber: 178,
                                        columnNumber: 434
                                    }, this)
                                ]
                            }, a.id, true, {
                                fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                lineNumber: 178,
                                columnNumber: 50
                            }, this)
                    }["TaskCard[task.assignees.map()]"])
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                    lineNumber: 177,
                    columnNumber: 138
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 177,
            columnNumber: 40
        }, this);
        $[31] = ownerId;
        $[32] = task.assignees;
        $[33] = t16;
    } else {
        t16 = $[33];
    }
    const t17 = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["priorityLabel"][task.priority];
    let t18;
    if ($[34] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-xs text-text-secondary",
            children: [
                "Priorité : ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-text-primary font-medium",
                    children: t17
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                    lineNumber: 189,
                    columnNumber: 67
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 189,
            columnNumber: 11
        }, this);
        $[34] = t17;
        $[35] = t18;
    } else {
        t18 = $[35];
    }
    let t19;
    if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
            className: "border-system-neutral",
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 197,
            columnNumber: 11
        }, this);
        $[36] = t19;
    } else {
        t19 = $[36];
    }
    let t20;
    if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = ({
            "TaskCard[<button>.onClick]": ()=>setCommentsOpen(_TaskCardButtonOnClickSetCommentsOpen)
        })["TaskCard[<button>.onClick]"];
        $[37] = t20;
    } else {
        t20 = $[37];
    }
    const t21 = `comments-${task.id}`;
    let t22;
    if ($[38] !== task.comments.length) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "flex items-center gap-1.5",
            children: [
                "Commentaires (",
                task.comments.length,
                ")"
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 214,
            columnNumber: 11
        }, this);
        $[38] = task.comments.length;
        $[39] = t22;
    } else {
        t22 = $[39];
    }
    let t23;
    if ($[40] !== commentsOpen) {
        t23 = commentsOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChevronDownIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__["ChevronDownIcon"], {
            className: "h-5 w-5 text-btn-black",
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 222,
            columnNumber: 26
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChevronUpIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUpIcon$3e$__["ChevronUpIcon"], {
            className: "h-5 w-5 text-btn-black",
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 222,
            columnNumber: 102
        }, this);
        $[40] = commentsOpen;
        $[41] = t23;
    } else {
        t23 = $[41];
    }
    let t24;
    if ($[42] !== t21 || $[43] !== t22 || $[44] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: t20,
            className: "flex items-center justify-between text-xs text-text-primary hover:text-text-primary transition",
            "aria-expanded": "false",
            "aria-controls": t21,
            children: [
                t22,
                t23
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 230,
            columnNumber: 11
        }, this);
        $[42] = t21;
        $[43] = t22;
        $[44] = t23;
        $[45] = t24;
    } else {
        t24 = $[45];
    }
    let t25;
    if ($[46] !== commentsOpen || $[47] !== onRefresh || $[48] !== ownerId || $[49] !== task.comments || $[50] !== task.id || $[51] !== task.projectId) {
        t25 = commentsOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            id: `comments-${task.id}`,
            className: "flex flex-col gap-2",
            children: [
                task.comments.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-xs text-text-secondary",
                    children: "Aucun commentaire."
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                    lineNumber: 240,
                    columnNumber: 121
                }, this) : task.comments.map({
                    "TaskCard[task.comments.map()]": (comment)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-start gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `w-6.75 h-6.75 rounded-full flex items-center justify-center shrink-0 mt-1 ${comment.author.id === ownerId ? "bg-brand-light" : "bg-[#E5E7EB]"}`,
                                    "aria-hidden": "true",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[10px] text-btn-black",
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(comment.author.name)
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                        lineNumber: 241,
                                        columnNumber: 291
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                    lineNumber: 241,
                                    columnNumber: 110
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col justify-center h-20.75 gap-5 bg-bg-grey-light rounded-[10px] px-3 py-2 flex-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-sm text-police-black",
                                                    children: comment.author.name
                                                }, void 0, false, {
                                                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                                    lineNumber: 241,
                                                    columnNumber: 549
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("time", {
                                                    className: "text-[10px] text-text-secondary shrink-0",
                                                    dateTime: comment.createdAt,
                                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(comment.createdAt)
                                                }, void 0, false, {
                                                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                                    lineNumber: 241,
                                                    columnNumber: 621
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                            lineNumber: 241,
                                            columnNumber: 492
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-[10px] text-police-black",
                                            children: comment.content
                                        }, void 0, false, {
                                            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                            lineNumber: 241,
                                            columnNumber: 753
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                                    lineNumber: 241,
                                    columnNumber: 383
                                }, this)
                            ]
                        }, comment.id, true, {
                            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                            lineNumber: 241,
                            columnNumber: 53
                        }, this)
                }["TaskCard[task.comments.map()]"]),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$CommentForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    projectId: task.projectId,
                    taskId: task.id,
                    onRefresh: onRefresh
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
                    lineNumber: 242,
                    columnNumber: 43
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 240,
            columnNumber: 27
        }, this);
        $[46] = commentsOpen;
        $[47] = onRefresh;
        $[48] = ownerId;
        $[49] = task.comments;
        $[50] = task.id;
        $[51] = task.projectId;
        $[52] = t25;
    } else {
        t25 = $[52];
    }
    let t26;
    if ($[53] !== t14 || $[54] !== t15 || $[55] !== t16 || $[56] !== t18 || $[57] !== t24 || $[58] !== t25 || $[59] !== t3) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-bg-content rounded-[10px] border border-bg-grey-border px-5 py-4 flex flex-col gap-3",
            "aria-label": t3,
            children: [
                t14,
                t15,
                t16,
                t18,
                t19,
                t24,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/TaskCard.tsx",
            lineNumber: 255,
            columnNumber: 11
        }, this);
        $[53] = t14;
        $[54] = t15;
        $[55] = t16;
        $[56] = t18;
        $[57] = t24;
        $[58] = t25;
        $[59] = t3;
        $[60] = t26;
    } else {
        t26 = $[60];
    }
    return t26;
}
_s(TaskCard, "KtnThLK2ukIxwidZ/5UQREXOouY=");
_c = TaskCard;
function _TaskCardButtonOnClickSetCommentsOpen(v_0) {
    return !v_0;
}
function _TaskCardButtonOnClickSetMenuOpen(v) {
    return !v;
}
var _c;
__turbopack_context__.k.register(_c, "TaskCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/project/ProjectTaskList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectTaskList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$projects$2f$TaskCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/projects/TaskCard.tsx [app-client] (ecmascript)");
"use client";
;
;
;
function ProjectTaskList(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "a685c39a14e3675bf969a75c0feb8c5d05a519197ca19eb45dffd516a52d29f5") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a685c39a14e3675bf969a75c0feb8c5d05a519197ca19eb45dffd516a52d29f5";
    }
    const { tasks, ownerId, onEditTask, onDeleteTask, onStatusChange, onRefresh } = t0;
    let t1;
    if ($[1] !== onDeleteTask || $[2] !== onEditTask || $[3] !== onRefresh || $[4] !== onStatusChange || $[5] !== ownerId || $[6] !== tasks) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "bg-bg-content rounded-[10px] shadow-card px-6 py-5 flex flex-col gap-4",
            children: tasks.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-text-secondary py-4",
                children: "Aucune tâche pour le moment."
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/project/ProjectTaskList.tsx",
                lineNumber: 32,
                columnNumber: 124
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "flex flex-col gap-3",
                "aria-label": "Liste des t\xE2ches",
                children: tasks.map({
                    "ProjectTaskList[tasks.map()]": (task)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$projects$2f$TaskCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                ownerId: ownerId,
                                task: task,
                                onDelete: onDeleteTask,
                                onEdit: onEditTask,
                                onStatusChange: onStatusChange,
                                onRefresh: onRefresh
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/project/ProjectTaskList.tsx",
                                lineNumber: 33,
                                columnNumber: 69
                            }, this)
                        }, task.id, false, {
                            fileName: "[project]/frontend/src/components/project/ProjectTaskList.tsx",
                            lineNumber: 33,
                            columnNumber: 51
                        }, this)
                }["ProjectTaskList[tasks.map()]"])
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/project/ProjectTaskList.tsx",
                lineNumber: 32,
                columnNumber: 207
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/project/ProjectTaskList.tsx",
            lineNumber: 32,
            columnNumber: 10
        }, this);
        $[1] = onDeleteTask;
        $[2] = onEditTask;
        $[3] = onRefresh;
        $[4] = onStatusChange;
        $[5] = ownerId;
        $[6] = tasks;
        $[7] = t1;
    } else {
        t1 = $[7];
    }
    return t1;
}
_c = ProjectTaskList;
var _c;
__turbopack_context__.k.register(_c, "ProjectTaskList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/BaseModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BaseModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js [app-client] (ecmascript) <export default as XMarkIcon>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function BaseModal(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(26);
    if ($[0] !== "aff49536f83a2f9678dc696da740fff19a7778adf2d464681431e0156f689bc6") {
        for(let $i = 0; $i < 26; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "aff49536f83a2f9678dc696da740fff19a7778adf2d464681431e0156f689bc6";
    }
    const { id, title, onClose, children, maxWidth: t1, icon } = t0;
    const maxWidth = t1 === undefined ? "max-w-149.5" : t1;
    let t2;
    let t3;
    if ($[1] !== onClose) {
        t2 = ({
            "BaseModal[useEffect()]": ()=>{
                const handleKeyDown = function handleKeyDown(e) {
                    if (e.key === "Escape") {
                        onClose();
                    }
                };
                document.addEventListener("keydown", handleKeyDown);
                return ()=>document.removeEventListener("keydown", handleKeyDown);
            }
        })["BaseModal[useEffect()]"];
        t3 = [
            onClose
        ];
        $[1] = onClose;
        $[2] = t2;
        $[3] = t3;
    } else {
        t2 = $[2];
        t3 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    const t4 = `bg-bg-content rounded-[8px] shadow-modal w-full ${maxWidth} max-h-[90vh] overflow-y-auto p-6 flex flex-col gap-5`;
    let t5;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
            className: "h-5 w-5"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 58,
            columnNumber: 10
        }, this);
        $[4] = t5;
    } else {
        t5 = $[4];
    }
    let t6;
    if ($[5] !== onClose) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-end",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: onClose,
                className: "text-text-secondary hover:text-text-primary transition",
                "aria-label": "Fermer la modale",
                children: t5
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
                lineNumber: 65,
                columnNumber: 44
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 65,
            columnNumber: 10
        }, this);
        $[5] = onClose;
        $[6] = t6;
    } else {
        t6 = $[6];
    }
    let t7;
    if ($[7] !== icon) {
        t7 = icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-2.5",
            children: icon
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 73,
            columnNumber: 18
        }, this);
        $[7] = icon;
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] !== id || $[10] !== title) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            id: id,
            className: "font-semibold text-text-primary text-2xl mt-2",
            children: title
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[9] = id;
        $[10] = title;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== t7 || $[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center ml-12 gap-2",
            children: [
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[12] = t7;
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== t6 || $[16] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col",
            children: [
                t6,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 99,
            columnNumber: 11
        }, this);
        $[15] = t6;
        $[16] = t9;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] !== children || $[19] !== t10 || $[20] !== t4) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t4,
            onClick: _BaseModalDivOnClick,
            children: [
                t10,
                children
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 108,
            columnNumber: 11
        }, this);
        $[18] = children;
        $[19] = t10;
        $[20] = t4;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    let t12;
    if ($[22] !== id || $[23] !== onClose || $[24] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-50 flex items-center justify-center bg-black/40",
            role: "dialog",
            "aria-modal": "true",
            "aria-labelledby": id,
            onClick: onClose,
            children: t11
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 118,
            columnNumber: 11
        }, this);
        $[22] = id;
        $[23] = onClose;
        $[24] = t11;
        $[25] = t12;
    } else {
        t12 = $[25];
    }
    return t12;
}
_s(BaseModal, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = BaseModal;
function _BaseModalDivOnClick(e_0) {
    return e_0.stopPropagation();
}
var _c;
__turbopack_context__.k.register(_c, "BaseModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/api/users.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getUsers",
    ()=>getUsers,
    "searchUsers",
    ()=>searchUsers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
;
async function searchUsers(query) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/users/search?query=${encodeURIComponent(query)}`);
}
async function getUsers() {
    const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])("/users");
    return res.data?.users ?? [];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/ContributorSearch.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContributorSearch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$users$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/users.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ContributorSearch(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(50);
    if ($[0] !== "07ecb7b3715facea8e6f57e6f46f639dd21737f69da0bbeae2e1c6ad953e147c") {
        for(let $i = 0; $i < 50; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "07ecb7b3715facea8e6f57e6f46f639dd21737f69da0bbeae2e1c6ad953e147c";
    }
    const { selectedUsers, excludeUserIds: t1, onAdd, onRemove, label: t2, ownerId, buttonLabel: t3 } = t0;
    let t4;
    if ($[1] !== t1) {
        t4 = t1 === undefined ? [] : t1;
        $[1] = t1;
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    const excludeUserIds = t4;
    const label = t2 === undefined ? "Contributeurs" : t2;
    const buttonLabel = t3 === undefined ? "Choisir un ou plusieurs collaborateurs" : t3;
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t5;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = [];
        $[3] = t5;
    } else {
        t5 = $[3];
    }
    const [allUsers, setAllUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t5);
    let t6;
    let t7;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "ContributorSearch[useEffect()]": ()=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$users$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUsers"])().then({
                    "ContributorSearch[useEffect() > (anonymous)()]": (users)=>setAllUsers(users)
                }["ContributorSearch[useEffect() > (anonymous)()]"]);
            }
        })["ContributorSearch[useEffect()]"];
        t7 = [];
        $[4] = t6;
        $[5] = t7;
    } else {
        t6 = $[4];
        t7 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t6, t7);
    let t10;
    let t11;
    let t12;
    let t13;
    let t8;
    let t9;
    if ($[6] !== allUsers || $[7] !== buttonLabel || $[8] !== excludeUserIds || $[9] !== isOpen || $[10] !== label || $[11] !== onAdd || $[12] !== onRemove || $[13] !== ownerId || $[14] !== selectedUsers) {
        let t14;
        if ($[21] !== excludeUserIds || $[22] !== selectedUsers) {
            t14 = ({
                "ContributorSearch[allUsers.filter()]": (u)=>!selectedUsers.find({
                        "ContributorSearch[allUsers.filter() > selectedUsers.find()]": (s)=>s.id === u.id
                    }["ContributorSearch[allUsers.filter() > selectedUsers.find()]"]) && !excludeUserIds.includes(u.id)
            })["ContributorSearch[allUsers.filter()]"];
            $[21] = excludeUserIds;
            $[22] = selectedUsers;
            $[23] = t14;
        } else {
            t14 = $[23];
        }
        const availableUsers = allUsers.filter(t14);
        let t15;
        if ($[24] !== onAdd) {
            t15 = function handleAdd(user) {
                onAdd(user);
                setIsOpen(false);
            };
            $[24] = onAdd;
            $[25] = t15;
        } else {
            t15 = $[25];
        }
        const handleAdd = t15;
        t11 = "flex flex-col gap-1";
        if ($[26] !== label) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm text-text-primary",
                children: label
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 107,
                columnNumber: 13
            }, this);
            $[26] = label;
            $[27] = t12;
        } else {
            t12 = $[27];
        }
        if ($[28] !== onRemove || $[29] !== ownerId || $[30] !== selectedUsers) {
            t13 = selectedUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-2 mb-1",
                children: selectedUsers.map({
                    "ContributorSearch[selectedUsers.map()]": (u_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1.5 bg-bg-grey-light rounded-full px-2 py-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${u_0.id === ownerId ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `text-[9px] ${u_0.id === ownerId ? "text-text-primary" : "text-text-secondary"}`,
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(u_0.name)
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                        lineNumber: 115,
                                        columnNumber: 301
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 115,
                                    columnNumber: 156
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs text-text-primary",
                                    children: u_0.name
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 115,
                                    columnNumber: 436
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: {
                                        "ContributorSearch[selectedUsers.map() > <button>.onClick]": ()=>onRemove(u_0.id)
                                    }["ContributorSearch[selectedUsers.map() > <button>.onClick]"],
                                    className: "text-text-secondary hover:text-system-error text-xs ml-0.5",
                                    "aria-label": `Retirer ${u_0.name}`,
                                    children: "×"
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 115,
                                    columnNumber: 497
                                }, this)
                            ]
                        }, u_0.id, true, {
                            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                            lineNumber: 115,
                            columnNumber: 60
                        }, this)
                }["ContributorSearch[selectedUsers.map()]"])
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 114,
                columnNumber: 41
            }, this);
            $[28] = onRemove;
            $[29] = ownerId;
            $[30] = selectedUsers;
            $[31] = t13;
        } else {
            t13 = $[31];
        }
        t8 = "relative";
        let t16;
        if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
            t16 = ({
                "ContributorSearch[<button>.onClick]": ()=>setIsOpen(_ContributorSearchButtonOnClickSetIsOpen)
            })["ContributorSearch[<button>.onClick]"];
            $[32] = t16;
        } else {
            t16 = $[32];
        }
        let t17;
        if ($[33] !== buttonLabel) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-text-secondary",
                children: buttonLabel
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 138,
                columnNumber: 13
            }, this);
            $[33] = buttonLabel;
            $[34] = t17;
        } else {
            t17 = $[34];
        }
        const t18 = `h-6 w-6 text-btn-black transition-transform ${isOpen ? "rotate-180" : ""}`;
        let t19;
        if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
            t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M5 8l5 5 5-5"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 147,
                columnNumber: 13
            }, this);
            $[35] = t19;
        } else {
            t19 = $[35];
        }
        let t20;
        if ($[36] !== t18) {
            t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: t18,
                viewBox: "0 0 20 20",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: 1.5,
                children: t19
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 154,
                columnNumber: 13
            }, this);
            $[36] = t18;
            $[37] = t20;
        } else {
            t20 = $[37];
        }
        if ($[38] !== t17 || $[39] !== t20) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: t16,
                className: "w-full h-13.25 flex items-center justify-between border border-system-neutral rounded-[8px] px-4 py-3 text-sm bg-bg-content transition",
                children: [
                    t17,
                    t20
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 161,
                columnNumber: 12
            }, this);
            $[38] = t17;
            $[39] = t20;
            $[40] = t9;
        } else {
            t9 = $[40];
        }
        t10 = isOpen && availableUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-full left-0 right-0 z-20 bg-bg-content border border-system-neutral rounded-[8px] shadow-modal mt-1 overflow-hidden max-h-48 overflow-y-auto",
            children: availableUsers.map({
                "ContributorSearch[availableUsers.map()]": (u_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: {
                            "ContributorSearch[availableUsers.map() > <button>.onClick]": ()=>handleAdd(u_1)
                        }["ContributorSearch[availableUsers.map() > <button>.onClick]"],
                        className: "w-full flex items-center gap-2 px-4 py-2 text-sm text-text-secondary hover:bg-bg-grey-light transition",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${u_1.id === ownerId ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `text-[9px] font-semibold ${u_1.id === ownerId ? "text-text-primary" : "text-text-secondary"}`,
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(u_1.name)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 171,
                                    columnNumber: 334
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                lineNumber: 171,
                                columnNumber: 189
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `px-2 py-0.5 rounded-full text-sm ${u_1.id === ownerId ? "bg-brand-light text-text-primary" : "bg-bg-grey-border text-text-secondary"}`,
                                children: u_1.name
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                lineNumber: 171,
                                columnNumber: 483
                            }, this)
                        ]
                    }, u_1.id, true, {
                        fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                        lineNumber: 169,
                        columnNumber: 59
                    }, this)
            }["ContributorSearch[availableUsers.map()]"])
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
            lineNumber: 168,
            columnNumber: 50
        }, this);
        $[6] = allUsers;
        $[7] = buttonLabel;
        $[8] = excludeUserIds;
        $[9] = isOpen;
        $[10] = label;
        $[11] = onAdd;
        $[12] = onRemove;
        $[13] = ownerId;
        $[14] = selectedUsers;
        $[15] = t10;
        $[16] = t11;
        $[17] = t12;
        $[18] = t13;
        $[19] = t8;
        $[20] = t9;
    } else {
        t10 = $[15];
        t11 = $[16];
        t12 = $[17];
        t13 = $[18];
        t8 = $[19];
        t9 = $[20];
    }
    let t14;
    if ($[41] !== t10 || $[42] !== t8 || $[43] !== t9) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t8,
            children: [
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
            lineNumber: 198,
            columnNumber: 11
        }, this);
        $[41] = t10;
        $[42] = t8;
        $[43] = t9;
        $[44] = t14;
    } else {
        t14 = $[44];
    }
    let t15;
    if ($[45] !== t11 || $[46] !== t12 || $[47] !== t13 || $[48] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t11,
            children: [
                t12,
                t13,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
            lineNumber: 208,
            columnNumber: 11
        }, this);
        $[45] = t11;
        $[46] = t12;
        $[47] = t13;
        $[48] = t14;
        $[49] = t15;
    } else {
        t15 = $[49];
    }
    return t15;
}
_s(ContributorSearch, "0MGr9tRE1P5jAGVda6z1I3Fhqgc=");
_c = ContributorSearch;
function _ContributorSearchButtonOnClickSetIsOpen(v) {
    return !v;
}
var _c;
__turbopack_context__.k.register(_c, "ContributorSearch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/forms/ProjectForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$ContributorSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/ContributorSearch.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ProjectForm(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(59);
    if ($[0] !== "2492284460de39344344b9fe362117072d989e282ac6370753fde79ef61e10c6") {
        for(let $i = 0; $i < 59; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2492284460de39344344b9fe362117072d989e282ac6370753fde79ef61e10c6";
    }
    const { initialName: t1, initialDescription: t2, initialMembers: t3, totalContributors, submitLabel, loading, error, onSubmit, onDelete, projectId, onAddContributor, onRemoveContributor, selectedContributors: t4, ownerId } = t0;
    const initialName = t1 === undefined ? "" : t1;
    const initialDescription = t2 === undefined ? "" : t2;
    const initialMembers = t3 === undefined ? [] : t3;
    let t5;
    if ($[1] !== t4) {
        t5 = t4 === undefined ? [] : t4;
        $[1] = t4;
        $[2] = t5;
    } else {
        t5 = $[2];
    }
    const selectedContributors = t5;
    const [name, setName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialName);
    const [description, setDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialDescription);
    let t6;
    if ($[3] !== description || $[4] !== name || $[5] !== onSubmit || $[6] !== selectedContributors) {
        t6 = async function handleSubmit(e) {
            e.preventDefault();
            const contributorEmails = selectedContributors.map(_ProjectFormHandleSubmitSelectedContributorsMap);
            await onSubmit(name, description, contributorEmails);
        };
        $[3] = description;
        $[4] = name;
        $[5] = onSubmit;
        $[6] = selectedContributors;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    const handleSubmit = t6;
    const excludeUserIds = initialMembers.map(_ProjectFormInitialMembersMap);
    let t7;
    if ($[8] !== ownerId) {
        t7 = ({
            "ProjectForm[initialMembers.find()]": (m_0)=>m_0.user.id === ownerId
        })["ProjectForm[initialMembers.find()]"];
        $[8] = ownerId;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    const ownerMember = initialMembers.find(t7);
    const ownerName = ownerMember?.user.name ?? "";
    const ownerInitials = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(ownerName);
    let t8;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            htmlFor: "project-name",
            className: "text-sm text-police-black",
            children: [
                "Titre ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    "aria-hidden": "true",
                    children: "*"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 97,
                    columnNumber: 84
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 97,
            columnNumber: 10
        }, this);
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] !== setName) {
        t9 = ({
            "ProjectForm[<input>.onChange]": (e_0)=>setName(e_0.target.value)
        })["ProjectForm[<input>.onChange]"];
        $[11] = setName;
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    let t10;
    if ($[13] !== name || $[14] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t8,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    id: "project-name",
                    type: "text",
                    value: name,
                    onChange: t9,
                    className: "h-13.25 px-4 py-2.5 text-sm text-police-black bg-bg-content transition",
                    placeholder: "Nom du projet",
                    required: true,
                    autoFocus: true
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 114,
                    columnNumber: 52
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 114,
            columnNumber: 11
        }, this);
        $[13] = name;
        $[14] = t9;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    let t11;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            htmlFor: "project-description",
            className: "text-sm text-text-primary",
            children: "Description"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 123,
            columnNumber: 11
        }, this);
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    let t12;
    if ($[17] !== setDescription) {
        t12 = ({
            "ProjectForm[<textarea>.onChange]": (e_1)=>setDescription(e_1.target.value)
        })["ProjectForm[<textarea>.onChange]"];
        $[17] = setDescription;
        $[18] = t12;
    } else {
        t12 = $[18];
    }
    let t13;
    if ($[19] !== description || $[20] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t11,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                    id: "project-description",
                    value: description,
                    onChange: t12,
                    className: "px-4 py-2.5 h-13.25 text-sm text-police-black bg-bg-content transition resize-none",
                    placeholder: "Description du projet"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 140,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 140,
            columnNumber: 11
        }, this);
        $[19] = description;
        $[20] = t12;
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    let t14;
    if ($[22] !== onRemoveContributor || $[23] !== ownerInitials || $[24] !== ownerMember || $[25] !== ownerName || $[26] !== selectedContributors || $[27] !== totalContributors) {
        t14 = onRemoveContributor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-sm font-medium text-text-primary",
                    children: [
                        "Contributeurs actuels (",
                        totalContributors,
                        ")"
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 149,
                    columnNumber: 71
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-wrap items-center gap-2",
                    children: [
                        ownerMember && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1 px-2.5 rounded-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-5 h-5 rounded-full flex items-center justify-center bg-brand-light",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[10px] font-semibold text-btn-black",
                                        children: ownerInitials
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                        lineNumber: 149,
                                        columnNumber: 391
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                    lineNumber: 149,
                                    columnNumber: 305
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[10px] px-2 py-0.5 rounded-full bg-brand-light text-text-primary",
                                    children: ownerName
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                    lineNumber: 149,
                                    columnNumber: 478
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                            lineNumber: 149,
                            columnNumber: 244
                        }, this),
                        selectedContributors.map({
                            "ProjectForm[selectedContributors.map()]": (user)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-1 px-2.5 rounded-full",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-5 h-5 rounded-full flex items-center justify-center bg-bg-grey-border",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[10px] font-semibold text-text-secondary",
                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(user.name)
                                            }, void 0, false, {
                                                fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                                lineNumber: 150,
                                                columnNumber: 226
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                            lineNumber: 150,
                                            columnNumber: 137
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[10px] px-2 py-0.5 rounded-full bg-bg-grey-border text-text-secondary",
                                            children: user.name
                                        }, void 0, false, {
                                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                            lineNumber: 150,
                                            columnNumber: 327
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: {
                                                "ProjectForm[selectedContributors.map() > <button>.onClick]": ()=>onRemoveContributor(user.id)
                                            }["ProjectForm[selectedContributors.map() > <button>.onClick]"],
                                            className: "text-text-secondary mb-1 hover:text-brand-dark transition",
                                            "aria-label": `Retirer ${user.name}`,
                                            children: "×"
                                        }, void 0, false, {
                                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                            lineNumber: 150,
                                            columnNumber: 438
                                        }, this)
                                    ]
                                }, user.id, true, {
                                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                    lineNumber: 150,
                                    columnNumber: 62
                                }, this)
                        }["ProjectForm[selectedContributors.map()]"])
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 149,
                    columnNumber: 177
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 149,
            columnNumber: 34
        }, this);
        $[22] = onRemoveContributor;
        $[23] = ownerInitials;
        $[24] = ownerMember;
        $[25] = ownerName;
        $[26] = selectedContributors;
        $[27] = totalContributors;
        $[28] = t14;
    } else {
        t14 = $[28];
    }
    let t15;
    if ($[29] !== excludeUserIds || $[30] !== onAddContributor || $[31] !== onRemoveContributor || $[32] !== ownerId || $[33] !== selectedContributors) {
        t15 = onAddContributor && onRemoveContributor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$ContributorSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            selectedUsers: selectedContributors,
            excludeUserIds: excludeUserIds,
            onAdd: onAddContributor,
            onRemove: onRemoveContributor,
            label: "Ajouter un contributeur",
            ownerId: ownerId,
            buttonLabel: selectedContributors.length > 0 ? `${selectedContributors.length} collaborateur${selectedContributors.length > 1 ? "s" : ""}` : "Choisir un ou plusieurs collaborateurs"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 166,
            columnNumber: 54
        }, this);
        $[29] = excludeUserIds;
        $[30] = onAddContributor;
        $[31] = onRemoveContributor;
        $[32] = ownerId;
        $[33] = selectedContributors;
        $[34] = t15;
    } else {
        t15 = $[34];
    }
    let t16;
    if ($[35] !== error) {
        t16 = error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            role: "alert",
            "aria-live": "assertive",
            className: "text-sm text-text-error",
            children: error
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 178,
            columnNumber: 20
        }, this);
        $[35] = error;
        $[36] = t16;
    } else {
        t16 = $[36];
    }
    let t17;
    if ($[37] !== loading || $[38] !== name) {
        t17 = loading || !name.trim();
        $[37] = loading;
        $[38] = name;
        $[39] = t17;
    } else {
        t17 = $[39];
    }
    const t18 = loading ? "En cours..." : submitLabel;
    let t19;
    if ($[40] !== t17 || $[41] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            disabled: t17,
            className: "w-46.25 h-12.5 py-2.5 bg-system-neutral text-text-neutral text-base rounded-[10px] hover:border border-brand-dark hover:text-brand-dark hover:bg-bg-content transition",
            children: t18
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 196,
            columnNumber: 11
        }, this);
        $[40] = t17;
        $[41] = t18;
        $[42] = t19;
    } else {
        t19 = $[42];
    }
    let t20;
    if ($[43] !== onDelete || $[44] !== projectId) {
        t20 = onDelete && projectId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            className: "text-text-error hover:text-red-700 text-sm",
            onClick: onDelete,
            children: "Supprimer le projet"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 205,
            columnNumber: 36
        }, this);
        $[43] = onDelete;
        $[44] = projectId;
        $[45] = t20;
    } else {
        t20 = $[45];
    }
    let t21;
    if ($[46] !== t19 || $[47] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-row justify-between mt-4",
            children: [
                t19,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 214,
            columnNumber: 11
        }, this);
        $[46] = t19;
        $[47] = t20;
        $[48] = t21;
    } else {
        t21 = $[48];
    }
    let t22;
    if ($[49] !== t10 || $[50] !== t13 || $[51] !== t14 || $[52] !== t15 || $[53] !== t16 || $[54] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-113 mx-auto overflow-y-auto flex flex-col gap-4 pr-1",
            children: [
                t10,
                t13,
                t14,
                t15,
                t16,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 223,
            columnNumber: 11
        }, this);
        $[49] = t10;
        $[50] = t13;
        $[51] = t14;
        $[52] = t15;
        $[53] = t16;
        $[54] = t21;
        $[55] = t22;
    } else {
        t22 = $[55];
    }
    let t23;
    if ($[56] !== handleSubmit || $[57] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: handleSubmit,
            className: "flex flex-col gap-4",
            noValidate: true,
            children: t22
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 236,
            columnNumber: 11
        }, this);
        $[56] = handleSubmit;
        $[57] = t22;
        $[58] = t23;
    } else {
        t23 = $[58];
    }
    return t23;
}
_s(ProjectForm, "p8e3PxGPGSdEGKqdDTcGONQjRj0=");
_c = ProjectForm;
function _ProjectFormInitialMembersMap(m) {
    return m.user.id;
}
function _ProjectFormHandleSubmitSelectedContributorsMap(c) {
    return c.email;
}
var _c;
__turbopack_context__.k.register(_c, "ProjectForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/ModalProjectDelete.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ModalProjectDelete
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
"use client";
;
;
function ModalProjectDelete(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "228ae9e65e2a9c7844f796b65f79e2c047a3ea4545d7a82e3bd3ebe9b66a3fb6") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "228ae9e65e2a9c7844f796b65f79e2c047a3ea4545d7a82e3bd3ebe9b66a3fb6";
    }
    const { onClose, onConfirm } = t0;
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            id: "delete-project-title",
            className: "text-xl font-semibold mb-2",
            children: "Supprimer le projet"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/ModalProjectDelete.tsx",
            lineNumber: 23,
            columnNumber: 10
        }, this);
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm text-gray-600 mb-6",
            children: "Cette action est irréversible. Voulez-vous vraiment supprimer ce projet ?"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/ModalProjectDelete.tsx",
            lineNumber: 24,
            columnNumber: 10
        }, this);
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    let t3;
    if ($[3] !== onClose) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: onClose,
            className: "px-4 py-2 rounded-md text-sm bg-gray-200 hover:bg-gray-300 transition",
            children: "Annuler"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/ModalProjectDelete.tsx",
            lineNumber: 33,
            columnNumber: 10
        }, this);
        $[3] = onClose;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== onConfirm) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            "aria-label": "Confirmer suppression projet",
            onClick: onConfirm,
            className: "px-4 py-2 rounded-md text-sm bg-red-600 text-white hover:bg-red-700 transition",
            children: "Confirmer"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/ModalProjectDelete.tsx",
            lineNumber: 41,
            columnNumber: 10
        }, this);
        $[5] = onConfirm;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== t3 || $[8] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 bg-black/40 flex items-center justify-center z-50",
            role: "dialog",
            "aria-modal": "true",
            "aria-labelledby": "delete-project-title",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-xl shadow-xl p-6 w-full max-w-md",
                children: [
                    t1,
                    t2,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-end gap-3",
                        children: [
                            t3,
                            t4
                        ]
                    }, void 0, true, {
                        fileName: "[project]/frontend/src/components/modals/ModalProjectDelete.tsx",
                        lineNumber: 49,
                        columnNumber: 237
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/modals/ModalProjectDelete.tsx",
                lineNumber: 49,
                columnNumber: 162
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/ModalProjectDelete.tsx",
            lineNumber: 49,
            columnNumber: 10
        }, this);
        $[7] = t3;
        $[8] = t4;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    return t5;
}
_c = ModalProjectDelete;
var _c;
__turbopack_context__.k.register(_c, "ModalProjectDelete");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/EditProjectModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EditProjectModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/BaseModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$ProjectForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/forms/ProjectForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$ModalProjectDelete$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/ModalProjectDelete.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function EditProjectModal({ projectId, initialName, initialDescription, initialMembers, ownerId, projectContributors, totalContributors, onClose, onSubmit, onAddContributor, onRemoveContributor, onRefresh, onDelete }) {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedContributors, setSelectedContributors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(projectContributors);
    const [deleteOpen, setDeleteOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EditProjectModal.useEffect": ()=>{
            setSelectedContributors(projectContributors);
        }
    }["EditProjectModal.useEffect"], [
        projectContributors
    ]);
    async function handleSubmit(name, description) {
        setError(null);
        setLoading(true);
        try {
            await onSubmit(projectId, name, description);
            await onRefresh();
            onClose();
        } catch (err) {
            if (err instanceof Error) setError(err.message);
            else setError("Une erreur est survenue");
        } finally{
            setLoading(false);
        }
    }
    // 🔹 Ajout d’un contributeur via ContributorSearch
    async function handleAddContributor(user) {
        try {
            await onAddContributor(projectId, user.email);
            setSelectedContributors((prev)=>[
                    ...prev,
                    user
                ]);
        } catch (err_0) {
            if (err_0 instanceof Error) setError(err_0.message);
        }
    }
    // 🔹 Suppression d’un contributeur
    async function handleRemoveContributor(userId) {
        try {
            await onRemoveContributor(projectId, userId);
            setSelectedContributors((prev_0)=>prev_0.filter((u)=>u.id !== userId));
        } catch (err_1) {
            if (err_1 instanceof Error) setError(err_1.message);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        id: "edit-project-title",
        title: "Modifier un projet",
        onClose: onClose,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$ProjectForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                initialName: initialName,
                initialDescription: initialDescription,
                initialMembers: initialMembers,
                projectContributors: projectContributors,
                totalContributors: totalContributors,
                submitLabel: "Enregistrer",
                loading: loading,
                error: error,
                onSubmit: handleSubmit,
                onAddContributor: handleAddContributor,
                onRemoveContributor: handleRemoveContributor,
                selectedContributors: selectedContributors,
                ownerId: ownerId,
                projectId: projectId,
                onDelete: ()=>setDeleteOpen(true)
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/modals/EditProjectModal.tsx",
                lineNumber: 79,
                columnNumber: 7
            }, this),
            deleteOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$ModalProjectDelete$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                onClose: ()=>setDeleteOpen(false),
                onConfirm: async ()=>{
                    await onDelete(projectId);
                    onClose();
                }
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/modals/EditProjectModal.tsx",
                lineNumber: 82,
                columnNumber: 22
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/frontend/src/components/modals/EditProjectModal.tsx",
        lineNumber: 78,
        columnNumber: 10
    }, this);
}
_s(EditProjectModal, "X4ickiKbLbSJj8E4DlPUw0lFd1s=");
_c = EditProjectModal;
var _c;
__turbopack_context__.k.register(_c, "EditProjectModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/MemberSearch.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MemberSearch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function MemberSearch(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(43);
    if ($[0] !== "4d45052403fa6202f806317131c96d30881ec7d39c592d98ed1ada1b09ec5c06") {
        for(let $i = 0; $i < 43; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4d45052403fa6202f806317131c96d30881ec7d39c592d98ed1ada1b09ec5c06";
    }
    const { users, selectedUsers, onAdd, onRemove, ownerId, label: t1, buttonLabel: t2 } = t0;
    const label = t1 === undefined ? "Assign\xE9 \xE0" : t1;
    const buttonLabel = t2 === undefined ? "Choisir un ou plusieurs collaborateurs" : t2;
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    if ($[1] !== buttonLabel || $[2] !== isOpen || $[3] !== label || $[4] !== onAdd || $[5] !== onRemove || $[6] !== ownerId || $[7] !== selectedUsers || $[8] !== users) {
        let t9;
        if ($[15] !== selectedUsers) {
            t9 = ({
                "MemberSearch[users.filter()]": (u)=>!selectedUsers.some({
                        "MemberSearch[users.filter() > selectedUsers.some()]": (s)=>s.id === u.id
                    }["MemberSearch[users.filter() > selectedUsers.some()]"])
            })["MemberSearch[users.filter()]"];
            $[15] = selectedUsers;
            $[16] = t9;
        } else {
            t9 = $[16];
        }
        const availableUsers = users.filter(t9);
        let t10;
        if ($[17] !== onAdd) {
            t10 = function handleAdd(user) {
                onAdd(user);
                setIsOpen(false);
            };
            $[17] = onAdd;
            $[18] = t10;
        } else {
            t10 = $[18];
        }
        const handleAdd = t10;
        t6 = "flex flex-col gap-1";
        if ($[19] !== label) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm text-text-primary",
                children: label
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 70,
                columnNumber: 12
            }, this);
            $[19] = label;
            $[20] = t7;
        } else {
            t7 = $[20];
        }
        if ($[21] !== onRemove || $[22] !== ownerId || $[23] !== selectedUsers) {
            t8 = selectedUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-2 mb-1",
                children: selectedUsers.map({
                    "MemberSearch[selectedUsers.map()]": (u_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1.5 bg-bg-grey-light rounded-full px-2 py-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${u_0.id === ownerId ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `text-[9px] ${u_0.id === ownerId ? "text-text-primary" : "text-text-secondary"}`,
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(u_0.name)
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                        lineNumber: 78,
                                        columnNumber: 296
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                    lineNumber: 78,
                                    columnNumber: 151
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs text-text-primary",
                                    children: u_0.name
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                    lineNumber: 78,
                                    columnNumber: 431
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: {
                                        "MemberSearch[selectedUsers.map() > <button>.onClick]": ()=>onRemove(u_0.id)
                                    }["MemberSearch[selectedUsers.map() > <button>.onClick]"],
                                    className: "text-text-secondary hover:text-system-error text-xs ml-0.5",
                                    "aria-label": `Retirer ${u_0.name}`,
                                    children: "×"
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                    lineNumber: 78,
                                    columnNumber: 492
                                }, this)
                            ]
                        }, u_0.id, true, {
                            fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                            lineNumber: 78,
                            columnNumber: 55
                        }, this)
                }["MemberSearch[selectedUsers.map()]"])
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 77,
                columnNumber: 40
            }, this);
            $[21] = onRemove;
            $[22] = ownerId;
            $[23] = selectedUsers;
            $[24] = t8;
        } else {
            t8 = $[24];
        }
        t3 = "relative";
        let t11;
        if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
            t11 = ({
                "MemberSearch[<button>.onClick]": ()=>setIsOpen(_MemberSearchButtonOnClickSetIsOpen)
            })["MemberSearch[<button>.onClick]"];
            $[25] = t11;
        } else {
            t11 = $[25];
        }
        let t12;
        if ($[26] !== buttonLabel) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-text-secondary",
                children: buttonLabel
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 101,
                columnNumber: 13
            }, this);
            $[26] = buttonLabel;
            $[27] = t12;
        } else {
            t12 = $[27];
        }
        const t13 = `h-6 w-6 text-btn-black transition-transform ${isOpen ? "rotate-180" : ""}`;
        let t14;
        if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
            t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M5 8l5 5 5-5"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 110,
                columnNumber: 13
            }, this);
            $[28] = t14;
        } else {
            t14 = $[28];
        }
        let t15;
        if ($[29] !== t13) {
            t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: t13,
                viewBox: "0 0 20 20",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: 1.5,
                children: t14
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 117,
                columnNumber: 13
            }, this);
            $[29] = t13;
            $[30] = t15;
        } else {
            t15 = $[30];
        }
        if ($[31] !== t12 || $[32] !== t15) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: t11,
                className: "w-full h-13.25 flex items-center justify-between border border-system-neutral rounded-[8px] px-4 py-3 text-sm bg-bg-content transition",
                children: [
                    t12,
                    t15
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 124,
                columnNumber: 12
            }, this);
            $[31] = t12;
            $[32] = t15;
            $[33] = t4;
        } else {
            t4 = $[33];
        }
        t5 = isOpen && availableUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-full left-0 right-0 z-20 bg-bg-content border border-system-neutral rounded-[8px] shadow-modal mt-1 overflow-hidden max-h-48 overflow-y-auto",
            children: availableUsers.map({
                "MemberSearch[availableUsers.map()]": (u_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: {
                            "MemberSearch[availableUsers.map() > <button>.onClick]": ()=>handleAdd(u_1)
                        }["MemberSearch[availableUsers.map() > <button>.onClick]"],
                        className: "w-full flex items-center gap-2 px-4 py-2 text-sm text-text-secondary hover:bg-bg-grey-light transition",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${u_1.id === ownerId ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `text-[9px] font-semibold ${u_1.id === ownerId ? "text-text-primary" : "text-text-secondary"}`,
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(u_1.name)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                    lineNumber: 134,
                                    columnNumber: 329
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                lineNumber: 134,
                                columnNumber: 184
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `px-2 py-0.5 rounded-full text-sm ${u_1.id === ownerId ? "bg-brand-light text-text-primary" : "bg-bg-grey-border text-text-secondary"}`,
                                children: u_1.name
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                lineNumber: 134,
                                columnNumber: 478
                            }, this)
                        ]
                    }, u_1.id, true, {
                        fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                        lineNumber: 132,
                        columnNumber: 54
                    }, this)
            }["MemberSearch[availableUsers.map()]"])
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
            lineNumber: 131,
            columnNumber: 49
        }, this);
        $[1] = buttonLabel;
        $[2] = isOpen;
        $[3] = label;
        $[4] = onAdd;
        $[5] = onRemove;
        $[6] = ownerId;
        $[7] = selectedUsers;
        $[8] = users;
        $[9] = t3;
        $[10] = t4;
        $[11] = t5;
        $[12] = t6;
        $[13] = t7;
        $[14] = t8;
    } else {
        t3 = $[9];
        t4 = $[10];
        t5 = $[11];
        t6 = $[12];
        t7 = $[13];
        t8 = $[14];
    }
    let t9;
    if ($[34] !== t3 || $[35] !== t4 || $[36] !== t5) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t3,
            children: [
                t4,
                t5
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
            lineNumber: 160,
            columnNumber: 10
        }, this);
        $[34] = t3;
        $[35] = t4;
        $[36] = t5;
        $[37] = t9;
    } else {
        t9 = $[37];
    }
    let t10;
    if ($[38] !== t6 || $[39] !== t7 || $[40] !== t8 || $[41] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t6,
            children: [
                t7,
                t8,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
            lineNumber: 170,
            columnNumber: 11
        }, this);
        $[38] = t6;
        $[39] = t7;
        $[40] = t8;
        $[41] = t9;
        $[42] = t10;
    } else {
        t10 = $[42];
    }
    return t10;
}
_s(MemberSearch, "+sus0Lb0ewKHdwiUhiTAJFoFyQ0=");
_c = MemberSearch;
function _MemberSearchButtonOnClickSetIsOpen(v) {
    return !v;
}
var _c;
__turbopack_context__.k.register(_c, "MemberSearch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/forms/TaskForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TaskForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$MemberSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/MemberSearch.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/task.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const statusOptions = Object.entries(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusLabel"]).filter(([value])=>value !== "CANCELLED");
function TaskForm(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(65);
    if ($[0] !== "8dd8dc45518a97980f9a35f173cf9d8c4dd6c129208b5da6dc648fcf13ebf169") {
        for(let $i = 0; $i < 65; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8dd8dc45518a97980f9a35f173cf9d8c4dd6c129208b5da6dc648fcf13ebf169";
    }
    const { initialTask, members, ownerId, submitLabel, loading, error, onSubmit } = t0;
    const [title, setTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialTask?.title ?? "");
    const [description, setDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialTask?.description ?? "");
    let t1;
    if ($[1] !== initialTask) {
        t1 = initialTask?.dueDate ? initialTask.dueDate.split("T")[0] : "";
        $[1] = initialTask;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [dueDate, setDueDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialTask?.status ?? "TODO");
    const [priority, setPriority] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialTask?.priority ?? "MEDIUM");
    let t2;
    if ($[3] !== initialTask?.assignees) {
        t2 = initialTask?.assignees?.map(_TaskFormAnonymous) ?? [];
        $[3] = initialTask?.assignees;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const [selectedAssignees, setSelectedAssignees] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    if ($[5] !== description || $[6] !== dueDate || $[7] !== onSubmit || $[8] !== priority || $[9] !== selectedAssignees || $[10] !== status || $[11] !== title) {
        t3 = async function handleSubmit(e) {
            e.preventDefault();
            await onSubmit(title, description, dueDate, selectedAssignees.map(_TaskFormHandleSubmitSelectedAssigneesMap), status, priority);
        };
        $[5] = description;
        $[6] = dueDate;
        $[7] = onSubmit;
        $[8] = priority;
        $[9] = selectedAssignees;
        $[10] = status;
        $[11] = title;
        $[12] = t3;
    } else {
        t3 = $[12];
    }
    const handleSubmit = t3;
    let t4;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "text-sm text-text-primary",
            children: "Titre *"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 77,
            columnNumber: 10
        }, this);
        $[13] = t4;
    } else {
        t4 = $[13];
    }
    let t5;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "TaskForm[<input>.onChange]": (e_0)=>setTitle(e_0.target.value)
        })["TaskForm[<input>.onChange]"];
        $[14] = t5;
    } else {
        t5 = $[14];
    }
    let t6;
    if ($[15] !== title) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t4,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    "aria-label": "Titre de la t\xE2che",
                    type: "text",
                    value: title,
                    onChange: t5,
                    className: "h-13.25 border border-system-neutral rounded-sm px-4 py-3",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 93,
                    columnNumber: 51
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 93,
            columnNumber: 10
        }, this);
        $[15] = title;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    let t7;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "text-sm text-text-primary",
            children: "Description *"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 101,
            columnNumber: 10
        }, this);
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    let t8;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = ({
            "TaskForm[<textarea>.onChange]": (e_1)=>setDescription(e_1.target.value)
        })["TaskForm[<textarea>.onChange]"];
        $[18] = t8;
    } else {
        t8 = $[18];
    }
    let t9;
    if ($[19] !== description) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t7,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                    "aria-label": "Description de la t\xE2che",
                    value: description,
                    onChange: t8,
                    className: "h-13.25 border border-system-neutral rounded-sm px-4 py-3 resize-none",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 117,
                    columnNumber: 51
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 117,
            columnNumber: 10
        }, this);
        $[19] = description;
        $[20] = t9;
    } else {
        t9 = $[20];
    }
    let t10;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "text-sm text-text-primary",
            children: "Échéance *"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 125,
            columnNumber: 11
        }, this);
        $[21] = t10;
    } else {
        t10 = $[21];
    }
    let t11;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = ({
            "TaskForm[<input>.onChange]": (e_2)=>setDueDate(e_2.target.value)
        })["TaskForm[<input>.onChange]"];
        $[22] = t11;
    } else {
        t11 = $[22];
    }
    let t12;
    if ($[23] !== dueDate) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t10,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    "aria-label": "Date d'\xE9ch\xE9ance",
                    type: "date",
                    value: dueDate,
                    onChange: t11,
                    className: "h-13.25 border border-system-neutral rounded-sm px-4 py-3",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 141,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 141,
            columnNumber: 11
        }, this);
        $[23] = dueDate;
        $[24] = t12;
    } else {
        t12 = $[24];
    }
    let t13;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-sm text-text-primary",
            children: "Assigné à"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 149,
            columnNumber: 11
        }, this);
        $[25] = t13;
    } else {
        t13 = $[25];
    }
    let t14;
    if ($[26] !== members) {
        t14 = members.map(_TaskFormMembersMap);
        $[26] = members;
        $[27] = t14;
    } else {
        t14 = $[27];
    }
    let t15;
    let t16;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = ({
            "TaskForm[<MemberSearch>.onAdd]": (u_0)=>setSelectedAssignees({
                    "TaskForm[<MemberSearch>.onAdd > setSelectedAssignees()]": (prev)=>[
                            ...prev,
                            u_0
                        ]
                }["TaskForm[<MemberSearch>.onAdd > setSelectedAssignees()]"])
        })["TaskForm[<MemberSearch>.onAdd]"];
        t16 = ({
            "TaskForm[<MemberSearch>.onRemove]": (id)=>setSelectedAssignees({
                    "TaskForm[<MemberSearch>.onRemove > setSelectedAssignees()]": (prev_0)=>prev_0.filter({
                            "TaskForm[<MemberSearch>.onRemove > setSelectedAssignees() > prev_0.filter()]": (u_1)=>u_1.id !== id
                        }["TaskForm[<MemberSearch>.onRemove > setSelectedAssignees() > prev_0.filter()]"])
                }["TaskForm[<MemberSearch>.onRemove > setSelectedAssignees()]"])
        })["TaskForm[<MemberSearch>.onRemove]"];
        $[28] = t15;
        $[29] = t16;
    } else {
        t15 = $[28];
        t16 = $[29];
    }
    const t17 = selectedAssignees.length > 0 ? `${selectedAssignees.length} assigné(s)` : "Choisir des assign\xE9s";
    let t18;
    if ($[30] !== ownerId || $[31] !== selectedAssignees || $[32] !== t14 || $[33] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t13,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$MemberSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    users: t14,
                    selectedUsers: selectedAssignees,
                    onAdd: t15,
                    onRemove: t16,
                    ownerId: ownerId,
                    buttonLabel: t17
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 186,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        $[30] = ownerId;
        $[31] = selectedAssignees;
        $[32] = t14;
        $[33] = t17;
        $[34] = t18;
    } else {
        t18 = $[34];
    }
    let t19;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-sm text-text-primary",
            children: "Statut"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 197,
            columnNumber: 11
        }, this);
        $[35] = t19;
    } else {
        t19 = $[35];
    }
    let t20;
    if ($[36] !== status) {
        t20 = statusOptions.map({
            "TaskForm[statusOptions.map()]": (t21)=>{
                const [value, label] = t21;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    onClick: {
                        "TaskForm[statusOptions.map() > <button>.onClick]": ()=>setStatus(value)
                    }["TaskForm[statusOptions.map() > <button>.onClick]"],
                    className: `px-3 py-1.5 rounded-full text-xs ${status === value ? "bg-system-info text-text-info" : __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusColor"][value]}`,
                    children: label
                }, value, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 207,
                    columnNumber: 16
                }, this);
            }
        }["TaskForm[statusOptions.map()]"]);
        $[36] = status;
        $[37] = t20;
    } else {
        t20 = $[37];
    }
    let t21;
    if ($[38] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t19,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2 flex-wrap",
                    children: t20
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 219,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 219,
            columnNumber: 11
        }, this);
        $[38] = t20;
        $[39] = t21;
    } else {
        t21 = $[39];
    }
    let t22;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-sm text-text-primary",
            children: "Priorité"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 227,
            columnNumber: 11
        }, this);
        $[40] = t22;
    } else {
        t22 = $[40];
    }
    let t23;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = ({
            "TaskForm[<select>.onChange]": (e_3)=>setPriority(e_3.target.value)
        })["TaskForm[<select>.onChange]"];
        $[41] = t23;
    } else {
        t23 = $[41];
    }
    let t24;
    let t25;
    let t26;
    let t27;
    if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "URGENT",
            children: "Urgente"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 246,
            columnNumber: 11
        }, this);
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "HIGH",
            children: "Haute"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 247,
            columnNumber: 11
        }, this);
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "MEDIUM",
            children: "Moyenne"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 248,
            columnNumber: 11
        }, this);
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "LOW",
            children: "Basse"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 249,
            columnNumber: 11
        }, this);
        $[42] = t24;
        $[43] = t25;
        $[44] = t26;
        $[45] = t27;
    } else {
        t24 = $[42];
        t25 = $[43];
        t26 = $[44];
        t27 = $[45];
    }
    let t28;
    if ($[46] !== priority) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t22,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                    id: "task-priority",
                    "aria-label": "S\xE9lectionner la priorit\xE9",
                    value: priority,
                    onChange: t23,
                    className: "h-13.25 border border-system-neutral rounded-sm px-4 py-3",
                    children: [
                        t24,
                        t25,
                        t26,
                        t27
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 262,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 262,
            columnNumber: 11
        }, this);
        $[46] = priority;
        $[47] = t28;
    } else {
        t28 = $[47];
    }
    let t29;
    if ($[48] !== error) {
        t29 = error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm text-text-error",
            children: error
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 270,
            columnNumber: 20
        }, this);
        $[48] = error;
        $[49] = t29;
    } else {
        t29 = $[49];
    }
    const t30 = loading || !title || !description || !dueDate;
    const t31 = loading ? "En cours..." : submitLabel;
    let t32;
    if ($[50] !== t30 || $[51] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            disabled: t30,
            className: "w-45.25 h-12.5 bg-system-neutral rounded-[8px]",
            children: t31
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 280,
            columnNumber: 11
        }, this);
        $[50] = t30;
        $[51] = t31;
        $[52] = t32;
    } else {
        t32 = $[52];
    }
    let t33;
    if ($[53] !== t12 || $[54] !== t18 || $[55] !== t21 || $[56] !== t28 || $[57] !== t29 || $[58] !== t32 || $[59] !== t6 || $[60] !== t9) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-113 h-133.75 mx-auto overflow-y-auto flex flex-col gap-4 pr-1",
            children: [
                t6,
                t9,
                t12,
                t18,
                t21,
                t28,
                t29,
                t32
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 289,
            columnNumber: 11
        }, this);
        $[53] = t12;
        $[54] = t18;
        $[55] = t21;
        $[56] = t28;
        $[57] = t29;
        $[58] = t32;
        $[59] = t6;
        $[60] = t9;
        $[61] = t33;
    } else {
        t33 = $[61];
    }
    let t34;
    if ($[62] !== handleSubmit || $[63] !== t33) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: handleSubmit,
            className: "flex flex-col gap-4",
            noValidate: true,
            children: t33
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 304,
            columnNumber: 11
        }, this);
        $[62] = handleSubmit;
        $[63] = t33;
        $[64] = t34;
    } else {
        t34 = $[64];
    }
    return t34;
}
_s(TaskForm, "3ISWg/sS3/yAfBb7nnSeLMOyYCE=");
_c = TaskForm;
function _TaskFormMembersMap(m) {
    return m.user;
}
function _TaskFormHandleSubmitSelectedAssigneesMap(u) {
    return u.id;
}
function _TaskFormAnonymous(a) {
    return a.user;
}
var _c;
__turbopack_context__.k.register(_c, "TaskForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/CreateTaskModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CreateTaskModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/BaseModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$TaskForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/forms/TaskForm.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function CreateTaskModal({ members, initialTask, ownerId, onClose, onSubmit }) {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    async function handleSubmit(title, description, dueDate, assigneeIds, status, priority) {
        setError(null);
        setLoading(true);
        try {
            const isoDate = dueDate && dueDate.trim() !== "" ? new Date(dueDate).toISOString() : null;
            await onSubmit(title, description, isoDate, assigneeIds, status, priority);
            onClose();
        } catch (err) {
            setError(err instanceof Error ? err.message : "Une erreur est survenue");
        } finally{
            setLoading(false);
        }
    }
    const isEdit = !!initialTask;
    console.log("🟢 MODALE CRÉATION OUVERTE — Données :", {
        mode: "create",
        initialTask: null
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        id: "task-modal-title",
        title: isEdit ? "Modifier" : "Créer une tâche",
        onClose: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$TaskForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            members: members,
            initialTask: initialTask,
            ownerId: ownerId,
            submitLabel: isEdit ? "Enregistrer" : "+ Ajouter une tâche",
            loading: loading,
            error: error,
            onSubmit: handleSubmit
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/CreateTaskModal.tsx",
            lineNumber: 42,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/frontend/src/components/modals/CreateTaskModal.tsx",
        lineNumber: 41,
        columnNumber: 10
    }, this);
}
_s(CreateTaskModal, "Iz3ozxQ+abMaAIcGIvU8cKUcBeo=");
_c = CreateTaskModal;
var _c;
__turbopack_context__.k.register(_c, "CreateTaskModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/EditTaskModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EditTaskModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/BaseModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$TaskForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/forms/TaskForm.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function EditTaskModal({ task, members, ownerId, onClose, onSubmit }) {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    async function handleSubmit(title, description, dueDate, assigneeIds, status, priority) {
        setError(null);
        setLoading(true);
        try {
            const isoDate = dueDate && dueDate.trim() !== "" ? new Date(dueDate).toISOString() : null;
            await onSubmit(title, description, isoDate, assigneeIds, status, priority);
            onClose();
        } catch (err) {
            setError(err instanceof Error ? err.message : "Une erreur est survenue");
        } finally{
            setLoading(false);
        }
    }
    console.log("🟢 MODALE OUVERTE — Données de la tâche :", {
        id: task.id,
        title: task.title,
        description: task.description,
        dueDate: task.dueDate,
        status: task.status,
        priority: task.priority,
        assignees: task.assignees?.map((a)=>a.user.name)
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        id: "edit-task-modal-title",
        title: "Modifier la tâche",
        onClose: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$TaskForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            initialTask: task,
            members: members,
            ownerId: ownerId,
            submitLabel: "Enregistrer",
            loading: loading,
            error: error,
            onSubmit: handleSubmit
        }, task.id, false, {
            fileName: "[project]/frontend/src/components/modals/EditTaskModal.tsx",
            lineNumber: 47,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/frontend/src/components/modals/EditTaskModal.tsx",
        lineNumber: 45,
        columnNumber: 10
    }, this);
}
_s(EditTaskModal, "Iz3ozxQ+abMaAIcGIvU8cKUcBeo=");
_c = EditTaskModal;
var _c;
__turbopack_context__.k.register(_c, "EditTaskModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/forms/AIForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AIForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$PlusIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusIcon$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/@heroicons/react/24/outline/esm/PlusIcon.js [app-client] (ecmascript) <export default as PlusIcon>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function AIForm({ onTasksGenerated }) {
    _s();
    const [prompt, setPrompt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [generating, setGenerating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const promptRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    async function handleGenerate() {
        if (!prompt.trim()) return;
        setGenerating(true);
        setError(null);
        try {
            const response = await fetch("/api/generate-tasks", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    prompt
                })
            });
            if (!response.ok) {
                throw new Error("Erreur lors de la génération");
            }
            const data = await response.json();
            if (!data.success || !data.tasks) {
                throw new Error("Format de réponse invalide");
            }
            const withIds = data.tasks.map((t, i)=>({
                    ...t,
                    id: `ai-${Date.now()}-${i}`
                }));
            onTasksGenerated(withIds);
            setPrompt("");
        } catch  {
            setError("Erreur lors de la génération. Vérifiez votre prompt et réessayez.");
        } finally{
            setGenerating(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2 items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        id: "ai-prompt",
                        ref: promptRef,
                        value: prompt,
                        onChange: (e)=>setPrompt(e.target.value),
                        className: "flex-1 h-15 border border-system-neutral px-4 py-5 text-[10px] text-police-black bg-bg-dashboard transition resize-none",
                        placeholder: "Décrivez les tâches que vous souhaitez ajouter",
                        rows: 3
                    }, void 0, false, {
                        fileName: "[project]/frontend/src/components/forms/AIForm.tsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleGenerate,
                        disabled: generating || !prompt.trim(),
                        className: "shrink-0 w-10 h-10 rounded-full bg-brand-dark text-text-white flex items-center justify-center hover:bg-brand-light hover:text-brand-dark transition",
                        "aria-label": "Générer les tâches",
                        children: generating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs",
                            children: "..."
                        }, void 0, false, {
                            fileName: "[project]/frontend/src/components/forms/AIForm.tsx",
                            lineNumber: 59,
                            columnNumber: 25
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$PlusIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusIcon$3e$__["PlusIcon"], {
                            className: "h-4 w-4"
                        }, void 0, false, {
                            fileName: "[project]/frontend/src/components/forms/AIForm.tsx",
                            lineNumber: 59,
                            columnNumber: 64
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/frontend/src/components/forms/AIForm.tsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/forms/AIForm.tsx",
                lineNumber: 56,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                "aria-live": "assertive",
                className: "text-sm text-system-error",
                children: error
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/forms/AIForm.tsx",
                lineNumber: 63,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/frontend/src/components/forms/AIForm.tsx",
        lineNumber: 55,
        columnNumber: 10
    }, this);
}
_s(AIForm, "GDIaUnLd5d4RV3wzX6dyLMVTOLM=");
_c = AIForm;
var _c;
__turbopack_context__.k.register(_c, "AIForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/projects/IACard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>IACard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$solid$2f$esm$2f$TrashIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/@heroicons/react/24/solid/esm/TrashIcon.js [app-client] (ecmascript) <export default as TrashIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$solid$2f$esm$2f$PencilIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PencilIcon$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/@heroicons/react/24/solid/esm/PencilIcon.js [app-client] (ecmascript) <export default as PencilIcon>");
"use client";
;
;
;
function IACard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "f164c27aa2db470d1d8df21df8848757f9a5917eddaed49a78323ec530f79f52") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f164c27aa2db470d1d8df21df8848757f9a5917eddaed49a78323ec530f79f52";
    }
    const { task, isEditing, onEdit, onDelete, onUpdate, onSave } = t0;
    let t1;
    if ($[1] !== isEditing || $[2] !== onDelete || $[3] !== onEdit || $[4] !== onSave || $[5] !== onUpdate || $[6] !== task.description || $[7] !== task.priority || $[8] !== task.title) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-bg-content border border-bg-grey-border rounded-[10px] p-3 shadow-card px-8 py-3 flex flex-col mb-5",
            children: isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-2 h-full justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                value: task.title,
                                onChange: {
                                    "IACard[<input>.onChange]": (e)=>onUpdate("title", e.target.value)
                                }["IACard[<input>.onChange]"],
                                className: "border border-system-neutral rounded-[8px] px-3 py-1.5 text-sm text-text-primary bg-bg-content",
                                "aria-label": "Titre de la t\xE2che"
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                lineNumber: 38,
                                columnNumber: 240
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                value: task.description,
                                onChange: {
                                    "IACard[<textarea>.onChange]": (e_0)=>onUpdate("description", e_0.target.value)
                                }["IACard[<textarea>.onChange]"],
                                className: "border border-system-neutral rounded-[8px] px-3 py-1.5 text-sm text-text-primary bg-bg-content resize-none",
                                rows: 2,
                                "aria-label": "Description de la t\xE2che"
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                lineNumber: 40,
                                columnNumber: 187
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: task.priority,
                                onChange: {
                                    "IACard[<select>.onChange]": (e_1)=>onUpdate("priority", e_1.target.value)
                                }["IACard[<select>.onChange]"],
                                className: "border border-system-neutral rounded-[8px] px-3 py-1.5 text-sm text-text-primary bg-bg-content",
                                "aria-label": "Priorit\xE9 de la t\xE2che",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "LOW",
                                        children: "Basse"
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                        lineNumber: 44,
                                        columnNumber: 192
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "MEDIUM",
                                        children: "Moyenne"
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                        lineNumber: 44,
                                        columnNumber: 226
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "HIGH",
                                        children: "Haute"
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                        lineNumber: 44,
                                        columnNumber: 265
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "URGENT",
                                        children: "Urgente"
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                        lineNumber: 44,
                                        columnNumber: 300
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                lineNumber: 42,
                                columnNumber: 217
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                        lineNumber: 38,
                        columnNumber: 203
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onSave,
                        className: "self-end text-xs text-brand-dark hover:underline",
                        children: "Valider"
                    }, void 0, false, {
                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                        lineNumber: 44,
                        columnNumber: 354
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                lineNumber: 38,
                columnNumber: 143
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-5 h-full",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-.5 flex-1 mt-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-[18px] font-semibold text-police-black",
                                children: task.title
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                lineNumber: 44,
                                columnNumber: 573
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-[14px] text-text-secondary line-clamp-3",
                                children: task.description
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                lineNumber: 44,
                                columnNumber: 650
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                        lineNumber: 44,
                        columnNumber: 523
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 mb-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: onDelete,
                                className: "flex items-center gap-1 text-text-secondary hover:text-brand-dark transition",
                                "aria-label": `Supprimer la tâche ${task.title}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$solid$2f$esm$2f$TrashIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__["TrashIcon"], {
                                        className: "h-4w w-4"
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                        lineNumber: 44,
                                        columnNumber: 962
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs",
                                        children: "Supprimer"
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                        lineNumber: 44,
                                        columnNumber: 996
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                lineNumber: 44,
                                columnNumber: 784
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-px h-2 bg-text-secondary"
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                lineNumber: 44,
                                columnNumber: 1047
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: onEdit,
                                className: "flex items-center gap-1 text-text-secondary hover:text-brand-dark transition",
                                "aria-label": `Modifier la tâche ${task.title}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$solid$2f$esm$2f$PencilIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PencilIcon$3e$__["PencilIcon"], {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                        lineNumber: 44,
                                        columnNumber: 1268
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs",
                                        children: "Modifier"
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                        lineNumber: 44,
                                        columnNumber: 1302
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                                lineNumber: 44,
                                columnNumber: 1093
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                        lineNumber: 44,
                        columnNumber: 738
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/projects/IACard.tsx",
                lineNumber: 44,
                columnNumber: 479
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/projects/IACard.tsx",
            lineNumber: 38,
            columnNumber: 10
        }, this);
        $[1] = isEditing;
        $[2] = onDelete;
        $[3] = onEdit;
        $[4] = onSave;
        $[5] = onUpdate;
        $[6] = task.description;
        $[7] = task.priority;
        $[8] = task.title;
        $[9] = t1;
    } else {
        t1 = $[9];
    }
    return t1;
}
_c = IACard;
var _c;
__turbopack_context__.k.register(_c, "IACard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/AITaskListModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AITaskListModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/BaseModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$AIForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/forms/AIForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$projects$2f$IACard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/projects/IACard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$IAIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/IAIcon.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function AITaskListModal({ tasks, onClose, onSubmit, onTasksUpdate }) {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editingId, setEditingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    function removeTask(id) {
        onTasksUpdate(tasks.filter((t)=>t.id !== id));
    }
    function updateTask(id_0, field, value) {
        onTasksUpdate(tasks.map((t_0)=>t_0.id === id_0 ? {
                ...t_0,
                [field]: value
            } : t_0));
    }
    function handleTasksGenerated(newTasks) {
        onTasksUpdate([
            ...tasks,
            ...newTasks
        ]);
    }
    async function handleSubmit() {
        if (tasks.length === 0) return;
        setLoading(true);
        setError(null);
        try {
            await onSubmit(tasks);
        } catch (err) {
            if (err instanceof Error) setError(err.message);
            else setError("Une erreur est survenue");
        } finally{
            setLoading(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        id: "task-list-modal-title",
        title: "Vos tâches",
        onClose: onClose,
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$IAIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: "text-brand-dark"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/AITaskListModal.tsx",
            lineNumber: 54,
            columnNumber: 91
        }, void 0),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-113 mx-auto",
            children: [
                tasks.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col h-133.75 overflow-y-auto p-4",
                    "aria-label": "Tâches générées",
                    children: tasks.map((task)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$projects$2f$IACard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            task: task,
                            isEditing: editingId === task.id,
                            onEdit: ()=>setEditingId(task.id),
                            onDelete: ()=>removeTask(task.id),
                            onUpdate: (field_0, value_0)=>updateTask(task.id, field_0, value_0),
                            onSave: ()=>setEditingId(null)
                        }, task.id, false, {
                            fileName: "[project]/frontend/src/components/modals/AITaskListModal.tsx",
                            lineNumber: 58,
                            columnNumber: 36
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/modals/AITaskListModal.tsx",
                    lineNumber: 57,
                    columnNumber: 34
                }, this),
                tasks.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
                            "aria-hidden": "true",
                            className: "my-4"
                        }, void 0, false, {
                            fileName: "[project]/frontend/src/components/modals/AITaskListModal.tsx",
                            lineNumber: 63,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: handleSubmit,
                            disabled: loading,
                            className: "w-45.25 h-12.5 mx-auto mb-5 bg-btn-black text-text-white text-base  rounded-[10px] flex items-center justify-center gap-2 hover:border border-brand-dark hover:bg-bg-content hover:text-brand-dark transition ",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-lg leading-none",
                                    children: "+"
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/modals/AITaskListModal.tsx",
                                    lineNumber: 65,
                                    columnNumber: 17
                                }, this),
                                loading ? "Ajout en cours..." : "Ajouter les tâches"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/frontend/src/components/modals/AITaskListModal.tsx",
                            lineNumber: 64,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$AIForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    onTasksGenerated: handleTasksGenerated
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/modals/AITaskListModal.tsx",
                    lineNumber: 71,
                    columnNumber: 13
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    "aria-live": "assertive",
                    className: "text-sm text-text-error mt-4",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/modals/AITaskListModal.tsx",
                    lineNumber: 74,
                    columnNumber: 23
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/modals/AITaskListModal.tsx",
            lineNumber: 55,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/frontend/src/components/modals/AITaskListModal.tsx",
        lineNumber: 54,
        columnNumber: 10
    }, this);
}
_s(AITaskListModal, "XAziOiDcfDWwhuazUeoM3St+SZE=");
_c = AITaskListModal;
var _c;
__turbopack_context__.k.register(_c, "AITaskListModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/AITaskModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AITaskModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/BaseModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$AIForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/forms/AIForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$AITaskListModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/AITaskListModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$IAIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/IAIcon.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function AITaskModal(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "c21bcac0cdf3c59f35a533164727c5a0996c44f685f6f167f7a3e801ba44a0b8") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c21bcac0cdf3c59f35a533164727c5a0996c44f685f6f167f7a3e801ba44a0b8";
    }
    const { onClose, onSubmit } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const [generatedTasks, setGeneratedTasks] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    const [showTaskList, setShowTaskList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = function handleTasksGenerated(tasks) {
            setGeneratedTasks(tasks);
            setShowTaskList(true);
        };
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const handleTasksGenerated = t2;
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = function handleCloseTaskList() {
            setShowTaskList(false);
        };
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const handleCloseTaskList = t3;
    let t4;
    if ($[4] !== onClose || $[5] !== onSubmit) {
        t4 = async function handleSubmitTasks(tasks_0) {
            await onSubmit(tasks_0);
            setShowTaskList(false);
            onClose();
        };
        $[4] = onClose;
        $[5] = onSubmit;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const handleSubmitTasks = t4;
    let t5;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$IAIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: "text-brand-dark"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/AITaskModal.tsx",
            lineNumber: 78,
            columnNumber: 10
        }, this);
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-115"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/AITaskModal.tsx",
            lineNumber: 85,
            columnNumber: 10
        }, this);
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-113 h-133.75 mx-auto flex flex-col",
            children: [
                t6,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-15",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$AIForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onTasksGenerated: handleTasksGenerated
                    }, void 0, false, {
                        fileName: "[project]/frontend/src/components/modals/AITaskModal.tsx",
                        lineNumber: 92,
                        columnNumber: 91
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/modals/AITaskModal.tsx",
                    lineNumber: 92,
                    columnNumber: 68
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/modals/AITaskModal.tsx",
            lineNumber: 92,
            columnNumber: 10
        }, this);
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] !== onClose) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            id: "ai-modal-title",
            title: "Cr\xE9er une t\xE2che",
            onClose: onClose,
            icon: t5,
            children: t7
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/AITaskModal.tsx",
            lineNumber: 99,
            columnNumber: 10
        }, this);
        $[10] = onClose;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== generatedTasks || $[13] !== handleSubmitTasks || $[14] !== showTaskList) {
        t9 = showTaskList && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$AITaskListModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            tasks: generatedTasks,
            onClose: handleCloseTaskList,
            onSubmit: handleSubmitTasks,
            onTasksUpdate: setGeneratedTasks
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/AITaskModal.tsx",
            lineNumber: 107,
            columnNumber: 26
        }, this);
        $[12] = generatedTasks;
        $[13] = handleSubmitTasks;
        $[14] = showTaskList;
        $[15] = t9;
    } else {
        t9 = $[15];
    }
    let t10;
    if ($[16] !== t8 || $[17] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t8,
                t9
            ]
        }, void 0, true);
        $[16] = t8;
        $[17] = t9;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    return t10;
}
_s(AITaskModal, "SbYleiYe13Lym7FwK06Y4Oc35mY=");
_c = AITaskModal;
var _c;
__turbopack_context__.k.register(_c, "AITaskModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/app/dashboard/projects/[id]/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectDetailPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useProjects.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProject$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useProject.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useAuth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useModal.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$project$2f$ProjectHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/project/ProjectHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$project$2f$ProjectFilters$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/project/ProjectFilters.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$project$2f$ProjectTaskList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/project/ProjectTaskList.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$EditProjectModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/EditProjectModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$CreateTaskModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/CreateTaskModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$EditTaskModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/EditTaskModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$AITaskModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/AITaskModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function ProjectDetailPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(96);
    if ($[0] !== "094365c1c0281a81c7cc12e205bbaf4b17d7cf162cd1e214618e2c8d501afc66") {
        for(let $i = 0; $i < 96; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "094365c1c0281a81c7cc12e205bbaf4b17d7cf162cd1e214618e2c8d501afc66";
    }
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const { project, loading, error, fetchProject, updateProject, addContributor, removeContributor, createTask, updateTask, deleteTask } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProject$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProject"])(id);
    const { deleteProject } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjects"])();
    const { isOpen, openModal, closeModal } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModal"])();
    const [view, setView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("list");
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [filterStatus, setFilterStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("ALL");
    const [editingTask, setEditingTask] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t0;
    let t1;
    if ($[1] !== fetchProject) {
        t0 = ({
            "ProjectDetailPage[useEffect()]": ()=>{
                fetchProject();
            }
        })["ProjectDetailPage[useEffect()]"];
        t1 = [
            fetchProject
        ];
        $[1] = fetchProject;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    if (loading) {
        let t2;
        if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "status",
                "aria-live": "polite",
                className: "text-sm text-text-secondary",
                children: "Chargement du projet..."
            }, void 0, false, {
                fileName: "[project]/frontend/src/app/dashboard/projects/[id]/page.tsx",
                lineNumber: 78,
                columnNumber: 12
            }, this);
            $[4] = t2;
        } else {
            t2 = $[4];
        }
        return t2;
    }
    if (error || !project) {
        const t2 = error ?? "Projet introuvable.";
        let t3;
        if ($[5] !== t2) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                "aria-live": "assertive",
                className: "text-sm text-system-error",
                children: t2
            }, void 0, false, {
                fileName: "[project]/frontend/src/app/dashboard/projects/[id]/page.tsx",
                lineNumber: 89,
                columnNumber: 12
            }, this);
            $[5] = t2;
            $[6] = t3;
        } else {
            t3 = $[6];
        }
        return t3;
    }
    const isOwner = project.owner.id === user?.id;
    let t2;
    if ($[7] !== project.members || $[8] !== project.owner.id) {
        t2 = project.members?.filter({
            "ProjectDetailPage[(anonymous)()]": (m)=>m.user.id !== project.owner.id
        }["ProjectDetailPage[(anonymous)()]"]).map(_ProjectDetailPageAnonymous) || [];
        $[7] = project.members;
        $[8] = project.owner.id;
        $[9] = t2;
    } else {
        t2 = $[9];
    }
    const projectContributors = t2;
    const totalContributors = 1 + projectContributors.length;
    let t3;
    if ($[10] !== filterStatus || $[11] !== project.tasks || $[12] !== search || $[13] !== view) {
        let t4;
        if ($[15] !== filterStatus || $[16] !== search) {
            t4 = ({
                "ProjectDetailPage[(anonymous)()]": (task)=>{
                    const matchSearch = task.title.toLowerCase().includes(search.toLowerCase()) || task.description?.toLowerCase().includes(search.toLowerCase());
                    const matchStatus = filterStatus === "ALL" || task.status === filterStatus;
                    return matchSearch && matchStatus;
                }
            })["ProjectDetailPage[(anonymous)()]"];
            $[15] = filterStatus;
            $[16] = search;
            $[17] = t4;
        } else {
            t4 = $[17];
        }
        let t5;
        if ($[18] !== view) {
            t5 = ({
                "ProjectDetailPage[(anonymous)()]": (a, b)=>view === "calendar" ? new Date(a.dueDate ?? "").getTime() - new Date(b.dueDate ?? "").getTime() : a.priority.localeCompare(b.priority)
            })["ProjectDetailPage[(anonymous)()]"];
            $[18] = view;
            $[19] = t5;
        } else {
            t5 = $[19];
        }
        t3 = (project.tasks ?? []).filter(t4).sort(t5);
        $[10] = filterStatus;
        $[11] = project.tasks;
        $[12] = search;
        $[13] = view;
        $[14] = t3;
    } else {
        t3 = $[14];
    }
    const filteredTasks = t3;
    let t4;
    if ($[20] !== createTask) {
        t4 = async function handleAISubmit(aiTasks) {
            await Promise.all(aiTasks.map({
                "ProjectDetailPage[handleAISubmit > aiTasks.map()]": (t)=>createTask(t.title, t.description, "", [], "TODO", t.priority)
            }["ProjectDetailPage[handleAISubmit > aiTasks.map()]"]));
        };
        $[20] = createTask;
        $[21] = t4;
    } else {
        t4 = $[21];
    }
    const handleAISubmit = t4;
    let t5;
    if ($[22] !== closeModal || $[23] !== editingTask || $[24] !== updateTask) {
        t5 = async function handleUpdateTask(title, description, dueDate, assigneeIds, status, priority) {
            if (!editingTask) {
                return;
            }
            await updateTask(editingTask.id, {
                title,
                description,
                dueDate: dueDate ?? undefined,
                assigneeIds,
                status,
                priority
            });
            closeModal();
            setEditingTask(null);
        };
        $[22] = closeModal;
        $[23] = editingTask;
        $[24] = updateTask;
        $[25] = t5;
    } else {
        t5 = $[25];
    }
    const handleUpdateTask = t5;
    let t6;
    if ($[26] !== router) {
        t6 = ({
            "ProjectDetailPage[<ProjectHeader>.onBack]": ()=>router.push("/dashboard/projects")
        })["ProjectDetailPage[<ProjectHeader>.onBack]"];
        $[26] = router;
        $[27] = t6;
    } else {
        t6 = $[27];
    }
    let t7;
    let t8;
    let t9;
    if ($[28] !== openModal) {
        t7 = ({
            "ProjectDetailPage[<ProjectHeader>.onEditProject]": ()=>openModal("editProject")
        })["ProjectDetailPage[<ProjectHeader>.onEditProject]"];
        t8 = ({
            "ProjectDetailPage[<ProjectHeader>.onCreateTask]": ()=>openModal("createTask")
        })["ProjectDetailPage[<ProjectHeader>.onCreateTask]"];
        t9 = ({
            "ProjectDetailPage[<ProjectHeader>.onCreateAITask]": ()=>openModal("aiTask")
        })["ProjectDetailPage[<ProjectHeader>.onCreateAITask]"];
        $[28] = openModal;
        $[29] = t7;
        $[30] = t8;
        $[31] = t9;
    } else {
        t7 = $[29];
        t8 = $[30];
        t9 = $[31];
    }
    let t10;
    if ($[32] !== isOwner || $[33] !== project || $[34] !== t6 || $[35] !== t7 || $[36] !== t8 || $[37] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$project$2f$ProjectHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            project: project,
            isOwner: isOwner,
            onBack: t6,
            onEditProject: t7,
            onCreateTask: t8,
            onCreateAITask: t9
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/[id]/page.tsx",
            lineNumber: 220,
            columnNumber: 11
        }, this);
        $[32] = isOwner;
        $[33] = project;
        $[34] = t6;
        $[35] = t7;
        $[36] = t8;
        $[37] = t9;
        $[38] = t10;
    } else {
        t10 = $[38];
    }
    let t11;
    if ($[39] !== filterStatus || $[40] !== search || $[41] !== view) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$project$2f$ProjectFilters$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            view: view,
            setView: setView,
            filterStatus: filterStatus,
            setFilterStatus: setFilterStatus,
            search: search,
            setSearch: setSearch
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/[id]/page.tsx",
            lineNumber: 233,
            columnNumber: 11
        }, this);
        $[39] = filterStatus;
        $[40] = search;
        $[41] = view;
        $[42] = t11;
    } else {
        t11 = $[42];
    }
    let t12;
    if ($[43] !== openModal || $[44] !== project.tasks) {
        t12 = ({
            "ProjectDetailPage[<ProjectTaskList>.onEditTask]": (t_0)=>{
                const fullTask = project.tasks.find({
                    "ProjectDetailPage[<ProjectTaskList>.onEditTask > project.tasks.find()]": (task_0)=>task_0.id === t_0.id
                }["ProjectDetailPage[<ProjectTaskList>.onEditTask > project.tasks.find()]"]);
                setEditingTask(fullTask || t_0);
                openModal("editTask");
            }
        })["ProjectDetailPage[<ProjectTaskList>.onEditTask]"];
        $[43] = openModal;
        $[44] = project.tasks;
        $[45] = t12;
    } else {
        t12 = $[45];
    }
    let t13;
    if ($[46] !== updateTask) {
        t13 = ({
            "ProjectDetailPage[<ProjectTaskList>.onStatusChange]": (taskId, status_0)=>updateTask(taskId, {
                    status: status_0
                })
        })["ProjectDetailPage[<ProjectTaskList>.onStatusChange]"];
        $[46] = updateTask;
        $[47] = t13;
    } else {
        t13 = $[47];
    }
    let t14;
    if ($[48] !== deleteTask || $[49] !== fetchProject || $[50] !== filteredTasks || $[51] !== project.owner.id || $[52] !== t12 || $[53] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$project$2f$ProjectTaskList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            tasks: filteredTasks,
            ownerId: project.owner.id,
            onEditTask: t12,
            onDeleteTask: deleteTask,
            onStatusChange: t13,
            onRefresh: fetchProject
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/[id]/page.tsx",
            lineNumber: 272,
            columnNumber: 11
        }, this);
        $[48] = deleteTask;
        $[49] = fetchProject;
        $[50] = filteredTasks;
        $[51] = project.owner.id;
        $[52] = t12;
        $[53] = t13;
        $[54] = t14;
    } else {
        t14 = $[54];
    }
    let t15;
    if ($[55] !== addContributor || $[56] !== closeModal || $[57] !== deleteProject || $[58] !== fetchProject || $[59] !== id || $[60] !== isOpen || $[61] !== project.description || $[62] !== project.members || $[63] !== project.name || $[64] !== project.owner.id || $[65] !== projectContributors || $[66] !== removeContributor || $[67] !== router || $[68] !== totalContributors || $[69] !== updateProject) {
        t15 = isOpen("editProject") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$EditProjectModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            projectId: id,
            initialName: project.name,
            initialDescription: project.description ?? "",
            initialMembers: project.members,
            ownerId: project.owner.id,
            projectContributors: projectContributors,
            totalContributors: totalContributors,
            onClose: closeModal,
            onSubmit: {
                "ProjectDetailPage[<EditProjectModal>.onSubmit]": async (projectId, name, description_0)=>{
                    await updateProject(projectId, name, description_0);
                }
            }["ProjectDetailPage[<EditProjectModal>.onSubmit]"],
            onAddContributor: {
                "ProjectDetailPage[<EditProjectModal>.onAddContributor]": async (projectId_0, email)=>{
                    await addContributor(projectId_0, email);
                }
            }["ProjectDetailPage[<EditProjectModal>.onAddContributor]"],
            onRemoveContributor: {
                "ProjectDetailPage[<EditProjectModal>.onRemoveContributor]": async (projectId_1, userId)=>{
                    await removeContributor(projectId_1, userId);
                }
            }["ProjectDetailPage[<EditProjectModal>.onRemoveContributor]"],
            onDelete: {
                "ProjectDetailPage[<EditProjectModal>.onDelete]": async (projectId_2)=>{
                    await deleteProject(projectId_2);
                    router.push("/dashboard/projects");
                }
            }["ProjectDetailPage[<EditProjectModal>.onDelete]"],
            onRefresh: fetchProject
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/[id]/page.tsx",
            lineNumber: 285,
            columnNumber: 36
        }, this);
        $[55] = addContributor;
        $[56] = closeModal;
        $[57] = deleteProject;
        $[58] = fetchProject;
        $[59] = id;
        $[60] = isOpen;
        $[61] = project.description;
        $[62] = project.members;
        $[63] = project.name;
        $[64] = project.owner.id;
        $[65] = projectContributors;
        $[66] = removeContributor;
        $[67] = router;
        $[68] = totalContributors;
        $[69] = updateProject;
        $[70] = t15;
    } else {
        t15 = $[70];
    }
    let t16;
    if ($[71] !== closeModal || $[72] !== createTask || $[73] !== isOpen || $[74] !== project.members || $[75] !== project.owner.id) {
        t16 = isOpen("createTask") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$CreateTaskModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            members: project.members,
            ownerId: project.owner.id,
            onClose: closeModal,
            onSubmit: {
                "ProjectDetailPage[<CreateTaskModal>.onSubmit]": (title_0, description_1, dueDate_0, assigneeIds_0, status_1, priority_0)=>createTask(title_0, description_1, dueDate_0 ?? "", assigneeIds_0, status_1, priority_0)
            }["ProjectDetailPage[<CreateTaskModal>.onSubmit]"]
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/[id]/page.tsx",
            lineNumber: 324,
            columnNumber: 35
        }, this);
        $[71] = closeModal;
        $[72] = createTask;
        $[73] = isOpen;
        $[74] = project.members;
        $[75] = project.owner.id;
        $[76] = t16;
    } else {
        t16 = $[76];
    }
    let t17;
    if ($[77] !== closeModal || $[78] !== editingTask || $[79] !== handleUpdateTask || $[80] !== isOpen || $[81] !== project.members || $[82] !== project.owner.id) {
        t17 = isOpen("editTask") && editingTask && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$EditTaskModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            task: editingTask,
            members: project.members,
            ownerId: project.owner.id,
            onClose: {
                "ProjectDetailPage[<EditTaskModal>.onClose]": ()=>{
                    closeModal();
                    setEditingTask(null);
                }
            }["ProjectDetailPage[<EditTaskModal>.onClose]"],
            onSubmit: handleUpdateTask
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/[id]/page.tsx",
            lineNumber: 338,
            columnNumber: 48
        }, this);
        $[77] = closeModal;
        $[78] = editingTask;
        $[79] = handleUpdateTask;
        $[80] = isOpen;
        $[81] = project.members;
        $[82] = project.owner.id;
        $[83] = t17;
    } else {
        t17 = $[83];
    }
    let t18;
    if ($[84] !== closeModal || $[85] !== handleAISubmit || $[86] !== isOpen) {
        t18 = isOpen("aiTask") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$AITaskModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClose: closeModal,
            onSubmit: handleAISubmit
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/[id]/page.tsx",
            lineNumber: 356,
            columnNumber: 31
        }, this);
        $[84] = closeModal;
        $[85] = handleAISubmit;
        $[86] = isOpen;
        $[87] = t18;
    } else {
        t18 = $[87];
    }
    let t19;
    if ($[88] !== t10 || $[89] !== t11 || $[90] !== t14 || $[91] !== t15 || $[92] !== t16 || $[93] !== t17 || $[94] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-6",
            children: [
                t10,
                t11,
                t14,
                t15,
                t16,
                t17,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/app/dashboard/projects/[id]/page.tsx",
            lineNumber: 366,
            columnNumber: 11
        }, this);
        $[88] = t10;
        $[89] = t11;
        $[90] = t14;
        $[91] = t15;
        $[92] = t16;
        $[93] = t17;
        $[94] = t18;
        $[95] = t19;
    } else {
        t19 = $[95];
    }
    return t19;
}
_s(ProjectDetailPage, "Xk9o3V5M1V9SMOrj+Y3OU9GAbew=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProject$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProject"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjects"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModal"]
    ];
});
_c = ProjectDetailPage;
function _ProjectDetailPageAnonymous(m_0) {
    return m_0.user;
}
var _c;
__turbopack_context__.k.register(_c, "ProjectDetailPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=frontend_src_fbaed865._.js.map