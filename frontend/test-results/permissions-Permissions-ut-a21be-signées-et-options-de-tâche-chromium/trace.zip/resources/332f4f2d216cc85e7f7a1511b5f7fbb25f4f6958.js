(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__d128c9ce._.css",
  "static/chunks/frontend_28d16c59._.js"
],
    source: "dynamic"
});
