(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "apiRequest",
    ()=>apiRequest
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const BASE_URL = ("TURBOPACK compile-time value", "http://localhost:8000");
async function apiRequest(endpoint, options = {}) {
    const { method = "GET", body } = options;
    try {
        const res = await fetch(`${BASE_URL}${endpoint}`, {
            method,
            headers: body ? {
                "Content-Type": "application/json"
            } : undefined,
            credentials: "include",
            body: body ? JSON.stringify(body) : undefined
        });
        const json = await res.json();
        if (!res.ok) {
            return {
                data: null,
                error: json.message || `Erreur ${res.status}`
            };
        }
        return {
            data: json.data,
            error: null
        };
    } catch  {
        return {
            data: null,
            error: "Erreur réseau. Vérifiez votre connexion."
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/api/projects.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addContributor",
    ()=>addContributor,
    "createProject",
    ()=>createProject,
    "deleteProject",
    ()=>deleteProject,
    "fetchProject",
    ()=>fetchProject,
    "fetchProjectTasks",
    ()=>fetchProjectTasks,
    "fetchProjects",
    ()=>fetchProjects,
    "removeContributor",
    ()=>removeContributor,
    "updateProject",
    ()=>updateProject
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
;
async function fetchProjects() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])("/projects");
}
async function fetchProject(projectId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}`);
}
async function createProject(name, description, contributors// ✅ Ajouter ce paramètre
) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])("/projects", {
        method: "POST",
        body: {
            name,
            description,
            contributors
        }
    });
}
async function updateProject(projectId, name, description) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}`, {
        method: "PUT",
        body: {
            name,
            description
        }
    });
}
async function deleteProject(projectId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}`, {
        method: "DELETE"
    });
}
async function addContributor(projectId, email) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/contributors`, {
        method: "POST",
        body: {
            email
        }
    });
}
async function removeContributor(projectId, userId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/contributors/${userId}`, {
        method: "DELETE"
    });
}
async function fetchProjectTasks(projectId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks`);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useProjects.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useProjects",
    ()=>useProjects
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/projects.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useAuth.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function useProjects() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "cb915cc7e0bd634ef620f1c3ffbf16b3d600a7aa69fadd7f0d5095773233e695") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb915cc7e0bd634ef620f1c3ffbf16b3d600a7aa69fadd7f0d5095773233e695";
    }
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [projects, setProjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "useProjects[fetchProjects]": async ()=>{
                setLoading(true);
                setError(null);
                const { data, error: err } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchProjects"])();
                if (err || !data) {
                    setError(err ?? "Erreur lors du chargement des projets");
                    setLoading(false);
                    return;
                }
                const projectsWithStats = await Promise.all(data.projects.map(_useProjectsFetchProjectsDataProjectsMap));
                setProjects(projectsWithStats);
                setLoading(false);
            }
        })["useProjects[fetchProjects]"];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const fetchProjects = t1;
    let t2;
    if ($[3] !== user?.id) {
        t2 = async function createProject(name, description, contributors) {
            if (!user?.id) {
                throw new Error("Utilisateur non authentifi\xE9");
            }
            const uniqueContributors = contributors ?? [];
            const { data: data_0, error: err_0 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProject"])(name, description, uniqueContributors);
            if (err_0 || !data_0) {
                throw new Error(err_0 ?? "Erreur lors de la cr\xE9ation");
            }
            return data_0.project.id;
        };
        $[3] = user?.id;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const createProject = t2;
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = async function addContributor(projectId, email) {
            const { error: err_1 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addContributor"])(projectId, email);
            if (err_1) {
                throw new Error(err_1);
            }
            await fetchProjects();
        };
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const addContributor = t3;
    let t4;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = async function deleteProject(projectId_0) {
            const { error: error_0 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteProject"])(projectId_0);
            if (error_0) {
                throw new Error(error_0);
            }
            setProjects({
                "useProjects[deleteProject > setProjects()]": (prev)=>prev.filter({
                        "useProjects[deleteProject > setProjects() > prev.filter()]": (p)=>p.id !== projectId_0
                    }["useProjects[deleteProject > setProjects() > prev.filter()]"])
            }["useProjects[deleteProject > setProjects()]"]);
        };
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const deleteProject = t4;
    let t5;
    if ($[7] !== createProject || $[8] !== error || $[9] !== loading || $[10] !== projects) {
        t5 = {
            projects,
            loading,
            error,
            fetchProjects,
            createProject,
            addContributor,
            deleteProject
        };
        $[7] = createProject;
        $[8] = error;
        $[9] = loading;
        $[10] = projects;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    return t5;
}
_s(useProjects, "UNqomK9kSRMxUJ5mQmMybh1HwFo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
async function _useProjectsFetchProjectsDataProjectsMap(project) {
    const { data: taskData } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchProjectTasks"])(project.id);
    const tasks = taskData?.tasks ?? [];
    const completedTasks = tasks.filter(_useProjectsFetchProjectsDataProjectsMapTasksFilter).length;
    const totalTasks = tasks.length;
    const progression = totalTasks > 0 ? Math.round(completedTasks / totalTasks * 100) : 0;
    return {
        ...project,
        tasks,
        completedTasks,
        totalTasks,
        progression
    };
}
function _useProjectsFetchProjectsDataProjectsMapTasksFilter(t) {
    return t.status === "DONE";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useModal.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useModal",
    ()=>useModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useModal() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "dcb9475c53dcb8c3bf3fd696417f973ef49db524180eca58b087d6d6c7455971") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "dcb9475c53dcb8c3bf3fd696417f973ef49db524180eca58b087d6d6c7455971";
    }
    const [activeModal, setActiveModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = function openModal(name) {
            setActiveModal(name);
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const openModal = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = function closeModal() {
            setActiveModal(null);
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const closeModal = t1;
    let t2;
    if ($[3] !== activeModal) {
        t2 = function isOpen(name_0) {
            return activeModal === name_0;
        };
        $[3] = activeModal;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const isOpen = t2;
    let t3;
    if ($[5] !== activeModal || $[6] !== isOpen) {
        t3 = {
            activeModal,
            openModal,
            closeModal,
            isOpen
        };
        $[5] = activeModal;
        $[6] = isOpen;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    return t3;
}
_s(useModal, "kAcpyZCE6YA2McoeUdamFLX5os8=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/icons/EquipeIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EquipeIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
function EquipeIcon(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "b80dc0f2bc8c0c7d30ee86ed9cf8b0a98ae9dd456afd1cbe674df110f50a3170") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b80dc0f2bc8c0c7d30ee86ed9cf8b0a98ae9dd456afd1cbe674df110f50a3170";
    }
    const { className } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M7.52637 6.94727C9.78424 6.94727 11.579 8.74215 11.5791 11H3.47363C3.47372 8.74222 5.2686 6.94738 7.52637 6.94727ZM3.87891 5.21094C4.11047 5.73187 4.45811 6.19468 4.86328 6.54199C3.99485 7.06305 3.2998 7.81614 2.89453 8.68457H0C0 6.77405 1.56313 5.21099 3.47363 5.21094H3.87891ZM7.52637 0.579102C9.12507 0.579102 10.4208 1.87494 10.4209 3.47363C10.4209 5.07238 9.12511 6.36816 7.52637 6.36816C5.92769 6.36809 4.63184 5.07233 4.63184 3.47363C4.63189 1.87499 5.92772 0.579177 7.52637 0.579102ZM3.47363 0C3.99467 0 4.45802 0.173434 4.86328 0.462891C3.99488 1.15761 3.47367 2.25787 3.47363 3.47363C3.47363 3.8789 3.53167 4.28446 3.64746 4.63184H3.47363C2.19994 4.63182 1.1582 3.58913 1.1582 2.31543C1.15843 1.04192 2.20008 1.19457e-05 3.47363 0Z"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/EquipeIcon.tsx",
            lineNumber: 16,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== className) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: className,
            width: "12",
            height: "11",
            viewBox: "0 0 12 11",
            fill: "currentColor",
            xmlns: "http://www.w3.org/2000/svg",
            children: t1
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/EquipeIcon.tsx",
            lineNumber: 23,
            columnNumber: 10
        }, this);
        $[2] = className;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_c = EquipeIcon;
var _c;
__turbopack_context__.k.register(_c, "EquipeIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/projects/ProjectCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$EquipeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/EquipeIcon.tsx [app-client] (ecmascript)");
;
;
;
;
;
function ProjectCard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(73);
    if ($[0] !== "3e6155061949a2a3a19a29514629021c3008ffb02ef512b631ae7ec2ef9968be") {
        for(let $i = 0; $i < 73; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "3e6155061949a2a3a19a29514629021c3008ffb02ef512b631ae7ec2ef9968be";
    }
    const { project } = t0;
    const owner = project.owner;
    let T0;
    let t1;
    let t10;
    let t11;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[1] !== owner.id || $[2] !== owner.name || $[3] !== project.completedTasks || $[4] !== project.description || $[5] !== project.id || $[6] !== project.members || $[7] !== project.name || $[8] !== project.progression || $[9] !== project.totalTasks) {
        const projectContributors = project.members?.filter({
            "ProjectCard[(anonymous)()]": (m)=>m.user.id !== owner.id
        }["ProjectCard[(anonymous)()]"]).map(_ProjectCardAnonymous) || [];
        const totalContributors = 1 + projectContributors.length;
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        t6 = `/dashboard/projects/${project.id}`;
        t7 = "bg-bg-content rounded-[8px] shadow-card p-5 flex flex-col hover:shadow-modal transition";
        t8 = `Voir le projet ${project.name}`;
        if ($[22] !== project.name) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "font-semibold text-text-primary text-lg",
                children: project.name
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 43,
                columnNumber: 12
            }, this);
            $[22] = project.name;
            $[23] = t9;
        } else {
            t9 = $[23];
        }
        if ($[24] !== project.description) {
            t10 = project.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-text-secondary line-clamp-2 mb-10",
                children: project.description
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 50,
                columnNumber: 36
            }, this);
            $[24] = project.description;
            $[25] = t10;
        } else {
            t10 = $[25];
        }
        let t12;
        if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xs text-text-secondary",
                children: "Progression"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 58,
                columnNumber: 13
            }, this);
            $[26] = t12;
        } else {
            t12 = $[26];
        }
        let t13;
        if ($[27] !== project.progression) {
            t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: [
                    t12,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs font-medium text-text-primary",
                        children: [
                            project.progression,
                            "%"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                        lineNumber: 65,
                        columnNumber: 69
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 65,
                columnNumber: 13
            }, this);
            $[27] = project.progression;
            $[28] = t13;
        } else {
            t13 = $[28];
        }
        const t14 = Number(project.progression) || 0;
        const t15 = `Progression du projet : ${project.progression}%`;
        const t16 = `${project.progression}%`;
        let t17;
        if ($[29] !== t16) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-full bg-brand-dark rounded-full transition-all",
                style: {
                    width: t16
                }
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 76,
                columnNumber: 13
            }, this);
            $[29] = t16;
            $[30] = t17;
        } else {
            t17 = $[30];
        }
        let t18;
        if ($[31] !== t14 || $[32] !== t15 || $[33] !== t17) {
            t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full h-1.5 mt-1 bg-bg-grey-light rounded-full overflow-hidden",
                role: "progressbar",
                "aria-valuenow": t14,
                "aria-valuemin": 0,
                "aria-valuemax": 100,
                "aria-label": t15,
                children: t17
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 86,
                columnNumber: 13
            }, this);
            $[31] = t14;
            $[32] = t15;
            $[33] = t17;
            $[34] = t18;
        } else {
            t18 = $[34];
        }
        let t19;
        if ($[35] !== project.completedTasks || $[36] !== project.totalTasks) {
            t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xs text-text-secondary",
                children: [
                    project.completedTasks,
                    "/",
                    project.totalTasks,
                    " tâches terminées"
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 96,
                columnNumber: 13
            }, this);
            $[35] = project.completedTasks;
            $[36] = project.totalTasks;
            $[37] = t19;
        } else {
            t19 = $[37];
        }
        if ($[38] !== t13 || $[39] !== t18 || $[40] !== t19) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col mb-10 gap-2",
                children: [
                    t13,
                    t18,
                    t19
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 104,
                columnNumber: 13
            }, this);
            $[38] = t13;
            $[39] = t18;
            $[40] = t19;
            $[41] = t11;
        } else {
            t11 = $[41];
        }
        t4 = "flex flex-col gap-2";
        let t20;
        if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
            t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$EquipeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "w-3 h-3"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 115,
                columnNumber: 13
            }, this);
            $[42] = t20;
        } else {
            t20 = $[42];
        }
        if ($[43] !== totalContributors) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex gap-1 text-[10px] font-medium text-text-secondary",
                children: [
                    t20,
                    "Équipe (",
                    totalContributors,
                    ")"
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 121,
                columnNumber: 12
            }, this);
            $[43] = totalContributors;
            $[44] = t5;
        } else {
            t5 = $[44];
        }
        t1 = "flex items-center gap-2 flex-wrap";
        const t21 = `${owner.name} — Propriétaire`;
        const t22 = owner.name;
        let t23;
        if ($[45] !== owner.name) {
            t23 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(owner.name);
            $[45] = owner.name;
            $[46] = t23;
        } else {
            t23 = $[46];
        }
        let t24;
        if ($[47] !== t23) {
            t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[10px] text-text-primary",
                children: t23
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 140,
                columnNumber: 13
            }, this);
            $[47] = t23;
            $[48] = t24;
        } else {
            t24 = $[48];
        }
        let t25;
        if ($[49] !== owner.name || $[50] !== t21 || $[51] !== t24) {
            t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-7 h-7 rounded-full bg-brand-light flex items-center justify-center",
                "aria-label": t21,
                title: t22,
                children: t24
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 148,
                columnNumber: 13
            }, this);
            $[49] = owner.name;
            $[50] = t21;
            $[51] = t24;
            $[52] = t25;
        } else {
            t25 = $[52];
        }
        let t26;
        if ($[53] === Symbol.for("react.memo_cache_sentinel")) {
            t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[10px] text-brand-dark bg-brand-light px-2 py-0.5 rounded-full",
                children: "Propriétaire"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 158,
                columnNumber: 13
            }, this);
            $[53] = t26;
        } else {
            t26 = $[53];
        }
        if ($[54] !== t25) {
            t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-1.5",
                children: [
                    t25,
                    t26
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
                lineNumber: 164,
                columnNumber: 12
            }, this);
            $[54] = t25;
            $[55] = t2;
        } else {
            t2 = $[55];
        }
        t3 = projectContributors.map(_ProjectCardProjectContributorsMap);
        $[1] = owner.id;
        $[2] = owner.name;
        $[3] = project.completedTasks;
        $[4] = project.description;
        $[5] = project.id;
        $[6] = project.members;
        $[7] = project.name;
        $[8] = project.progression;
        $[9] = project.totalTasks;
        $[10] = T0;
        $[11] = t1;
        $[12] = t10;
        $[13] = t11;
        $[14] = t2;
        $[15] = t3;
        $[16] = t4;
        $[17] = t5;
        $[18] = t6;
        $[19] = t7;
        $[20] = t8;
        $[21] = t9;
    } else {
        T0 = $[10];
        t1 = $[11];
        t10 = $[12];
        t11 = $[13];
        t2 = $[14];
        t3 = $[15];
        t4 = $[16];
        t5 = $[17];
        t6 = $[18];
        t7 = $[19];
        t8 = $[20];
        t9 = $[21];
    }
    let t12;
    if ($[56] !== t1 || $[57] !== t2 || $[58] !== t3) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t1,
            children: [
                t2,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
            lineNumber: 208,
            columnNumber: 11
        }, this);
        $[56] = t1;
        $[57] = t2;
        $[58] = t3;
        $[59] = t12;
    } else {
        t12 = $[59];
    }
    let t13;
    if ($[60] !== t12 || $[61] !== t4 || $[62] !== t5) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t4,
            children: [
                t5,
                t12
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
            lineNumber: 218,
            columnNumber: 11
        }, this);
        $[60] = t12;
        $[61] = t4;
        $[62] = t5;
        $[63] = t13;
    } else {
        t13 = $[63];
    }
    let t14;
    if ($[64] !== T0 || $[65] !== t10 || $[66] !== t11 || $[67] !== t13 || $[68] !== t6 || $[69] !== t7 || $[70] !== t8 || $[71] !== t9) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            href: t6,
            className: t7,
            "aria-label": t8,
            children: [
                t9,
                t10,
                t11,
                t13
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
            lineNumber: 228,
            columnNumber: 11
        }, this);
        $[64] = T0;
        $[65] = t10;
        $[66] = t11;
        $[67] = t13;
        $[68] = t6;
        $[69] = t7;
        $[70] = t8;
        $[71] = t9;
        $[72] = t14;
    } else {
        t14 = $[72];
    }
    return t14;
}
_c = ProjectCard;
function _ProjectCardProjectContributorsMap(user) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-7 h-7 rounded-full bg-bg-grey-border flex items-center justify-center",
        "aria-label": user.name,
        title: user.name,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-[10px] text-text-secondary",
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(user.name)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
            lineNumber: 244,
            columnNumber: 154
        }, this)
    }, user.id, false, {
        fileName: "[project]/frontend/src/components/projects/ProjectCard.tsx",
        lineNumber: 244,
        columnNumber: 10
    }, this);
}
function _ProjectCardAnonymous(m_0) {
    return m_0.user;
}
var _c;
__turbopack_context__.k.register(_c, "ProjectCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/BaseModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BaseModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js [app-client] (ecmascript) <export default as XMarkIcon>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function BaseModal(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(26);
    if ($[0] !== "aff49536f83a2f9678dc696da740fff19a7778adf2d464681431e0156f689bc6") {
        for(let $i = 0; $i < 26; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "aff49536f83a2f9678dc696da740fff19a7778adf2d464681431e0156f689bc6";
    }
    const { id, title, onClose, children, maxWidth: t1, icon } = t0;
    const maxWidth = t1 === undefined ? "max-w-149.5" : t1;
    let t2;
    let t3;
    if ($[1] !== onClose) {
        t2 = ({
            "BaseModal[useEffect()]": ()=>{
                const handleKeyDown = function handleKeyDown(e) {
                    if (e.key === "Escape") {
                        onClose();
                    }
                };
                document.addEventListener("keydown", handleKeyDown);
                return ()=>document.removeEventListener("keydown", handleKeyDown);
            }
        })["BaseModal[useEffect()]"];
        t3 = [
            onClose
        ];
        $[1] = onClose;
        $[2] = t2;
        $[3] = t3;
    } else {
        t2 = $[2];
        t3 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    const t4 = `bg-bg-content rounded-[8px] shadow-modal w-full ${maxWidth} max-h-[90vh] overflow-y-auto p-6 flex flex-col gap-5`;
    let t5;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
            className: "h-5 w-5"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 58,
            columnNumber: 10
        }, this);
        $[4] = t5;
    } else {
        t5 = $[4];
    }
    let t6;
    if ($[5] !== onClose) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-end",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: onClose,
                className: "text-text-secondary hover:text-text-primary transition",
                "aria-label": "Fermer la modale",
                children: t5
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
                lineNumber: 65,
                columnNumber: 44
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 65,
            columnNumber: 10
        }, this);
        $[5] = onClose;
        $[6] = t6;
    } else {
        t6 = $[6];
    }
    let t7;
    if ($[7] !== icon) {
        t7 = icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-2.5",
            children: icon
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 73,
            columnNumber: 18
        }, this);
        $[7] = icon;
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] !== id || $[10] !== title) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            id: id,
            className: "font-semibold text-text-primary text-2xl mt-2",
            children: title
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[9] = id;
        $[10] = title;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== t7 || $[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center ml-12 gap-2",
            children: [
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[12] = t7;
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== t6 || $[16] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col",
            children: [
                t6,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 99,
            columnNumber: 11
        }, this);
        $[15] = t6;
        $[16] = t9;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] !== children || $[19] !== t10 || $[20] !== t4) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t4,
            onClick: _BaseModalDivOnClick,
            children: [
                t10,
                children
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 108,
            columnNumber: 11
        }, this);
        $[18] = children;
        $[19] = t10;
        $[20] = t4;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    let t12;
    if ($[22] !== id || $[23] !== onClose || $[24] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-50 flex items-center justify-center bg-black/40",
            role: "dialog",
            "aria-modal": "true",
            "aria-labelledby": id,
            onClick: onClose,
            children: t11
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 118,
            columnNumber: 11
        }, this);
        $[22] = id;
        $[23] = onClose;
        $[24] = t11;
        $[25] = t12;
    } else {
        t12 = $[25];
    }
    return t12;
}
_s(BaseModal, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = BaseModal;
function _BaseModalDivOnClick(e_0) {
    return e_0.stopPropagation();
}
var _c;
__turbopack_context__.k.register(_c, "BaseModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/api/users.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getUsers",
    ()=>getUsers,
    "searchUsers",
    ()=>searchUsers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
;
async function searchUsers(query) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/users/search?query=${encodeURIComponent(query)}`);
}
async function getUsers() {
    const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])("/users");
    return res.data?.users ?? [];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/ContributorSearch.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContributorSearch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$users$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/users.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ContributorSearch(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(50);
    if ($[0] !== "07ecb7b3715facea8e6f57e6f46f639dd21737f69da0bbeae2e1c6ad953e147c") {
        for(let $i = 0; $i < 50; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "07ecb7b3715facea8e6f57e6f46f639dd21737f69da0bbeae2e1c6ad953e147c";
    }
    const { selectedUsers, excludeUserIds: t1, onAdd, onRemove, label: t2, ownerId, buttonLabel: t3 } = t0;
    let t4;
    if ($[1] !== t1) {
        t4 = t1 === undefined ? [] : t1;
        $[1] = t1;
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    const excludeUserIds = t4;
    const label = t2 === undefined ? "Contributeurs" : t2;
    const buttonLabel = t3 === undefined ? "Choisir un ou plusieurs collaborateurs" : t3;
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t5;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = [];
        $[3] = t5;
    } else {
        t5 = $[3];
    }
    const [allUsers, setAllUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t5);
    let t6;
    let t7;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "ContributorSearch[useEffect()]": ()=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$users$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUsers"])().then({
                    "ContributorSearch[useEffect() > (anonymous)()]": (users)=>setAllUsers(users)
                }["ContributorSearch[useEffect() > (anonymous)()]"]);
            }
        })["ContributorSearch[useEffect()]"];
        t7 = [];
        $[4] = t6;
        $[5] = t7;
    } else {
        t6 = $[4];
        t7 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t6, t7);
    let t10;
    let t11;
    let t12;
    let t13;
    let t8;
    let t9;
    if ($[6] !== allUsers || $[7] !== buttonLabel || $[8] !== excludeUserIds || $[9] !== isOpen || $[10] !== label || $[11] !== onAdd || $[12] !== onRemove || $[13] !== ownerId || $[14] !== selectedUsers) {
        let t14;
        if ($[21] !== excludeUserIds || $[22] !== selectedUsers) {
            t14 = ({
                "ContributorSearch[allUsers.filter()]": (u)=>!selectedUsers.find({
                        "ContributorSearch[allUsers.filter() > selectedUsers.find()]": (s)=>s.id === u.id
                    }["ContributorSearch[allUsers.filter() > selectedUsers.find()]"]) && !excludeUserIds.includes(u.id)
            })["ContributorSearch[allUsers.filter()]"];
            $[21] = excludeUserIds;
            $[22] = selectedUsers;
            $[23] = t14;
        } else {
            t14 = $[23];
        }
        const availableUsers = allUsers.filter(t14);
        let t15;
        if ($[24] !== onAdd) {
            t15 = function handleAdd(user) {
                onAdd(user);
                setIsOpen(false);
            };
            $[24] = onAdd;
            $[25] = t15;
        } else {
            t15 = $[25];
        }
        const handleAdd = t15;
        t11 = "flex flex-col gap-1";
        if ($[26] !== label) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm text-text-primary",
                children: label
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 107,
                columnNumber: 13
            }, this);
            $[26] = label;
            $[27] = t12;
        } else {
            t12 = $[27];
        }
        if ($[28] !== onRemove || $[29] !== ownerId || $[30] !== selectedUsers) {
            t13 = selectedUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-2 mb-1",
                children: selectedUsers.map({
                    "ContributorSearch[selectedUsers.map()]": (u_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1.5 bg-bg-grey-light rounded-full px-2 py-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${u_0.id === ownerId ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `text-[9px] ${u_0.id === ownerId ? "text-text-primary" : "text-text-secondary"}`,
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(u_0.name)
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                        lineNumber: 115,
                                        columnNumber: 301
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 115,
                                    columnNumber: 156
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs text-text-primary",
                                    children: u_0.name
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 115,
                                    columnNumber: 436
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: {
                                        "ContributorSearch[selectedUsers.map() > <button>.onClick]": ()=>onRemove(u_0.id)
                                    }["ContributorSearch[selectedUsers.map() > <button>.onClick]"],
                                    className: "text-text-secondary hover:text-system-error text-xs ml-0.5",
                                    "aria-label": `Retirer ${u_0.name}`,
                                    children: "×"
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 115,
                                    columnNumber: 497
                                }, this)
                            ]
                        }, u_0.id, true, {
                            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                            lineNumber: 115,
                            columnNumber: 60
                        }, this)
                }["ContributorSearch[selectedUsers.map()]"])
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 114,
                columnNumber: 41
            }, this);
            $[28] = onRemove;
            $[29] = ownerId;
            $[30] = selectedUsers;
            $[31] = t13;
        } else {
            t13 = $[31];
        }
        t8 = "relative";
        let t16;
        if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
            t16 = ({
                "ContributorSearch[<button>.onClick]": ()=>setIsOpen(_ContributorSearchButtonOnClickSetIsOpen)
            })["ContributorSearch[<button>.onClick]"];
            $[32] = t16;
        } else {
            t16 = $[32];
        }
        let t17;
        if ($[33] !== buttonLabel) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-text-secondary",
                children: buttonLabel
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 138,
                columnNumber: 13
            }, this);
            $[33] = buttonLabel;
            $[34] = t17;
        } else {
            t17 = $[34];
        }
        const t18 = `h-6 w-6 text-btn-black transition-transform ${isOpen ? "rotate-180" : ""}`;
        let t19;
        if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
            t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M5 8l5 5 5-5"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 147,
                columnNumber: 13
            }, this);
            $[35] = t19;
        } else {
            t19 = $[35];
        }
        let t20;
        if ($[36] !== t18) {
            t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: t18,
                viewBox: "0 0 20 20",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: 1.5,
                children: t19
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 154,
                columnNumber: 13
            }, this);
            $[36] = t18;
            $[37] = t20;
        } else {
            t20 = $[37];
        }
        if ($[38] !== t17 || $[39] !== t20) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: t16,
                className: "w-full h-13.25 flex items-center justify-between border border-system-neutral rounded-[8px] px-4 py-3 text-sm bg-bg-content transition",
                children: [
                    t17,
                    t20
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 161,
                columnNumber: 12
            }, this);
            $[38] = t17;
            $[39] = t20;
            $[40] = t9;
        } else {
            t9 = $[40];
        }
        t10 = isOpen && availableUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-full left-0 right-0 z-20 bg-bg-content border border-system-neutral rounded-[8px] shadow-modal mt-1 overflow-hidden max-h-48 overflow-y-auto",
            children: availableUsers.map({
                "ContributorSearch[availableUsers.map()]": (u_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: {
                            "ContributorSearch[availableUsers.map() > <button>.onClick]": ()=>handleAdd(u_1)
                        }["ContributorSearch[availableUsers.map() > <button>.onClick]"],
                        className: "w-full flex items-center gap-2 px-4 py-2 text-sm text-text-secondary hover:bg-bg-grey-light transition",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${u_1.id === ownerId ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `text-[9px] font-semibold ${u_1.id === ownerId ? "text-text-primary" : "text-text-secondary"}`,
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(u_1.name)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 171,
                                    columnNumber: 334
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                lineNumber: 171,
                                columnNumber: 189
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `px-2 py-0.5 rounded-full text-sm ${u_1.id === ownerId ? "bg-brand-light text-text-primary" : "bg-bg-grey-border text-text-secondary"}`,
                                children: u_1.name
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                lineNumber: 171,
                                columnNumber: 483
                            }, this)
                        ]
                    }, u_1.id, true, {
                        fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                        lineNumber: 169,
                        columnNumber: 59
                    }, this)
            }["ContributorSearch[availableUsers.map()]"])
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
            lineNumber: 168,
            columnNumber: 50
        }, this);
        $[6] = allUsers;
        $[7] = buttonLabel;
        $[8] = excludeUserIds;
        $[9] = isOpen;
        $[10] = label;
        $[11] = onAdd;
        $[12] = onRemove;
        $[13] = ownerId;
        $[14] = selectedUsers;
        $[15] = t10;
        $[16] = t11;
        $[17] = t12;
        $[18] = t13;
        $[19] = t8;
        $[20] = t9;
    } else {
        t10 = $[15];
        t11 = $[16];
        t12 = $[17];
        t13 = $[18];
        t8 = $[19];
        t9 = $[20];
    }
    let t14;
    if ($[41] !== t10 || $[42] !== t8 || $[43] !== t9) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t8,
            children: [
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
            lineNumber: 198,
            columnNumber: 11
        }, this);
        $[41] = t10;
        $[42] = t8;
        $[43] = t9;
        $[44] = t14;
    } else {
        t14 = $[44];
    }
    let t15;
    if ($[45] !== t11 || $[46] !== t12 || $[47] !== t13 || $[48] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t11,
            children: [
                t12,
                t13,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
            lineNumber: 208,
            columnNumber: 11
        }, this);
        $[45] = t11;
        $[46] = t12;
        $[47] = t13;
        $[48] = t14;
        $[49] = t15;
    } else {
        t15 = $[49];
    }
    return t15;
}
_s(ContributorSearch, "0MGr9tRE1P5jAGVda6z1I3Fhqgc=");
_c = ContributorSearch;
function _ContributorSearchButtonOnClickSetIsOpen(v) {
    return !v;
}
var _c;
__turbopack_context__.k.register(_c, "ContributorSearch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/forms/ProjectForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$ContributorSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/ContributorSearch.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ProjectForm(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(59);
    if ($[0] !== "2492284460de39344344b9fe362117072d989e282ac6370753fde79ef61e10c6") {
        for(let $i = 0; $i < 59; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2492284460de39344344b9fe362117072d989e282ac6370753fde79ef61e10c6";
    }
    const { initialName: t1, initialDescription: t2, initialMembers: t3, totalContributors, submitLabel, loading, error, onSubmit, onDelete, projectId, onAddContributor, onRemoveContributor, selectedContributors: t4, ownerId } = t0;
    const initialName = t1 === undefined ? "" : t1;
    const initialDescription = t2 === undefined ? "" : t2;
    const initialMembers = t3 === undefined ? [] : t3;
    let t5;
    if ($[1] !== t4) {
        t5 = t4 === undefined ? [] : t4;
        $[1] = t4;
        $[2] = t5;
    } else {
        t5 = $[2];
    }
    const selectedContributors = t5;
    const [name, setName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialName);
    const [description, setDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialDescription);
    let t6;
    if ($[3] !== description || $[4] !== name || $[5] !== onSubmit || $[6] !== selectedContributors) {
        t6 = async function handleSubmit(e) {
            e.preventDefault();
            const contributorEmails = selectedContributors.map(_ProjectFormHandleSubmitSelectedContributorsMap);
            await onSubmit(name, description, contributorEmails);
        };
        $[3] = description;
        $[4] = name;
        $[5] = onSubmit;
        $[6] = selectedContributors;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    const handleSubmit = t6;
    const excludeUserIds = initialMembers.map(_ProjectFormInitialMembersMap);
    let t7;
    if ($[8] !== ownerId) {
        t7 = ({
            "ProjectForm[initialMembers.find()]": (m_0)=>m_0.user.id === ownerId
        })["ProjectForm[initialMembers.find()]"];
        $[8] = ownerId;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    const ownerMember = initialMembers.find(t7);
    const ownerName = ownerMember?.user.name ?? "";
    const ownerInitials = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(ownerName);
    let t8;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            htmlFor: "project-name",
            className: "text-sm text-police-black",
            children: [
                "Titre ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    "aria-hidden": "true",
                    children: "*"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 97,
                    columnNumber: 84
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 97,
            columnNumber: 10
        }, this);
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] !== setName) {
        t9 = ({
            "ProjectForm[<input>.onChange]": (e_0)=>setName(e_0.target.value)
        })["ProjectForm[<input>.onChange]"];
        $[11] = setName;
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    let t10;
    if ($[13] !== name || $[14] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t8,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    id: "project-name",
                    type: "text",
                    value: name,
                    onChange: t9,
                    className: "h-13.25 px-4 py-2.5 text-sm text-police-black bg-bg-content transition",
                    placeholder: "Nom du projet",
                    required: true,
                    autoFocus: true
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 114,
                    columnNumber: 52
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 114,
            columnNumber: 11
        }, this);
        $[13] = name;
        $[14] = t9;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    let t11;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            htmlFor: "project-description",
            className: "text-sm text-text-primary",
            children: "Description"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 123,
            columnNumber: 11
        }, this);
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    let t12;
    if ($[17] !== setDescription) {
        t12 = ({
            "ProjectForm[<textarea>.onChange]": (e_1)=>setDescription(e_1.target.value)
        })["ProjectForm[<textarea>.onChange]"];
        $[17] = setDescription;
        $[18] = t12;
    } else {
        t12 = $[18];
    }
    let t13;
    if ($[19] !== description || $[20] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t11,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                    id: "project-description",
                    value: description,
                    onChange: t12,
                    className: "px-4 py-2.5 h-13.25 text-sm text-police-black bg-bg-content transition resize-none",
                    placeholder: "Description du projet"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 140,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 140,
            columnNumber: 11
        }, this);
        $[19] = description;
        $[20] = t12;
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    let t14;
    if ($[22] !== onRemoveContributor || $[23] !== ownerInitials || $[24] !== ownerMember || $[25] !== ownerName || $[26] !== selectedContributors || $[27] !== totalContributors) {
        t14 = onRemoveContributor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-sm font-medium text-text-primary",
                    children: [
                        "Contributeurs actuels (",
                        totalContributors,
                        ")"
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 149,
                    columnNumber: 71
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-wrap items-center gap-2",
                    children: [
                        ownerMember && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1 px-2.5 rounded-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-5 h-5 rounded-full flex items-center justify-center bg-brand-light",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[10px] font-semibold text-btn-black",
                                        children: ownerInitials
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                        lineNumber: 149,
                                        columnNumber: 391
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                    lineNumber: 149,
                                    columnNumber: 305
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[10px] px-2 py-0.5 rounded-full bg-brand-light text-text-primary",
                                    children: ownerName
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                    lineNumber: 149,
                                    columnNumber: 478
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                            lineNumber: 149,
                            columnNumber: 244
                        }, this),
                        selectedContributors.map({
                            "ProjectForm[selectedContributors.map()]": (user)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-1 px-2.5 rounded-full",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-5 h-5 rounded-full flex items-center justify-center bg-bg-grey-border",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[10px] font-semibold text-text-secondary",
                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(user.name)
                                            }, void 0, false, {
                                                fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                                lineNumber: 150,
                                                columnNumber: 226
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                            lineNumber: 150,
                                            columnNumber: 137
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[10px] px-2 py-0.5 rounded-full bg-bg-grey-border text-text-secondary",
                                            children: user.name
                                        }, void 0, false, {
                                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                            lineNumber: 150,
                                            columnNumber: 327
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: {
                                                "ProjectForm[selectedContributors.map() > <button>.onClick]": ()=>onRemoveContributor(user.id)
                                            }["ProjectForm[selectedContributors.map() > <button>.onClick]"],
                                            className: "text-text-secondary mb-1 hover:text-brand-dark transition",
                                            "aria-label": `Retirer ${user.name}`,
                                            children: "×"
                                        }, void 0, false, {
                                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                            lineNumber: 150,
                                            columnNumber: 438
                                        }, this)
                                    ]
                                }, user.id, true, {
                                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                    lineNumber: 150,
                                    columnNumber: 62
                                }, this)
                        }["ProjectForm[selectedContributors.map()]"])
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 149,
                    columnNumber: 177
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 149,
            columnNumber: 34
        }, this);
        $[22] = onRemoveContributor;
        $[23] = ownerInitials;
        $[24] = ownerMember;
        $[25] = ownerName;
        $[26] = selectedContributors;
        $[27] = totalContributors;
        $[28] = t14;
    } else {
        t14 = $[28];
    }
    let t15;
    if ($[29] !== excludeUserIds || $[30] !== onAddContributor || $[31] !== onRemoveContributor || $[32] !== ownerId || $[33] !== selectedContributors) {
        t15 = onAddContributor && onRemoveContributor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$ContributorSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            selectedUsers: selectedContributors,
            excludeUserIds: excludeUserIds,
            onAdd: onAddContributor,
            onRemove: onRemoveContributor,
            label: "Ajouter un contributeur",
            ownerId: ownerId,
            buttonLabel: selectedContributors.length > 0 ? `${selectedContributors.length} collaborateur${selectedContributors.length > 1 ? "s" : ""}` : "Choisir un ou plusieurs collaborateurs"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 166,
            columnNumber: 54
        }, this);
        $[29] = excludeUserIds;
        $[30] = onAddContributor;
        $[31] = onRemoveContributor;
        $[32] = ownerId;
        $[33] = selectedContributors;
        $[34] = t15;
    } else {
        t15 = $[34];
    }
    let t16;
    if ($[35] !== error) {
        t16 = error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            role: "alert",
            "aria-live": "assertive",
            className: "text-sm text-text-error",
            children: error
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 178,
            columnNumber: 20
        }, this);
        $[35] = error;
        $[36] = t16;
    } else {
        t16 = $[36];
    }
    let t17;
    if ($[37] !== loading || $[38] !== name) {
        t17 = loading || !name.trim();
        $[37] = loading;
        $[38] = name;
        $[39] = t17;
    } else {
        t17 = $[39];
    }
    const t18 = loading ? "En cours..." : submitLabel;
    let t19;
    if ($[40] !== t17 || $[41] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            disabled: t17,
            className: "w-46.25 h-12.5 py-2.5 bg-system-neutral text-text-neutral text-base rounded-[10px] hover:border border-brand-dark hover:text-brand-dark hover:bg-bg-content transition",
            children: t18
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 196,
            columnNumber: 11
        }, this);
        $[40] = t17;
        $[41] = t18;
        $[42] = t19;
    } else {
        t19 = $[42];
    }
    let t20;
    if ($[43] !== onDelete || $[44] !== projectId) {
        t20 = onDelete && projectId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            className: "text-text-error hover:text-red-700 text-sm",
            onClick: onDelete,
            children: "Supprimer le projet"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 205,
            columnNumber: 36
        }, this);
        $[43] = onDelete;
        $[44] = projectId;
        $[45] = t20;
    } else {
        t20 = $[45];
    }
    let t21;
    if ($[46] !== t19 || $[47] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-row justify-between mt-4",
            children: [
                t19,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 214,
            columnNumber: 11
        }, this);
        $[46] = t19;
        $[47] = t20;
        $[48] = t21;
    } else {
        t21 = $[48];
    }
    let t22;
    if ($[49] !== t10 || $[50] !== t13 || $[51] !== t14 || $[52] !== t15 || $[53] !== t16 || $[54] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-113 mx-auto overflow-y-auto flex flex-col gap-4 pr-1",
            children: [
                t10,
                t13,
                t14,
                t15,
                t16,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 223,
            columnNumber: 11
        }, this);
        $[49] = t10;
        $[50] = t13;
        $[51] = t14;
        $[52] = t15;
        $[53] = t16;
        $[54] = t21;
        $[55] = t22;
    } else {
        t22 = $[55];
    }
    let t23;
    if ($[56] !== handleSubmit || $[57] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: handleSubmit,
            className: "flex flex-col gap-4",
            noValidate: true,
            children: t22
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 236,
            columnNumber: 11
        }, this);
        $[56] = handleSubmit;
        $[57] = t22;
        $[58] = t23;
    } else {
        t23 = $[58];
    }
    return t23;
}
_s(ProjectForm, "p8e3PxGPGSdEGKqdDTcGONQjRj0=");
_c = ProjectForm;
function _ProjectFormInitialMembersMap(m) {
    return m.user.id;
}
function _ProjectFormHandleSubmitSelectedContributorsMap(c) {
    return c.email;
}
var _c;
__turbopack_context__.k.register(_c, "ProjectForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/CreateProjectModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CreateProjectModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/BaseModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$ProjectForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/forms/ProjectForm.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function CreateProjectModal({ onClose, onSubmit }) {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedContributors, setSelectedContributors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    async function handleSubmit(name, description) {
        setError(null);
        setLoading(true);
        try {
            await onSubmit(name, description, selectedContributors);
            onClose();
        } catch (err) {
            if (err instanceof Error) setError(err.message);
            else setError("Une erreur est survenue");
        } finally{
            setLoading(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        id: "create-project-title",
        title: "Créer un projet",
        onClose: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$ProjectForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            submitLabel: "Créer",
            loading: loading,
            error: error,
            onSubmit: handleSubmit,
            // 🔹 Pas de membres initiaux lors de la création
            initialMembers: [],
            // 🔹 Aucun contributeur au début
            projectContributors: selectedContributors,
            // 🔹 Total = contributeurs sélectionnés + owner (owner sera ajouté après création)
            totalContributors: selectedContributors.length,
            // 🔹 Gestion des contributeurs
            selectedContributors: selectedContributors,
            onAddContributor: (user)=>setSelectedContributors((prev)=>[
                        ...prev,
                        user
                    ]),
            onRemoveContributor: (userId)=>setSelectedContributors((prev_0)=>prev_0.filter((u)=>u.id !== userId)),
            // 🔹 Pas de suppression de projet ici
            onDelete: ()=>{}
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/CreateProjectModal.tsx",
            lineNumber: 31,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/frontend/src/components/modals/CreateProjectModal.tsx",
        lineNumber: 30,
        columnNumber: 10
    }, this);
}
_s(CreateProjectModal, "bzuncdVN93XlwhF2yV41O5EILHA=");
_c = CreateProjectModal;
var _c;
__turbopack_context__.k.register(_c, "CreateProjectModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/Button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
// src/components/ui/Button.tsx
"use client";
;
;
const variants = {
    "voir": "text-xs bg-btn-black w-30.25 h-12.5 text-text-white hover:text-brand-dark hover:bg-bg-content hover:border border-brand-dark focus:ring-2 focus:ring-brand-dark rounded-md transition",
    "creer-projet": "px-4 py-2 w-45.25 h-12.5 rounded-md bg-btn-2-Black text-white text-[16px] hover:text-brand-dark hover:bg-bg-content hover:border border-brand-dark transition",
    "creer-tache": "w-35.25 h-12.5 bg-btn-black text-text-white text-sm rounded-[10px] hover:text-brand-dark hover:bg-bg-content border border-brand-dark transition"
};
function Button(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "81e098c372daa21abd5d28d6af1f1c4f4ce27ca90c6a7e764e71161e1d253c47") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "81e098c372daa21abd5d28d6af1f1c4f4ce27ca90c6a7e764e71161e1d253c47";
    }
    const { variant: t1, children, onClick, type: t2, disabled, className: t3, ariaLabel } = t0;
    const variant = t1 === undefined ? "voir" : t1;
    const type = t2 === undefined ? "button" : t2;
    const className = t3 === undefined ? "" : t3;
    const t4 = `${variants[variant]} disabled:opacity-50 ${className}`;
    let t5;
    if ($[1] !== ariaLabel || $[2] !== children || $[3] !== disabled || $[4] !== onClick || $[5] !== t4 || $[6] !== type) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: type,
            onClick: onClick,
            disabled: disabled,
            "aria-label": ariaLabel,
            className: t4,
            children: children
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/Button.tsx",
            lineNumber: 43,
            columnNumber: 10
        }, this);
        $[1] = ariaLabel;
        $[2] = children;
        $[3] = disabled;
        $[4] = onClick;
        $[5] = t4;
        $[6] = type;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    return t5;
}
_c = Button;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/app/dashboard/projects/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectsPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useProjects.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useModal.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$projects$2f$ProjectCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/projects/ProjectCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$CreateProjectModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/CreateProjectModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/Button.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function ProjectsPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(35);
    if ($[0] !== "fe92c51953e69de920f5ff6effeaa5b0ab95a684787f8694a58b329c1a2d8371") {
        for(let $i = 0; $i < 35; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "fe92c51953e69de920f5ff6effeaa5b0ab95a684787f8694a58b329c1a2d8371";
    }
    const { projects, loading, error, fetchProjects, createProject } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjects"])();
    const { isOpen, openModal, closeModal } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModal"])();
    let t0;
    let t1;
    if ($[1] !== fetchProjects) {
        t0 = ({
            "ProjectsPage[useEffect()]": ()=>{
                fetchProjects();
            }
        })["ProjectsPage[useEffect()]"];
        t1 = [
            fetchProjects
        ];
        $[1] = fetchProjects;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    let t2;
    if ($[4] !== createProject || $[5] !== fetchProjects) {
        t2 = async function handleCreateProject(name, description, contributors) {
            ;
            try {
                const contributorEmails = contributors.map(_ProjectsPageHandleCreateProjectContributorsMap);
                const projectId = await createProject(name, description, contributorEmails);
                if (!projectId) {
                    return;
                }
                await fetchProjects();
            } catch (t3) {
                const error_0 = t3;
                console.error("Erreur lors de la cr\xE9ation du projet:", error_0);
                throw error_0;
            }
        };
        $[4] = createProject;
        $[5] = fetchProjects;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    const handleCreateProject = t2;
    let t3;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-[28px] font-semibold text-text-primary",
                    children: "Mes projets"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
                    lineNumber: 74,
                    columnNumber: 47
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-lg text-police-black",
                    children: "Gérez vos projets"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
                    lineNumber: 74,
                    columnNumber: 123
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
            lineNumber: 74,
            columnNumber: 10
        }, this);
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    let t4;
    if ($[8] !== openModal) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-start justify-between",
            children: [
                t3,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "creer-projet",
                    onClick: {
                        "ProjectsPage[<Button>.onClick]": ()=>openModal("createProject")
                    }["ProjectsPage[<Button>.onClick]"],
                    ariaLabel: "Cr\xE9er un nouveau projet",
                    children: "+ Créer un projet"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
                    lineNumber: 81,
                    columnNumber: 64
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[8] = openModal;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    let t5;
    if ($[10] !== loading) {
        t5 = loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            role: "status",
            "aria-live": "polite",
            className: "text-sm text-text-secondary",
            children: "Chargement des projets..."
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
            lineNumber: 91,
            columnNumber: 21
        }, this);
        $[10] = loading;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    let t6;
    if ($[12] !== error || $[13] !== loading) {
        t6 = !loading && error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            role: "alert",
            "aria-live": "assertive",
            className: "text-sm text-system-error",
            children: error
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
            lineNumber: 99,
            columnNumber: 31
        }, this);
        $[12] = error;
        $[13] = loading;
        $[14] = t6;
    } else {
        t6 = $[14];
    }
    let t7;
    if ($[15] !== error || $[16] !== loading || $[17] !== openModal || $[18] !== projects) {
        t7 = !loading && !error && projects.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-center justify-center py-20 gap-3",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-text-secondary text-sm",
                    children: "Aucun projet pour le moment."
                }, void 0, false, {
                    fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
                    lineNumber: 108,
                    columnNumber: 128
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: {
                        "ProjectsPage[<button>.onClick]": ()=>openModal("createProject")
                    }["ProjectsPage[<button>.onClick]"],
                    className: "px-4 py-2 bg-btn-black text-text-white text-sm font-medium rounded-md hover:opacity-90 transition",
                    children: "+ Créer votre premier projet"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
                    lineNumber: 108,
                    columnNumber: 203
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
            lineNumber: 108,
            columnNumber: 57
        }, this);
        $[15] = error;
        $[16] = loading;
        $[17] = openModal;
        $[18] = projects;
        $[19] = t7;
    } else {
        t7 = $[19];
    }
    let t8;
    if ($[20] !== error || $[21] !== loading || $[22] !== projects) {
        t8 = !loading && !error && projects.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
            className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5",
            "aria-label": "Liste des projets",
            children: projects.map(_ProjectsPageProjectsMap)
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
            lineNumber: 121,
            columnNumber: 55
        }, this);
        $[20] = error;
        $[21] = loading;
        $[22] = projects;
        $[23] = t8;
    } else {
        t8 = $[23];
    }
    let t9;
    if ($[24] !== closeModal || $[25] !== handleCreateProject || $[26] !== isOpen) {
        t9 = isOpen("createProject") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$CreateProjectModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClose: closeModal,
            onSubmit: handleCreateProject
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
            lineNumber: 131,
            columnNumber: 37
        }, this);
        $[24] = closeModal;
        $[25] = handleCreateProject;
        $[26] = isOpen;
        $[27] = t9;
    } else {
        t9 = $[27];
    }
    let t10;
    if ($[28] !== t4 || $[29] !== t5 || $[30] !== t6 || $[31] !== t7 || $[32] !== t8 || $[33] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-8",
            children: [
                t4,
                t5,
                t6,
                t7,
                t8,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
            lineNumber: 141,
            columnNumber: 11
        }, this);
        $[28] = t4;
        $[29] = t5;
        $[30] = t6;
        $[31] = t7;
        $[32] = t8;
        $[33] = t9;
        $[34] = t10;
    } else {
        t10 = $[34];
    }
    return t10;
}
_s(ProjectsPage, "7Wz1Johb2xWKJg9LvSAxJnd3N8g=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjects"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModal"]
    ];
});
_c = ProjectsPage;
function _ProjectsPageProjectsMap(project) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$projects$2f$ProjectCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            project: project
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
            lineNumber: 155,
            columnNumber: 31
        }, this)
    }, project.id, false, {
        fileName: "[project]/frontend/src/app/dashboard/projects/page.tsx",
        lineNumber: 155,
        columnNumber: 10
    }, this);
}
function _ProjectsPageHandleCreateProjectContributorsMap(u) {
    return u.email;
}
var _c;
__turbopack_context__.k.register(_c, "ProjectsPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=frontend_src_8880fb54._.js.map