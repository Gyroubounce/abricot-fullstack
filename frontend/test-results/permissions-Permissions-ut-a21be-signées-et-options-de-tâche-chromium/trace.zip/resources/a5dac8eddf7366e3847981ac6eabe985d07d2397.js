(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/frontend_src_979e3847._.js",
  "static/chunks/9e883_a8fb9739._.js"
],
    source: "dynamic"
});
