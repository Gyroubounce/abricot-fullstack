(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/frontend_src_fbaed865._.js",
  "static/chunks/9e883_@heroicons_react_24_11166541._.js"
],
    source: "dynamic"
});
