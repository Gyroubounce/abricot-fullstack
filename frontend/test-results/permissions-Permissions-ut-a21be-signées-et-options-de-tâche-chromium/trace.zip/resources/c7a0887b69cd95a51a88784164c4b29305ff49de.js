(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/9e883_8ca5fbd7._.js",
  "static/chunks/frontend_src_0c80bc1b._.js"
],
    source: "dynamic"
});
