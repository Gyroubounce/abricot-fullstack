(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "apiRequest",
    ()=>apiRequest
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const BASE_URL = ("TURBOPACK compile-time value", "http://localhost:8000");
async function apiRequest(endpoint, options = {}) {
    const { method = "GET", body } = options;
    try {
        const res = await fetch(`${BASE_URL}${endpoint}`, {
            method,
            headers: body ? {
                "Content-Type": "application/json"
            } : undefined,
            credentials: "include",
            body: body ? JSON.stringify(body) : undefined
        });
        const json = await res.json();
        if (!res.ok) {
            return {
                data: null,
                error: json.message || `Erreur ${res.status}`
            };
        }
        return {
            data: json.data,
            error: null
        };
    } catch  {
        return {
            data: null,
            error: "Erreur réseau. Vérifiez votre connexion."
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useApi.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/utils/task.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "priorityLabel",
    ()=>priorityLabel,
    "priorityOrder",
    ()=>priorityOrder,
    "statusColor",
    ()=>statusColor,
    "statusLabel",
    ()=>statusLabel
]);
const statusLabel = {
    TODO: "À faire",
    IN_PROGRESS: "En cours",
    DONE: "Terminée",
    CANCELLED: "Annulée"
};
const statusColor = {
    TODO: "bg-system-error text-text-error",
    IN_PROGRESS: "bg-brand-light text-brand-dark",
    DONE: "bg-system-success text-text-success",
    CANCELLED: "bg-system-neutral text-text-secondary"
};
const priorityLabel = {
    LOW: "Basse",
    MEDIUM: "Moyenne",
    HIGH: "Haute",
    URGENT: "Urgente"
};
const priorityOrder = {
    URGENT: 0,
    HIGH: 1,
    MEDIUM: 2,
    LOW: 3
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useDashboard.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDashboard",
    ()=>useDashboard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useAuth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useApi.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/task.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function useDashboard() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "4bf2292cfc5d2f6151c850f9e452cefeb297e5637e2df07f27b085683807f999") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4bf2292cfc5d2f6151c850f9e452cefeb297e5637e2df07f27b085683807f999";
    }
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [projects, setProjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [tasks, setTasks] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t2;
    if ($[3] !== user) {
        t2 = ({
            "useDashboard[fetchAll]": async ()=>{
                setLoading(true);
                setError(null);
                const { data: projectData, error: projectErr } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])("/projects");
                if (projectErr || !projectData) {
                    setError(projectErr ?? "Erreur lors du chargement");
                    setLoading(false);
                    return;
                }
                const projectList = projectData.projects;
                setProjects(projectList);
                const taskResults = await Promise.all(projectList.map(_useDashboardFetchAllProjectListMap));
                const allTasks = taskResults.flat();
                const myTasks = allTasks.filter({
                    "useDashboard[fetchAll > allTasks.filter()]": (task_0)=>task_0.assignees.some({
                            "useDashboard[fetchAll > allTasks.filter() > task_0.assignees.some()]": (a)=>a.user.id === user.id
                        }["useDashboard[fetchAll > allTasks.filter() > task_0.assignees.some()]"])
                }["useDashboard[fetchAll > allTasks.filter()]"]).sort(_useDashboardFetchAllAnonymous);
                setTasks(myTasks);
                setLoading(false);
            }
        })["useDashboard[fetchAll]"];
        $[3] = user;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const fetchAll = t2;
    let t3;
    let t4;
    if ($[5] !== fetchAll || $[6] !== user) {
        t3 = ({
            "useDashboard[useEffect()]": ()=>{
                if (!user) {
                    return;
                }
                fetchAll();
            }
        })["useDashboard[useEffect()]"];
        t4 = [
            user,
            fetchAll
        ];
        $[5] = fetchAll;
        $[6] = user;
        $[7] = t3;
        $[8] = t4;
    } else {
        t3 = $[7];
        t4 = $[8];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    let t5;
    if ($[9] !== fetchAll) {
        t5 = async function updateTaskStatus(taskId, projectId, newStatus) {
            setTasks({
                "useDashboard[updateTaskStatus > setTasks()]": (prev)=>prev.map({
                        "useDashboard[updateTaskStatus > setTasks() > prev.map()]": (t)=>t.id === taskId ? {
                                ...t,
                                status: newStatus
                            } : t
                    }["useDashboard[updateTaskStatus > setTasks() > prev.map()]"])
            }["useDashboard[updateTaskStatus > setTasks()]"]);
            const { error: err } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks/${taskId}`, {
                method: "PUT",
                body: {
                    status: newStatus
                }
            });
            if (err) {
                await fetchAll();
            }
        };
        $[9] = fetchAll;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    const updateTaskStatus = t5;
    let t6;
    if ($[11] !== error || $[12] !== loading || $[13] !== projects || $[14] !== tasks || $[15] !== updateTaskStatus) {
        t6 = {
            projects,
            tasks,
            loading,
            error,
            updateTaskStatus
        };
        $[11] = error;
        $[12] = loading;
        $[13] = projects;
        $[14] = tasks;
        $[15] = updateTaskStatus;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    return t6;
}
_s(useDashboard, "2bnVsJd9Q6NrcAkcUkaJH7I40ik=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
function _useDashboardFetchAllAnonymous(a_0, b) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["priorityOrder"][a_0.priority] - __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["priorityOrder"][b.priority];
}
async function _useDashboardFetchAllProjectListMap(project) {
    const { data } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${project.id}/tasks`);
    return (data?.tasks ?? []).map({
        "useDashboard[fetchAll > projectList.map() > (anonymous)()]": (task)=>({
                ...task,
                projectName: project.name
            })
    }["useDashboard[fetchAll > projectList.map() > (anonymous)()]"]);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useModal.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useModal",
    ()=>useModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useModal() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "dcb9475c53dcb8c3bf3fd696417f973ef49db524180eca58b087d6d6c7455971") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "dcb9475c53dcb8c3bf3fd696417f973ef49db524180eca58b087d6d6c7455971";
    }
    const [activeModal, setActiveModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = function openModal(name) {
            setActiveModal(name);
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const openModal = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = function closeModal() {
            setActiveModal(null);
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const closeModal = t1;
    let t2;
    if ($[3] !== activeModal) {
        t2 = function isOpen(name_0) {
            return activeModal === name_0;
        };
        $[3] = activeModal;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const isOpen = t2;
    let t3;
    if ($[5] !== activeModal || $[6] !== isOpen) {
        t3 = {
            activeModal,
            openModal,
            closeModal,
            isOpen
        };
        $[5] = activeModal;
        $[6] = isOpen;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    return t3;
}
_s(useModal, "kAcpyZCE6YA2McoeUdamFLX5os8=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/api/projects.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addContributor",
    ()=>addContributor,
    "createProject",
    ()=>createProject,
    "deleteProject",
    ()=>deleteProject,
    "fetchProject",
    ()=>fetchProject,
    "fetchProjectTasks",
    ()=>fetchProjectTasks,
    "fetchProjects",
    ()=>fetchProjects,
    "removeContributor",
    ()=>removeContributor,
    "updateProject",
    ()=>updateProject
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
;
async function fetchProjects() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])("/projects");
}
async function fetchProject(projectId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}`);
}
async function createProject(name, description, contributors// ✅ Ajouter ce paramètre
) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])("/projects", {
        method: "POST",
        body: {
            name,
            description,
            contributors
        }
    });
}
async function updateProject(projectId, name, description) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}`, {
        method: "PUT",
        body: {
            name,
            description
        }
    });
}
async function deleteProject(projectId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}`, {
        method: "DELETE"
    });
}
async function addContributor(projectId, email) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/contributors`, {
        method: "POST",
        body: {
            email
        }
    });
}
async function removeContributor(projectId, userId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/contributors/${userId}`, {
        method: "DELETE"
    });
}
async function fetchProjectTasks(projectId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks`);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useProjects.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useProjects",
    ()=>useProjects
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/projects.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useAuth.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function useProjects() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "cb915cc7e0bd634ef620f1c3ffbf16b3d600a7aa69fadd7f0d5095773233e695") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb915cc7e0bd634ef620f1c3ffbf16b3d600a7aa69fadd7f0d5095773233e695";
    }
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [projects, setProjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "useProjects[fetchProjects]": async ()=>{
                setLoading(true);
                setError(null);
                const { data, error: err } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchProjects"])();
                if (err || !data) {
                    setError(err ?? "Erreur lors du chargement des projets");
                    setLoading(false);
                    return;
                }
                const projectsWithStats = await Promise.all(data.projects.map(_useProjectsFetchProjectsDataProjectsMap));
                setProjects(projectsWithStats);
                setLoading(false);
            }
        })["useProjects[fetchProjects]"];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const fetchProjects = t1;
    let t2;
    if ($[3] !== user?.id) {
        t2 = async function createProject(name, description, contributors) {
            if (!user?.id) {
                throw new Error("Utilisateur non authentifi\xE9");
            }
            const uniqueContributors = contributors ?? [];
            const { data: data_0, error: err_0 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProject"])(name, description, uniqueContributors);
            if (err_0 || !data_0) {
                throw new Error(err_0 ?? "Erreur lors de la cr\xE9ation");
            }
            return data_0.project.id;
        };
        $[3] = user?.id;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const createProject = t2;
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = async function addContributor(projectId, email) {
            const { error: err_1 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addContributor"])(projectId, email);
            if (err_1) {
                throw new Error(err_1);
            }
            await fetchProjects();
        };
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const addContributor = t3;
    let t4;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = async function deleteProject(projectId_0) {
            const { error: error_0 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteProject"])(projectId_0);
            if (error_0) {
                throw new Error(error_0);
            }
            setProjects({
                "useProjects[deleteProject > setProjects()]": (prev)=>prev.filter({
                        "useProjects[deleteProject > setProjects() > prev.filter()]": (p)=>p.id !== projectId_0
                    }["useProjects[deleteProject > setProjects() > prev.filter()]"])
            }["useProjects[deleteProject > setProjects()]"]);
        };
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const deleteProject = t4;
    let t5;
    if ($[7] !== createProject || $[8] !== error || $[9] !== loading || $[10] !== projects) {
        t5 = {
            projects,
            loading,
            error,
            fetchProjects,
            createProject,
            addContributor,
            deleteProject
        };
        $[7] = createProject;
        $[8] = error;
        $[9] = loading;
        $[10] = projects;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    return t5;
}
_s(useProjects, "UNqomK9kSRMxUJ5mQmMybh1HwFo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
async function _useProjectsFetchProjectsDataProjectsMap(project) {
    const { data: taskData } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$projects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchProjectTasks"])(project.id);
    const tasks = taskData?.tasks ?? [];
    const completedTasks = tasks.filter(_useProjectsFetchProjectsDataProjectsMapTasksFilter).length;
    const totalTasks = tasks.length;
    const progression = totalTasks > 0 ? Math.round(completedTasks / totalTasks * 100) : 0;
    return {
        ...project,
        tasks,
        completedTasks,
        totalTasks,
        progression
    };
}
function _useProjectsFetchProjectsDataProjectsMapTasksFilter(t) {
    return t.status === "DONE";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/icons/ListIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ListIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
function ListIcon(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "f4f683f06a3b04e24be17b5104ca07f1471f2aef62a712b6bac31953c9a3b325") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f4f683f06a3b04e24be17b5104ca07f1471f2aef62a712b6bac31953c9a3b325";
    }
    const { className } = t0;
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M15.1111 7.82222C14.5778 7.82222 14.2222 8.17778 14.2222 8.71111V13.6889C14.2222 13.9556 13.9556 14.2222 13.6889 14.2222H2.31111C2.04444 14.2222 1.77778 13.9556 1.77778 13.6889V2.31111C1.77778 2.04444 2.04444 1.77778 2.31111 1.77778H10.8444C11.3778 1.77778 11.7333 1.42222 11.7333 0.888889C11.7333 0.355556 11.3778 0 10.8444 0H2.31111C1.06667 0 0 1.06667 0 2.31111V13.6889C0 14.9333 1.06667 16 2.31111 16H13.6889C14.9333 16 16 14.9333 16 13.6889V8.71111C16 8.26667 15.6444 7.82222 15.1111 7.82222Z"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/ListIcon.tsx",
            lineNumber: 17,
            columnNumber: 10
        }, this);
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M6.84435 7.11113C6.48879 6.75558 5.95546 6.84447 5.5999 7.20002C5.33324 7.46669 5.33324 8.00002 5.5999 8.35558L7.55546 10.4C7.73324 10.5778 7.91101 10.6667 8.17768 10.6667C8.44435 10.6667 8.62212 10.5778 8.7999 10.4L14.8443 4.1778C15.1999 3.82224 15.1999 3.28891 14.8443 2.93335C14.4888 2.5778 13.9555 2.5778 13.5999 2.93335L8.17768 8.53335L6.84435 7.11113Z"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/ListIcon.tsx",
            lineNumber: 18,
            columnNumber: 10
        }, this);
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    let t3;
    if ($[3] !== className) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: className,
            width: "16",
            height: "16",
            viewBox: "0 0 16 16",
            fill: "currentColor",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                t1,
                t2
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/icons/ListIcon.tsx",
            lineNumber: 27,
            columnNumber: 10
        }, this);
        $[3] = className;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    return t3;
}
_c = ListIcon;
var _c;
__turbopack_context__.k.register(_c, "ListIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/icons/CalenderIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CalenderIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
function CalenderIcon(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "893590dfb6ab043c9899da5fa5e55fadd712478904f4f80e859841e187049f45") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "893590dfb6ab043c9899da5fa5e55fadd712478904f4f80e859841e187049f45";
    }
    const { className } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M4.42285 0C4.10746 0 3.8457 0.261761 3.8457 0.577148V1.17871C1.39505 1.38897 0 2.96789 0 5.57715V12.1152C0 14.9229 1.61522 16.538 4.42285 16.5381H10.5771C13.3847 16.538 15 14.9229 15 12.1152V5.57715C15 2.96794 13.6049 1.38901 11.1543 1.17871V0.577148C11.1543 0.261782 10.8925 3.47543e-05 10.5771 0C10.2618 0 10 0.261761 10 0.577148V1.15332H5V0.577148C5 0.261793 4.7382 5.25452e-05 4.42285 0ZM13.8457 12.1152C13.8457 14.3152 12.777 15.3847 10.5771 15.3848H4.42285C2.22293 15.3847 1.15332 14.3152 1.15332 12.1152V6.60742H13.8457V12.1152ZM10.4844 11.4082C10.1998 11.2852 9.86186 11.3541 9.64648 11.5693C9.61572 11.6078 9.57679 11.6461 9.55371 11.6846C9.52294 11.7307 9.49976 11.7771 9.48438 11.8232C9.46134 11.8693 9.44616 11.9159 9.43848 11.9697C9.43082 12.0157 9.42288 12.0693 9.42285 12.1152C9.42285 12.3152 9.50802 12.516 9.64648 12.6621C9.7926 12.8003 9.99256 12.8848 10.1924 12.8848C10.2923 12.8848 10.3922 12.8616 10.4844 12.8232C10.5765 12.7848 10.6615 12.7312 10.7383 12.6621C10.8075 12.5852 10.8619 12.5081 10.9004 12.4082C10.9389 12.3159 10.9619 12.2152 10.9619 12.1152C10.9618 11.9153 10.8767 11.7154 10.7383 11.5693C10.6614 11.5001 10.5766 11.4466 10.4844 11.4082ZM10.0381 8.66895C9.99208 8.67665 9.94639 8.69283 9.90039 8.71582C9.85434 8.73117 9.80777 8.75352 9.76172 8.78418C9.72332 8.8149 9.68489 8.84623 9.64648 8.87695C9.61572 8.9154 9.57679 8.95374 9.55371 8.99219C9.52294 9.03834 9.49976 9.08471 9.48438 9.13086C9.46134 9.17696 9.44616 9.22343 9.43848 9.26953C9.43081 9.32318 9.42288 9.3692 9.42285 9.42285C9.42285 9.62285 9.50802 9.82357 9.64648 9.96973C9.7926 10.108 9.99256 10.1924 10.1924 10.1924C10.2923 10.1924 10.3922 10.1693 10.4844 10.1309C10.5765 10.0925 10.6614 10.0388 10.7383 9.96973C10.8075 9.89286 10.8619 9.80804 10.9004 9.71582C10.9389 9.62351 10.9619 9.52285 10.9619 9.42285C10.9618 9.22293 10.8767 9.02305 10.7383 8.87695C10.6614 8.80777 10.5766 8.75426 10.4844 8.71582C10.3459 8.65431 10.1919 8.63818 10.0381 8.66895ZM8.0459 8.87695C7.83052 8.66172 7.48485 8.59282 7.20801 8.71582C7.10806 8.75426 7.03098 8.80778 6.9541 8.87695C6.8157 9.02304 6.73055 9.22294 6.73047 9.42285C6.73047 9.4767 6.7384 9.5233 6.74609 9.57715C6.75379 9.62325 6.76894 9.66972 6.79199 9.71582C6.80733 9.76177 6.83074 9.80757 6.86133 9.85352C6.8921 9.89198 6.92333 9.93126 6.9541 9.96973C7.03091 10.0388 7.10815 10.0925 7.20801 10.1309C7.30023 10.1693 7.4001 10.1924 7.5 10.1924C7.69983 10.1924 7.89978 10.108 8.0459 9.96973C8.07667 9.93126 8.1079 9.89198 8.13867 9.85352C8.16927 9.80756 8.19266 9.76177 8.20801 9.71582C8.23106 9.66972 8.2462 9.62325 8.25391 9.57715C8.2616 9.5233 8.26953 9.4767 8.26953 9.42285C8.26949 9.32299 8.2464 9.22305 8.20801 9.13086C8.16955 9.03855 8.11513 8.95388 8.0459 8.87695ZM10 2.88477C10.0001 3.20009 10.2618 3.46191 10.5771 3.46191C10.8925 3.46188 11.1542 3.20007 11.1543 2.88477V2.33789C12.9266 2.51306 13.806 3.53533 13.8418 5.4541H1.15723C1.193 3.53528 2.07336 2.51303 3.8457 2.33789V2.88477C3.84578 3.20009 4.10751 3.46191 4.42285 3.46191C4.73815 3.46186 4.99992 3.20006 5 2.88477V2.30762H10V2.88477Z"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/CalenderIcon.tsx",
            lineNumber: 16,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== className) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: className,
            width: "15",
            height: "17",
            viewBox: "0 0 15 17",
            fill: "currentColor",
            xmlns: "http://www.w3.org/2000/svg",
            children: t1
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/CalenderIcon.tsx",
            lineNumber: 23,
            columnNumber: 10
        }, this);
        $[2] = className;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_c = CalenderIcon;
var _c;
__turbopack_context__.k.register(_c, "CalenderIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/Button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
// src/components/ui/Button.tsx
"use client";
;
;
const variants = {
    "voir": "text-xs bg-btn-black w-30.25 h-12.5 text-text-white hover:text-brand-dark hover:bg-bg-content hover:border border-brand-dark focus:ring-2 focus:ring-brand-dark rounded-md transition",
    "creer-projet": "px-4 py-2 w-45.25 h-12.5 rounded-md bg-btn-2-Black text-white text-[16px] hover:text-brand-dark hover:bg-bg-content hover:border border-brand-dark transition",
    "creer-tache": "w-35.25 h-12.5 bg-btn-black text-text-white text-sm rounded-[10px] hover:text-brand-dark hover:bg-bg-content border border-brand-dark transition"
};
function Button(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "81e098c372daa21abd5d28d6af1f1c4f4ce27ca90c6a7e764e71161e1d253c47") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "81e098c372daa21abd5d28d6af1f1c4f4ce27ca90c6a7e764e71161e1d253c47";
    }
    const { variant: t1, children, onClick, type: t2, disabled, className: t3, ariaLabel } = t0;
    const variant = t1 === undefined ? "voir" : t1;
    const type = t2 === undefined ? "button" : t2;
    const className = t3 === undefined ? "" : t3;
    const t4 = `${variants[variant]} disabled:opacity-50 ${className}`;
    let t5;
    if ($[1] !== ariaLabel || $[2] !== children || $[3] !== disabled || $[4] !== onClick || $[5] !== t4 || $[6] !== type) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: type,
            onClick: onClick,
            disabled: disabled,
            "aria-label": ariaLabel,
            className: t4,
            children: children
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/Button.tsx",
            lineNumber: 43,
            columnNumber: 10
        }, this);
        $[1] = ariaLabel;
        $[2] = children;
        $[3] = disabled;
        $[4] = onClick;
        $[5] = t4;
        $[6] = type;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    return t5;
}
_c = Button;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/dashboard/DashboardHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DashboardHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$ListIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/ListIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CalenderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/CalenderIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/Button.tsx [app-client] (ecmascript)");
;
;
;
;
;
function DashboardHeader(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(27);
    if ($[0] !== "832f8ef451d25200a94970fafc1ca1a4b2d353b059b661482dbffab0ce306cc1") {
        for(let $i = 0; $i < 27; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "832f8ef451d25200a94970fafc1ca1a4b2d353b059b661482dbffab0ce306cc1";
    }
    const { name, onCreateProject, view, onViewChange } = t0;
    console.log("NAME FRONT:", name);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-[24px] font-semibold text-text-primary",
            children: "Tableau de bord"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/DashboardHeader.tsx",
            lineNumber: 28,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== name) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t1,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-[18px] text-black",
                    children: [
                        "Bonjour ",
                        name,
                        ", voici un aperçu de vos projets et tâches."
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/dashboard/DashboardHeader.tsx",
                    lineNumber: 35,
                    columnNumber: 51
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/DashboardHeader.tsx",
            lineNumber: 35,
            columnNumber: 10
        }, this);
        $[2] = name;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] !== onCreateProject) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "creer-projet",
            onClick: {
                "DashboardHeader[<Button>.onClick]": ()=>onCreateProject()
            }["DashboardHeader[<Button>.onClick]"],
            ariaLabel: "Cr\xE9er un nouveau projet",
            children: "+ Créer un projet"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/DashboardHeader.tsx",
            lineNumber: 43,
            columnNumber: 10
        }, this);
        $[4] = onCreateProject;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== t2 || $[7] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-between",
            children: [
                t2,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/DashboardHeader.tsx",
            lineNumber: 53,
            columnNumber: 10
        }, this);
        $[6] = t2;
        $[7] = t3;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    if ($[9] !== onViewChange) {
        t5 = ({
            "DashboardHeader[<button>.onClick]": ()=>onViewChange("list")
        })["DashboardHeader[<button>.onClick]"];
        $[9] = onViewChange;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    const t6 = `px-4 py-2 w-23.5 h-11.25 rounded-md flex items-center gap-3 text-sm transition ${view === "list" ? "bg-brand-light text-brand-dark font-medium" : "bg-bg-content text-brand-dark hover:bg-brand-light hover:text-brand-dark"}`;
    let t7;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$ListIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: "w-4 h-4",
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/DashboardHeader.tsx",
            lineNumber: 73,
            columnNumber: 10
        }, this);
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] !== t5 || $[13] !== t6) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: t5,
            "aria-pressed": "false",
            className: t6,
            children: [
                t7,
                "Liste"
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/DashboardHeader.tsx",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        $[12] = t5;
        $[13] = t6;
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    let t9;
    if ($[15] !== onViewChange) {
        t9 = ({
            "DashboardHeader[<button>.onClick]": ()=>onViewChange("kanban")
        })["DashboardHeader[<button>.onClick]"];
        $[15] = onViewChange;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    const t10 = `px-3 py-2 rounded-md flex items-center gap-3 text-sm transition ${view === "kanban" ? "bg-brand-light text-brand-dark font-medium" : "bg-bg-content text-brand-dark hover:bg-brand-light hover:text-brand-dark"}`;
    let t11;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CalenderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: "w-5 h-5 shrink-0",
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/DashboardHeader.tsx",
            lineNumber: 100,
            columnNumber: 11
        }, this);
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    if ($[18] !== t10 || $[19] !== t9) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: t9,
            "aria-pressed": "false",
            className: t10,
            children: [
                t11,
                "Kanban"
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/DashboardHeader.tsx",
            lineNumber: 107,
            columnNumber: 11
        }, this);
        $[18] = t10;
        $[19] = t9;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] !== t12 || $[22] !== t8) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-3",
            role: "group",
            "aria-label": "Mode d'affichage",
            children: [
                t8,
                t12
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/DashboardHeader.tsx",
            lineNumber: 116,
            columnNumber: 11
        }, this);
        $[21] = t12;
        $[22] = t8;
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    let t14;
    if ($[24] !== t13 || $[25] !== t4) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-12 my-8",
            children: [
                t4,
                t13
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/DashboardHeader.tsx",
            lineNumber: 125,
            columnNumber: 11
        }, this);
        $[24] = t13;
        $[25] = t4;
        $[26] = t14;
    } else {
        t14 = $[26];
    }
    return t14;
}
_c = DashboardHeader;
var _c;
__turbopack_context__.k.register(_c, "DashboardHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/icons/CommentsIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommentsIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
function CommentsIcon(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "119a4b283197af37f40d07a5b4b951ab889af04963ede47ee483e472a8b2a490") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "119a4b283197af37f40d07a5b4b951ab889af04963ede47ee483e472a8b2a490";
    }
    const { className } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M12.0311 0H2.97479C1.33353 0 0.00293083 1.3359 0 2.98009V9.97376C0.00293083 11.6179 1.33353 12.9538 2.97479 12.9538H5.44255L7.06037 14.8006C7.27432 15.0443 7.64361 15.0678 7.88687 14.8535C7.90445 14.8359 7.92204 14.8212 7.93962 14.8006L9.55744 12.9538H12.0252C13.6694 12.9538 15 11.6179 15 9.97376V2.98009C15.0029 1.33297 13.6723 0 12.0311 0ZM11.1723 9.90329H3.83353C3.51114 9.90329 3.24736 9.63905 3.24736 9.31608C3.24736 8.99312 3.51114 8.72887 3.83353 8.72887H11.1723C11.4947 8.72887 11.7585 8.99312 11.7585 9.31608C11.7585 9.63905 11.4947 9.90329 11.1723 9.90329ZM11.1723 7.02597H3.83353C3.51114 7.02597 3.24736 6.76172 3.24736 6.43876C3.24736 6.11579 3.51114 5.85155 3.83353 5.85155H11.1723C11.4947 5.85155 11.7585 6.11579 11.7585 6.43876C11.7585 6.76172 11.4947 7.02597 11.1723 7.02597ZM11.1723 4.14864H3.83353C3.51114 4.14864 3.24736 3.88439 3.24736 3.56143C3.24736 3.23846 3.51114 2.97422 3.83353 2.97422H11.1723C11.4947 2.97422 11.7585 3.23846 11.7585 3.56143C11.7585 3.88439 11.4947 4.14864 11.1723 4.14864Z"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/CommentsIcon.tsx",
            lineNumber: 16,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== className) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: className,
            width: "15",
            height: "15",
            viewBox: "0 0 15 15",
            fill: "currentColor",
            xmlns: "http://www.w3.org/2000/svg",
            children: t1
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/icons/CommentsIcon.tsx",
            lineNumber: 23,
            columnNumber: 10
        }, this);
        $[2] = className;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_c = CommentsIcon;
var _c;
__turbopack_context__.k.register(_c, "CommentsIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/utils/format.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatDate",
    ()=>formatDate,
    "formatDateInput",
    ()=>formatDateInput,
    "formatDateTime",
    ()=>formatDateTime
]);
function formatDate(dateStr) {
    if (!dateStr) return "";
    return new Date(dateStr).toLocaleDateString("fr-FR", {
        day: "numeric",
        month: "long"
    });
}
function formatDateTime(dateStr) {
    if (!dateStr) return "";
    return new Date(dateStr).toLocaleDateString("fr-FR", {
        day: "numeric",
        month: "long",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
    });
}
function formatDateInput(dateStr) {
    if (!dateStr) return "";
    return dateStr.split("T")[0];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/dashboard/TaskCardList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TaskCardList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$FolderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/FolderIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CalenderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/CalenderIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CommentsIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/CommentsIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/task.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/Button.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
function TaskCardList(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(33);
    if ($[0] !== "b9e966216f944857c60e1db8a914289721ce92c7b32b0ca1dedf00c7f3c4b56b") {
        for(let $i = 0; $i < 33; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b9e966216f944857c60e1db8a914289721ce92c7b32b0ca1dedf00c7f3c4b56b";
    }
    const { task, onEdit } = t0;
    const t1 = `Tâche : ${task.title}`;
    let t2;
    if ($[1] !== task.title) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "font-semibold text-black text-sm truncate",
            children: task.title
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
            lineNumber: 31,
            columnNumber: 10
        }, this);
        $[1] = task.title;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== task.description) {
        t3 = task.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-xs text-text-secondary line-clamp-2",
            children: task.description
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
            lineNumber: 39,
            columnNumber: 30
        }, this);
        $[3] = task.description;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$FolderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: "h-3.5 w-3.5",
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
            lineNumber: 47,
            columnNumber: 10
        }, this);
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== task.projectName) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "flex items-center gap-1",
            children: [
                t4,
                task.projectName
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
            lineNumber: 54,
            columnNumber: 10
        }, this);
        $[6] = task.projectName;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] !== task.dueDate) {
        t6 = task.dueDate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    "aria-hidden": "true",
                    className: "w-px h-2 bg-text-secondary inline-block"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
                    lineNumber: 62,
                    columnNumber: 28
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CalenderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            className: "h-3.5 w-3.5",
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
                            lineNumber: 62,
                            columnNumber: 149
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("time", {
                            dateTime: task.dueDate,
                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(task.dueDate)
                        }, void 0, false, {
                            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
                            lineNumber: 62,
                            columnNumber: 208
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
                    lineNumber: 62,
                    columnNumber: 107
                }, this)
            ]
        }, void 0, true);
        $[8] = task.dueDate;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] !== task.comments.length) {
        t7 = task.comments.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    "aria-hidden": "true",
                    className: "w-px h-2 bg-text-secondary inline-block"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
                    lineNumber: 70,
                    columnNumber: 40
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-1",
                    "aria-label": `${task.comments.length} commentaire${task.comments.length > 1 ? "s" : ""}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CommentsIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            className: "h-3.5 w-3.5",
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
                            lineNumber: 70,
                            columnNumber: 250
                        }, this),
                        task.comments.length
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
                    lineNumber: 70,
                    columnNumber: 119
                }, this)
            ]
        }, void 0, true);
        $[10] = task.comments.length;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] !== t5 || $[13] !== t6 || $[14] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-3 text-xs text-text-secondary flex-wrap my-5",
            children: [
                t5,
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
            lineNumber: 78,
            columnNumber: 10
        }, this);
        $[12] = t5;
        $[13] = t6;
        $[14] = t7;
        $[15] = t8;
    } else {
        t8 = $[15];
    }
    let t9;
    if ($[16] !== t2 || $[17] !== t3 || $[18] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1 mt-4 mb-2 flex-1 min-w-0",
            children: [
                t2,
                t3,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
            lineNumber: 88,
            columnNumber: 10
        }, this);
        $[16] = t2;
        $[17] = t3;
        $[18] = t8;
        $[19] = t9;
    } else {
        t9 = $[19];
    }
    const t10 = `text-xs px-2 py-1 rounded-full ${__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusColor"][task.status]}`;
    const t11 = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusLabel"][task.status];
    let t12;
    if ($[20] !== t10 || $[21] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: t10,
            children: t11
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
            lineNumber: 100,
            columnNumber: 11
        }, this);
        $[20] = t10;
        $[21] = t11;
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    let t13;
    if ($[23] !== onEdit || $[24] !== task) {
        t13 = onEdit && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "voir",
            onClick: {
                "TaskCardList[<Button>.onClick]": ()=>onEdit(task)
            }["TaskCardList[<Button>.onClick]"],
            ariaLabel: `Voir la tâche ${task.title}`,
            children: "Voir"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
            lineNumber: 109,
            columnNumber: 21
        }, this);
        $[23] = onEdit;
        $[24] = task;
        $[25] = t13;
    } else {
        t13 = $[25];
    }
    let t14;
    if ($[26] !== t12 || $[27] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-end mt-4 gap-5 shrink-0",
            children: [
                t12,
                t13
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
            lineNumber: 120,
            columnNumber: 11
        }, this);
        $[26] = t12;
        $[27] = t13;
        $[28] = t14;
    } else {
        t14 = $[28];
    }
    let t15;
    if ($[29] !== t1 || $[30] !== t14 || $[31] !== t9) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-bg-content rounded-[8px] shadow-card px-7 flex items-start justify-between gap-4 border border-bg-grey-border",
            "aria-label": t1,
            children: [
                t9,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardList.tsx",
            lineNumber: 129,
            columnNumber: 11
        }, this);
        $[29] = t1;
        $[30] = t14;
        $[31] = t9;
        $[32] = t15;
    } else {
        t15 = $[32];
    }
    return t15;
}
_c = TaskCardList;
var _c;
__turbopack_context__.k.register(_c, "TaskCardList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/dashboard/TaskCardKanban.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TaskCardKanban
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$FolderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/FolderIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CalenderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/CalenderIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CommentsIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/icons/CommentsIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/@dnd-kit/sortable/dist/sortable.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/@dnd-kit/utilities/dist/utilities.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/task.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/Button.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function TaskCardKanban(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(48);
    if ($[0] !== "4b557f7cb7afe3fb7f65b874eced22fdb46a947a773baeddfae9ef055307c351") {
        for(let $i = 0; $i < 48; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4b557f7cb7afe3fb7f65b874eced22fdb46a947a773baeddfae9ef055307c351";
    }
    const { task, onEdit } = t0;
    let t1;
    if ($[1] !== task.id) {
        t1 = {
            id: task.id
        };
        $[1] = task.id;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSortable"])(t1);
    let t2;
    if ($[3] !== transform) {
        t2 = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CSS"].Transform.toString(transform);
        $[3] = transform;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const t3 = isDragging ? 0.4 : 1;
    let t4;
    if ($[5] !== t2 || $[6] !== t3 || $[7] !== transition) {
        t4 = {
            transform: t2,
            transition,
            opacity: t3
        };
        $[5] = t2;
        $[6] = t3;
        $[7] = transition;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const style = t4;
    const t5 = `Tâche : ${task.title}`;
    let t6;
    if ($[9] !== task.title) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "font-semibold text-black text-[18px]",
            children: task.title
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
            lineNumber: 75,
            columnNumber: 10
        }, this);
        $[9] = task.title;
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    const t7 = `mb-5 shrink-0 text-xs font-medium px-2 py-1 rounded-full ${__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusColor"][task.status]}`;
    const t8 = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusLabel"][task.status];
    let t9;
    if ($[11] !== t7 || $[12] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: t7,
            children: t8
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
            lineNumber: 85,
            columnNumber: 10
        }, this);
        $[11] = t7;
        $[12] = t8;
        $[13] = t9;
    } else {
        t9 = $[13];
    }
    let t10;
    if ($[14] !== t6 || $[15] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-between gap-2",
            children: [
                t6,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
            lineNumber: 94,
            columnNumber: 11
        }, this);
        $[14] = t6;
        $[15] = t9;
        $[16] = t10;
    } else {
        t10 = $[16];
    }
    let t11;
    if ($[17] !== task.description) {
        t11 = task.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-[14px] text-text-secondary line-clamp-3",
            children: task.description
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
            lineNumber: 103,
            columnNumber: 31
        }, this);
        $[17] = task.description;
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$FolderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: "h-3.5 w-3.5",
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
            lineNumber: 111,
            columnNumber: 11
        }, this);
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    let t13;
    if ($[20] !== task.projectName) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "flex items-center gap-1",
            children: [
                t12,
                task.projectName
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
            lineNumber: 118,
            columnNumber: 11
        }, this);
        $[20] = task.projectName;
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    let t14;
    if ($[22] !== task.dueDate) {
        t14 = task.dueDate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    "aria-hidden": "true",
                    className: "w-px h-2 bg-text-secondary inline-block"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
                    lineNumber: 126,
                    columnNumber: 29
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CalenderIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            className: "h-3.5 w-3.5",
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
                            lineNumber: 126,
                            columnNumber: 150
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("time", {
                            dateTime: task.dueDate,
                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(task.dueDate)
                        }, void 0, false, {
                            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
                            lineNumber: 126,
                            columnNumber: 209
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
                    lineNumber: 126,
                    columnNumber: 108
                }, this)
            ]
        }, void 0, true);
        $[22] = task.dueDate;
        $[23] = t14;
    } else {
        t14 = $[23];
    }
    let t15;
    if ($[24] !== task.comments.length) {
        t15 = task.comments.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    "aria-hidden": "true",
                    className: "w-px h-2 bg-text-secondary inline-block"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
                    lineNumber: 134,
                    columnNumber: 41
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-1",
                    "aria-label": `${task.comments.length} commentaire${task.comments.length > 1 ? "s" : ""}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$icons$2f$CommentsIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            className: "h-3.5 w-3.5",
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
                            lineNumber: 134,
                            columnNumber: 251
                        }, this),
                        task.comments.length
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
                    lineNumber: 134,
                    columnNumber: 120
                }, this)
            ]
        }, void 0, true);
        $[24] = task.comments.length;
        $[25] = t15;
    } else {
        t15 = $[25];
    }
    let t16;
    if ($[26] !== t13 || $[27] !== t14 || $[28] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-2 text-xs text-text-secondary flex-wrap my-5",
            children: [
                t13,
                t14,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
            lineNumber: 142,
            columnNumber: 11
        }, this);
        $[26] = t13;
        $[27] = t14;
        $[28] = t15;
        $[29] = t16;
    } else {
        t16 = $[29];
    }
    let t17;
    if ($[30] !== attributes || $[31] !== listeners || $[32] !== t10 || $[33] !== t11 || $[34] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ...attributes,
            ...listeners,
            className: "px-6 pt-4 pb-2 cursor-grab active:cursor-grabbing flex flex-col gap-1",
            children: [
                t10,
                t11,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
            lineNumber: 152,
            columnNumber: 11
        }, this);
        $[30] = attributes;
        $[31] = listeners;
        $[32] = t10;
        $[33] = t11;
        $[34] = t16;
        $[35] = t17;
    } else {
        t17 = $[35];
    }
    let t18;
    if ($[36] !== onEdit || $[37] !== task) {
        t18 = ({
            "TaskCardKanban[<Button>.onClick]": ()=>onEdit(task)
        })["TaskCardKanban[<Button>.onClick]"];
        $[36] = onEdit;
        $[37] = task;
        $[38] = t18;
    } else {
        t18 = $[38];
    }
    const t19 = `Modifier la tâche ${task.title}`;
    let t20;
    if ($[39] !== t18 || $[40] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "px-6 pb-5",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "voir",
                onClick: t18,
                ariaLabel: t19,
                children: "Voir"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
                lineNumber: 176,
                columnNumber: 38
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
            lineNumber: 176,
            columnNumber: 11
        }, this);
        $[39] = t18;
        $[40] = t19;
        $[41] = t20;
    } else {
        t20 = $[41];
    }
    let t21;
    if ($[42] !== setNodeRef || $[43] !== style || $[44] !== t17 || $[45] !== t20 || $[46] !== t5) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: setNodeRef,
            style: style,
            className: "bg-bg-content rounded-[8px] shadow-card flex flex-col w-full border border-bg-grey-border",
            "aria-label": t5,
            children: [
                t17,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TaskCardKanban.tsx",
            lineNumber: 185,
            columnNumber: 11
        }, this);
        $[42] = setNodeRef;
        $[43] = style;
        $[44] = t17;
        $[45] = t20;
        $[46] = t5;
        $[47] = t21;
    } else {
        t21 = $[47];
    }
    return t21;
}
_s(TaskCardKanban, "9J/a3p2iAf7PAeqkD/B/H2PQwgk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSortable"]
    ];
});
_c = TaskCardKanban;
var _c;
__turbopack_context__.k.register(_c, "TaskCardKanban");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/dashboard/KanbanColumn.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>KanbanColumn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/@dnd-kit/core/dist/core.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/@dnd-kit/sortable/dist/sortable.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$dashboard$2f$TaskCardKanban$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/dashboard/TaskCardKanban.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function KanbanColumn(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(32);
    if ($[0] !== "509c41c350f3ba515165fa0ed0f83fe383479b8d528445e373447318f528919a") {
        for(let $i = 0; $i < 32; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "509c41c350f3ba515165fa0ed0f83fe383479b8d528445e373447318f528919a";
    }
    const { id, title, tasks, projects, onEdit } = t0;
    let t1;
    if ($[1] !== tasks) {
        t1 = tasks ?? [];
        $[1] = tasks;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const safeTasks = t1;
    let t2;
    if ($[3] !== id) {
        t2 = {
            id
        };
        $[3] = id;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const { setNodeRef, isOver } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDroppable"])(t2);
    const t3 = `Colonne ${title} — ${safeTasks.length} tâche${safeTasks.length > 1 ? "s" : ""}`;
    let t4;
    if ($[5] !== title) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "font-semibold text-text-primary text-[18px]",
            children: title
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/KanbanColumn.tsx",
            lineNumber: 54,
            columnNumber: 10
        }, this);
        $[5] = title;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const t5 = `${safeTasks.length} tâche${safeTasks.length > 1 ? "s" : ""}`;
    let t6;
    if ($[7] !== safeTasks.length || $[8] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-xs font-medium bg-bg-grey-light text-text-secondary px-2 py-0.5 rounded-full",
            "aria-label": t5,
            children: safeTasks.length
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/KanbanColumn.tsx",
            lineNumber: 63,
            columnNumber: 10
        }, this);
        $[7] = safeTasks.length;
        $[8] = t5;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] !== t4 || $[11] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-2 px-1",
            children: [
                t4,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/KanbanColumn.tsx",
            lineNumber: 72,
            columnNumber: 10
        }, this);
        $[10] = t4;
        $[11] = t6;
        $[12] = t7;
    } else {
        t7 = $[12];
    }
    const t8 = `rounded-[8px] min-h-50 transition-colors ${isOver ? "bg-brand-light" : "bg-bg-content"}`;
    let t9;
    if ($[13] !== safeTasks) {
        t9 = safeTasks.map(_KanbanColumnSafeTasksMap);
        $[13] = safeTasks;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== onEdit || $[16] !== projects || $[17] !== safeTasks) {
        t10 = safeTasks.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
            className: "text-xs text-text-secondary text-center mt-6",
            children: "Aucune tâche"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/KanbanColumn.tsx",
            lineNumber: 90,
            columnNumber: 36
        }, this) : safeTasks.map({
            "KanbanColumn[safeTasks.map()]": (task)=>{
                const taskProject = projects.find({
                    "KanbanColumn[safeTasks.map() > projects.find()]": (p)=>p.id === task.projectId
                }["KanbanColumn[safeTasks.map() > projects.find()]"]);
                const taskOwnerId = taskProject?.owner?.id;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$dashboard$2f$TaskCardKanban$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        task: task,
                        ownerId: taskOwnerId,
                        onEdit: onEdit
                    }, void 0, false, {
                        fileName: "[project]/frontend/src/components/dashboard/KanbanColumn.tsx",
                        lineNumber: 96,
                        columnNumber: 34
                    }, this)
                }, task.id, false, {
                    fileName: "[project]/frontend/src/components/dashboard/KanbanColumn.tsx",
                    lineNumber: 96,
                    columnNumber: 16
                }, this);
            }
        }["KanbanColumn[safeTasks.map()]"]);
        $[15] = onEdit;
        $[16] = projects;
        $[17] = safeTasks;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    let t11;
    if ($[19] !== t10) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
            className: "flex flex-col gap-3",
            children: t10
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/KanbanColumn.tsx",
            lineNumber: 108,
            columnNumber: 11
        }, this);
        $[19] = t10;
        $[20] = t11;
    } else {
        t11 = $[20];
    }
    let t12;
    if ($[21] !== t11 || $[22] !== t9) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SortableContext"], {
            items: t9,
            strategy: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["verticalListSortingStrategy"],
            children: t11
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/KanbanColumn.tsx",
            lineNumber: 116,
            columnNumber: 11
        }, this);
        $[21] = t11;
        $[22] = t9;
        $[23] = t12;
    } else {
        t12 = $[23];
    }
    let t13;
    if ($[24] !== setNodeRef || $[25] !== t12 || $[26] !== t8) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: setNodeRef,
            className: t8,
            children: t12
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/KanbanColumn.tsx",
            lineNumber: 125,
            columnNumber: 11
        }, this);
        $[24] = setNodeRef;
        $[25] = t12;
        $[26] = t8;
        $[27] = t13;
    } else {
        t13 = $[27];
    }
    let t14;
    if ($[28] !== t13 || $[29] !== t3 || $[30] !== t7) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            "aria-label": t3,
            className: "flex flex-col gap-3 w-93.75",
            children: [
                t7,
                t13
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/KanbanColumn.tsx",
            lineNumber: 135,
            columnNumber: 11
        }, this);
        $[28] = t13;
        $[29] = t3;
        $[30] = t7;
        $[31] = t14;
    } else {
        t14 = $[31];
    }
    return t14;
}
_s(KanbanColumn, "OMEW8Hck2kMrBB8Yn9LGK1pN6RM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDroppable"]
    ];
});
_c = KanbanColumn;
function _KanbanColumnSafeTasksMap(t) {
    return t.id;
}
var _c;
__turbopack_context__.k.register(_c, "KanbanColumn");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/BaseModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BaseModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js [app-client] (ecmascript) <export default as XMarkIcon>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function BaseModal(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(26);
    if ($[0] !== "aff49536f83a2f9678dc696da740fff19a7778adf2d464681431e0156f689bc6") {
        for(let $i = 0; $i < 26; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "aff49536f83a2f9678dc696da740fff19a7778adf2d464681431e0156f689bc6";
    }
    const { id, title, onClose, children, maxWidth: t1, icon } = t0;
    const maxWidth = t1 === undefined ? "max-w-149.5" : t1;
    let t2;
    let t3;
    if ($[1] !== onClose) {
        t2 = ({
            "BaseModal[useEffect()]": ()=>{
                const handleKeyDown = function handleKeyDown(e) {
                    if (e.key === "Escape") {
                        onClose();
                    }
                };
                document.addEventListener("keydown", handleKeyDown);
                return ()=>document.removeEventListener("keydown", handleKeyDown);
            }
        })["BaseModal[useEffect()]"];
        t3 = [
            onClose
        ];
        $[1] = onClose;
        $[2] = t2;
        $[3] = t3;
    } else {
        t2 = $[2];
        t3 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    const t4 = `bg-bg-content rounded-[8px] shadow-modal w-full ${maxWidth} max-h-[90vh] overflow-y-auto p-6 flex flex-col gap-5`;
    let t5;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
            className: "h-5 w-5"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 58,
            columnNumber: 10
        }, this);
        $[4] = t5;
    } else {
        t5 = $[4];
    }
    let t6;
    if ($[5] !== onClose) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-end",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: onClose,
                className: "text-text-secondary hover:text-text-primary transition",
                "aria-label": "Fermer la modale",
                children: t5
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
                lineNumber: 65,
                columnNumber: 44
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 65,
            columnNumber: 10
        }, this);
        $[5] = onClose;
        $[6] = t6;
    } else {
        t6 = $[6];
    }
    let t7;
    if ($[7] !== icon) {
        t7 = icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-2.5",
            children: icon
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 73,
            columnNumber: 18
        }, this);
        $[7] = icon;
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] !== id || $[10] !== title) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            id: id,
            className: "font-semibold text-text-primary text-2xl mt-2",
            children: title
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[9] = id;
        $[10] = title;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== t7 || $[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center ml-12 gap-2",
            children: [
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[12] = t7;
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== t6 || $[16] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col",
            children: [
                t6,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 99,
            columnNumber: 11
        }, this);
        $[15] = t6;
        $[16] = t9;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] !== children || $[19] !== t10 || $[20] !== t4) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t4,
            onClick: _BaseModalDivOnClick,
            children: [
                t10,
                children
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 108,
            columnNumber: 11
        }, this);
        $[18] = children;
        $[19] = t10;
        $[20] = t4;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    let t12;
    if ($[22] !== id || $[23] !== onClose || $[24] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-50 flex items-center justify-center bg-black/40",
            role: "dialog",
            "aria-modal": "true",
            "aria-labelledby": id,
            onClick: onClose,
            children: t11
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/BaseModal.tsx",
            lineNumber: 118,
            columnNumber: 11
        }, this);
        $[22] = id;
        $[23] = onClose;
        $[24] = t11;
        $[25] = t12;
    } else {
        t12 = $[25];
    }
    return t12;
}
_s(BaseModal, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = BaseModal;
function _BaseModalDivOnClick(e_0) {
    return e_0.stopPropagation();
}
var _c;
__turbopack_context__.k.register(_c, "BaseModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/MemberSearch.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MemberSearch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function MemberSearch(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(43);
    if ($[0] !== "4d45052403fa6202f806317131c96d30881ec7d39c592d98ed1ada1b09ec5c06") {
        for(let $i = 0; $i < 43; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4d45052403fa6202f806317131c96d30881ec7d39c592d98ed1ada1b09ec5c06";
    }
    const { users, selectedUsers, onAdd, onRemove, ownerId, label: t1, buttonLabel: t2 } = t0;
    const label = t1 === undefined ? "Assign\xE9 \xE0" : t1;
    const buttonLabel = t2 === undefined ? "Choisir un ou plusieurs collaborateurs" : t2;
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    if ($[1] !== buttonLabel || $[2] !== isOpen || $[3] !== label || $[4] !== onAdd || $[5] !== onRemove || $[6] !== ownerId || $[7] !== selectedUsers || $[8] !== users) {
        let t9;
        if ($[15] !== selectedUsers) {
            t9 = ({
                "MemberSearch[users.filter()]": (u)=>!selectedUsers.some({
                        "MemberSearch[users.filter() > selectedUsers.some()]": (s)=>s.id === u.id
                    }["MemberSearch[users.filter() > selectedUsers.some()]"])
            })["MemberSearch[users.filter()]"];
            $[15] = selectedUsers;
            $[16] = t9;
        } else {
            t9 = $[16];
        }
        const availableUsers = users.filter(t9);
        let t10;
        if ($[17] !== onAdd) {
            t10 = function handleAdd(user) {
                onAdd(user);
                setIsOpen(false);
            };
            $[17] = onAdd;
            $[18] = t10;
        } else {
            t10 = $[18];
        }
        const handleAdd = t10;
        t6 = "flex flex-col gap-1";
        if ($[19] !== label) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm text-text-primary",
                children: label
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 70,
                columnNumber: 12
            }, this);
            $[19] = label;
            $[20] = t7;
        } else {
            t7 = $[20];
        }
        if ($[21] !== onRemove || $[22] !== ownerId || $[23] !== selectedUsers) {
            t8 = selectedUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-2 mb-1",
                children: selectedUsers.map({
                    "MemberSearch[selectedUsers.map()]": (u_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1.5 bg-bg-grey-light rounded-full px-2 py-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${u_0.id === ownerId ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `text-[9px] ${u_0.id === ownerId ? "text-text-primary" : "text-text-secondary"}`,
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(u_0.name)
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                        lineNumber: 78,
                                        columnNumber: 296
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                    lineNumber: 78,
                                    columnNumber: 151
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs text-text-primary",
                                    children: u_0.name
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                    lineNumber: 78,
                                    columnNumber: 431
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: {
                                        "MemberSearch[selectedUsers.map() > <button>.onClick]": ()=>onRemove(u_0.id)
                                    }["MemberSearch[selectedUsers.map() > <button>.onClick]"],
                                    className: "text-text-secondary hover:text-system-error text-xs ml-0.5",
                                    "aria-label": `Retirer ${u_0.name}`,
                                    children: "×"
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                    lineNumber: 78,
                                    columnNumber: 492
                                }, this)
                            ]
                        }, u_0.id, true, {
                            fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                            lineNumber: 78,
                            columnNumber: 55
                        }, this)
                }["MemberSearch[selectedUsers.map()]"])
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 77,
                columnNumber: 40
            }, this);
            $[21] = onRemove;
            $[22] = ownerId;
            $[23] = selectedUsers;
            $[24] = t8;
        } else {
            t8 = $[24];
        }
        t3 = "relative";
        let t11;
        if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
            t11 = ({
                "MemberSearch[<button>.onClick]": ()=>setIsOpen(_MemberSearchButtonOnClickSetIsOpen)
            })["MemberSearch[<button>.onClick]"];
            $[25] = t11;
        } else {
            t11 = $[25];
        }
        let t12;
        if ($[26] !== buttonLabel) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-text-secondary",
                children: buttonLabel
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 101,
                columnNumber: 13
            }, this);
            $[26] = buttonLabel;
            $[27] = t12;
        } else {
            t12 = $[27];
        }
        const t13 = `h-6 w-6 text-btn-black transition-transform ${isOpen ? "rotate-180" : ""}`;
        let t14;
        if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
            t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M5 8l5 5 5-5"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 110,
                columnNumber: 13
            }, this);
            $[28] = t14;
        } else {
            t14 = $[28];
        }
        let t15;
        if ($[29] !== t13) {
            t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: t13,
                viewBox: "0 0 20 20",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: 1.5,
                children: t14
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 117,
                columnNumber: 13
            }, this);
            $[29] = t13;
            $[30] = t15;
        } else {
            t15 = $[30];
        }
        if ($[31] !== t12 || $[32] !== t15) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: t11,
                className: "w-full h-13.25 flex items-center justify-between border border-system-neutral rounded-[8px] px-4 py-3 text-sm bg-bg-content transition",
                children: [
                    t12,
                    t15
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                lineNumber: 124,
                columnNumber: 12
            }, this);
            $[31] = t12;
            $[32] = t15;
            $[33] = t4;
        } else {
            t4 = $[33];
        }
        t5 = isOpen && availableUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-full left-0 right-0 z-20 bg-bg-content border border-system-neutral rounded-[8px] shadow-modal mt-1 overflow-hidden max-h-48 overflow-y-auto",
            children: availableUsers.map({
                "MemberSearch[availableUsers.map()]": (u_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: {
                            "MemberSearch[availableUsers.map() > <button>.onClick]": ()=>handleAdd(u_1)
                        }["MemberSearch[availableUsers.map() > <button>.onClick]"],
                        className: "w-full flex items-center gap-2 px-4 py-2 text-sm text-text-secondary hover:bg-bg-grey-light transition",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${u_1.id === ownerId ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `text-[9px] font-semibold ${u_1.id === ownerId ? "text-text-primary" : "text-text-secondary"}`,
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(u_1.name)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                    lineNumber: 134,
                                    columnNumber: 329
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                lineNumber: 134,
                                columnNumber: 184
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `px-2 py-0.5 rounded-full text-sm ${u_1.id === ownerId ? "bg-brand-light text-text-primary" : "bg-bg-grey-border text-text-secondary"}`,
                                children: u_1.name
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                                lineNumber: 134,
                                columnNumber: 478
                            }, this)
                        ]
                    }, u_1.id, true, {
                        fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
                        lineNumber: 132,
                        columnNumber: 54
                    }, this)
            }["MemberSearch[availableUsers.map()]"])
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
            lineNumber: 131,
            columnNumber: 49
        }, this);
        $[1] = buttonLabel;
        $[2] = isOpen;
        $[3] = label;
        $[4] = onAdd;
        $[5] = onRemove;
        $[6] = ownerId;
        $[7] = selectedUsers;
        $[8] = users;
        $[9] = t3;
        $[10] = t4;
        $[11] = t5;
        $[12] = t6;
        $[13] = t7;
        $[14] = t8;
    } else {
        t3 = $[9];
        t4 = $[10];
        t5 = $[11];
        t6 = $[12];
        t7 = $[13];
        t8 = $[14];
    }
    let t9;
    if ($[34] !== t3 || $[35] !== t4 || $[36] !== t5) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t3,
            children: [
                t4,
                t5
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
            lineNumber: 160,
            columnNumber: 10
        }, this);
        $[34] = t3;
        $[35] = t4;
        $[36] = t5;
        $[37] = t9;
    } else {
        t9 = $[37];
    }
    let t10;
    if ($[38] !== t6 || $[39] !== t7 || $[40] !== t8 || $[41] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t6,
            children: [
                t7,
                t8,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/MemberSearch.tsx",
            lineNumber: 170,
            columnNumber: 11
        }, this);
        $[38] = t6;
        $[39] = t7;
        $[40] = t8;
        $[41] = t9;
        $[42] = t10;
    } else {
        t10 = $[42];
    }
    return t10;
}
_s(MemberSearch, "+sus0Lb0ewKHdwiUhiTAJFoFyQ0=");
_c = MemberSearch;
function _MemberSearchButtonOnClickSetIsOpen(v) {
    return !v;
}
var _c;
__turbopack_context__.k.register(_c, "MemberSearch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/forms/TaskForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TaskForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$MemberSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/MemberSearch.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/task.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const statusOptions = Object.entries(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusLabel"]).filter(([value])=>value !== "CANCELLED");
function TaskForm(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(65);
    if ($[0] !== "8dd8dc45518a97980f9a35f173cf9d8c4dd6c129208b5da6dc648fcf13ebf169") {
        for(let $i = 0; $i < 65; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8dd8dc45518a97980f9a35f173cf9d8c4dd6c129208b5da6dc648fcf13ebf169";
    }
    const { initialTask, members, ownerId, submitLabel, loading, error, onSubmit } = t0;
    const [title, setTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialTask?.title ?? "");
    const [description, setDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialTask?.description ?? "");
    let t1;
    if ($[1] !== initialTask) {
        t1 = initialTask?.dueDate ? initialTask.dueDate.split("T")[0] : "";
        $[1] = initialTask;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [dueDate, setDueDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialTask?.status ?? "TODO");
    const [priority, setPriority] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialTask?.priority ?? "MEDIUM");
    let t2;
    if ($[3] !== initialTask?.assignees) {
        t2 = initialTask?.assignees?.map(_TaskFormAnonymous) ?? [];
        $[3] = initialTask?.assignees;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const [selectedAssignees, setSelectedAssignees] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    if ($[5] !== description || $[6] !== dueDate || $[7] !== onSubmit || $[8] !== priority || $[9] !== selectedAssignees || $[10] !== status || $[11] !== title) {
        t3 = async function handleSubmit(e) {
            e.preventDefault();
            await onSubmit(title, description, dueDate, selectedAssignees.map(_TaskFormHandleSubmitSelectedAssigneesMap), status, priority);
        };
        $[5] = description;
        $[6] = dueDate;
        $[7] = onSubmit;
        $[8] = priority;
        $[9] = selectedAssignees;
        $[10] = status;
        $[11] = title;
        $[12] = t3;
    } else {
        t3 = $[12];
    }
    const handleSubmit = t3;
    let t4;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "text-sm text-text-primary",
            children: "Titre *"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 77,
            columnNumber: 10
        }, this);
        $[13] = t4;
    } else {
        t4 = $[13];
    }
    let t5;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "TaskForm[<input>.onChange]": (e_0)=>setTitle(e_0.target.value)
        })["TaskForm[<input>.onChange]"];
        $[14] = t5;
    } else {
        t5 = $[14];
    }
    let t6;
    if ($[15] !== title) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t4,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    "aria-label": "Titre de la t\xE2che",
                    type: "text",
                    value: title,
                    onChange: t5,
                    className: "h-13.25 border border-system-neutral rounded-sm px-4 py-3",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 93,
                    columnNumber: 51
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 93,
            columnNumber: 10
        }, this);
        $[15] = title;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    let t7;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "text-sm text-text-primary",
            children: "Description *"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 101,
            columnNumber: 10
        }, this);
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    let t8;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = ({
            "TaskForm[<textarea>.onChange]": (e_1)=>setDescription(e_1.target.value)
        })["TaskForm[<textarea>.onChange]"];
        $[18] = t8;
    } else {
        t8 = $[18];
    }
    let t9;
    if ($[19] !== description) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t7,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                    "aria-label": "Description de la t\xE2che",
                    value: description,
                    onChange: t8,
                    className: "h-13.25 border border-system-neutral rounded-sm px-4 py-3 resize-none",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 117,
                    columnNumber: 51
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 117,
            columnNumber: 10
        }, this);
        $[19] = description;
        $[20] = t9;
    } else {
        t9 = $[20];
    }
    let t10;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "text-sm text-text-primary",
            children: "Échéance *"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 125,
            columnNumber: 11
        }, this);
        $[21] = t10;
    } else {
        t10 = $[21];
    }
    let t11;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = ({
            "TaskForm[<input>.onChange]": (e_2)=>setDueDate(e_2.target.value)
        })["TaskForm[<input>.onChange]"];
        $[22] = t11;
    } else {
        t11 = $[22];
    }
    let t12;
    if ($[23] !== dueDate) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t10,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    "aria-label": "Date d'\xE9ch\xE9ance",
                    type: "date",
                    value: dueDate,
                    onChange: t11,
                    className: "h-13.25 border border-system-neutral rounded-sm px-4 py-3",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 141,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 141,
            columnNumber: 11
        }, this);
        $[23] = dueDate;
        $[24] = t12;
    } else {
        t12 = $[24];
    }
    let t13;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-sm text-text-primary",
            children: "Assigné à"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 149,
            columnNumber: 11
        }, this);
        $[25] = t13;
    } else {
        t13 = $[25];
    }
    let t14;
    if ($[26] !== members) {
        t14 = members.map(_TaskFormMembersMap);
        $[26] = members;
        $[27] = t14;
    } else {
        t14 = $[27];
    }
    let t15;
    let t16;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = ({
            "TaskForm[<MemberSearch>.onAdd]": (u_0)=>setSelectedAssignees({
                    "TaskForm[<MemberSearch>.onAdd > setSelectedAssignees()]": (prev)=>[
                            ...prev,
                            u_0
                        ]
                }["TaskForm[<MemberSearch>.onAdd > setSelectedAssignees()]"])
        })["TaskForm[<MemberSearch>.onAdd]"];
        t16 = ({
            "TaskForm[<MemberSearch>.onRemove]": (id)=>setSelectedAssignees({
                    "TaskForm[<MemberSearch>.onRemove > setSelectedAssignees()]": (prev_0)=>prev_0.filter({
                            "TaskForm[<MemberSearch>.onRemove > setSelectedAssignees() > prev_0.filter()]": (u_1)=>u_1.id !== id
                        }["TaskForm[<MemberSearch>.onRemove > setSelectedAssignees() > prev_0.filter()]"])
                }["TaskForm[<MemberSearch>.onRemove > setSelectedAssignees()]"])
        })["TaskForm[<MemberSearch>.onRemove]"];
        $[28] = t15;
        $[29] = t16;
    } else {
        t15 = $[28];
        t16 = $[29];
    }
    const t17 = selectedAssignees.length > 0 ? `${selectedAssignees.length} assigné(s)` : "Choisir des assign\xE9s";
    let t18;
    if ($[30] !== ownerId || $[31] !== selectedAssignees || $[32] !== t14 || $[33] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t13,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$MemberSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    users: t14,
                    selectedUsers: selectedAssignees,
                    onAdd: t15,
                    onRemove: t16,
                    ownerId: ownerId,
                    buttonLabel: t17
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 186,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        $[30] = ownerId;
        $[31] = selectedAssignees;
        $[32] = t14;
        $[33] = t17;
        $[34] = t18;
    } else {
        t18 = $[34];
    }
    let t19;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-sm text-text-primary",
            children: "Statut"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 197,
            columnNumber: 11
        }, this);
        $[35] = t19;
    } else {
        t19 = $[35];
    }
    let t20;
    if ($[36] !== status) {
        t20 = statusOptions.map({
            "TaskForm[statusOptions.map()]": (t21)=>{
                const [value, label] = t21;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    onClick: {
                        "TaskForm[statusOptions.map() > <button>.onClick]": ()=>setStatus(value)
                    }["TaskForm[statusOptions.map() > <button>.onClick]"],
                    className: `px-3 py-1.5 rounded-full text-xs ${status === value ? "bg-system-info text-text-info" : __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusColor"][value]}`,
                    children: label
                }, value, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 207,
                    columnNumber: 16
                }, this);
            }
        }["TaskForm[statusOptions.map()]"]);
        $[36] = status;
        $[37] = t20;
    } else {
        t20 = $[37];
    }
    let t21;
    if ($[38] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t19,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2 flex-wrap",
                    children: t20
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 219,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 219,
            columnNumber: 11
        }, this);
        $[38] = t20;
        $[39] = t21;
    } else {
        t21 = $[39];
    }
    let t22;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-sm text-text-primary",
            children: "Priorité"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 227,
            columnNumber: 11
        }, this);
        $[40] = t22;
    } else {
        t22 = $[40];
    }
    let t23;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = ({
            "TaskForm[<select>.onChange]": (e_3)=>setPriority(e_3.target.value)
        })["TaskForm[<select>.onChange]"];
        $[41] = t23;
    } else {
        t23 = $[41];
    }
    let t24;
    let t25;
    let t26;
    let t27;
    if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "URGENT",
            children: "Urgente"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 246,
            columnNumber: 11
        }, this);
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "HIGH",
            children: "Haute"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 247,
            columnNumber: 11
        }, this);
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "MEDIUM",
            children: "Moyenne"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 248,
            columnNumber: 11
        }, this);
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "LOW",
            children: "Basse"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 249,
            columnNumber: 11
        }, this);
        $[42] = t24;
        $[43] = t25;
        $[44] = t26;
        $[45] = t27;
    } else {
        t24 = $[42];
        t25 = $[43];
        t26 = $[44];
        t27 = $[45];
    }
    let t28;
    if ($[46] !== priority) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t22,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                    id: "task-priority",
                    "aria-label": "S\xE9lectionner la priorit\xE9",
                    value: priority,
                    onChange: t23,
                    className: "h-13.25 border border-system-neutral rounded-sm px-4 py-3",
                    children: [
                        t24,
                        t25,
                        t26,
                        t27
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
                    lineNumber: 262,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 262,
            columnNumber: 11
        }, this);
        $[46] = priority;
        $[47] = t28;
    } else {
        t28 = $[47];
    }
    let t29;
    if ($[48] !== error) {
        t29 = error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm text-text-error",
            children: error
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 270,
            columnNumber: 20
        }, this);
        $[48] = error;
        $[49] = t29;
    } else {
        t29 = $[49];
    }
    const t30 = loading || !title || !description || !dueDate;
    const t31 = loading ? "En cours..." : submitLabel;
    let t32;
    if ($[50] !== t30 || $[51] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            disabled: t30,
            className: "w-45.25 h-12.5 bg-system-neutral rounded-[8px]",
            children: t31
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 280,
            columnNumber: 11
        }, this);
        $[50] = t30;
        $[51] = t31;
        $[52] = t32;
    } else {
        t32 = $[52];
    }
    let t33;
    if ($[53] !== t12 || $[54] !== t18 || $[55] !== t21 || $[56] !== t28 || $[57] !== t29 || $[58] !== t32 || $[59] !== t6 || $[60] !== t9) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-113 h-133.75 mx-auto overflow-y-auto flex flex-col gap-4 pr-1",
            children: [
                t6,
                t9,
                t12,
                t18,
                t21,
                t28,
                t29,
                t32
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 289,
            columnNumber: 11
        }, this);
        $[53] = t12;
        $[54] = t18;
        $[55] = t21;
        $[56] = t28;
        $[57] = t29;
        $[58] = t32;
        $[59] = t6;
        $[60] = t9;
        $[61] = t33;
    } else {
        t33 = $[61];
    }
    let t34;
    if ($[62] !== handleSubmit || $[63] !== t33) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: handleSubmit,
            className: "flex flex-col gap-4",
            noValidate: true,
            children: t33
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/TaskForm.tsx",
            lineNumber: 304,
            columnNumber: 11
        }, this);
        $[62] = handleSubmit;
        $[63] = t33;
        $[64] = t34;
    } else {
        t34 = $[64];
    }
    return t34;
}
_s(TaskForm, "3ISWg/sS3/yAfBb7nnSeLMOyYCE=");
_c = TaskForm;
function _TaskFormMembersMap(m) {
    return m.user;
}
function _TaskFormHandleSubmitSelectedAssigneesMap(u) {
    return u.id;
}
function _TaskFormAnonymous(a) {
    return a.user;
}
var _c;
__turbopack_context__.k.register(_c, "TaskForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/CreateTaskModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CreateTaskModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/BaseModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$TaskForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/forms/TaskForm.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function CreateTaskModal({ members, initialTask, ownerId, onClose, onSubmit }) {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    async function handleSubmit(title, description, dueDate, assigneeIds, status, priority) {
        setError(null);
        setLoading(true);
        try {
            const isoDate = dueDate && dueDate.trim() !== "" ? new Date(dueDate).toISOString() : null;
            await onSubmit(title, description, isoDate, assigneeIds, status, priority);
            onClose();
        } catch (err) {
            setError(err instanceof Error ? err.message : "Une erreur est survenue");
        } finally{
            setLoading(false);
        }
    }
    const isEdit = !!initialTask;
    console.log("🟢 MODALE CRÉATION OUVERTE — Données :", {
        mode: "create",
        initialTask: null
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        id: "task-modal-title",
        title: isEdit ? "Modifier" : "Créer une tâche",
        onClose: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$TaskForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            members: members,
            initialTask: initialTask,
            ownerId: ownerId,
            submitLabel: isEdit ? "Enregistrer" : "+ Ajouter une tâche",
            loading: loading,
            error: error,
            onSubmit: handleSubmit
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/CreateTaskModal.tsx",
            lineNumber: 42,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/frontend/src/components/modals/CreateTaskModal.tsx",
        lineNumber: 41,
        columnNumber: 10
    }, this);
}
_s(CreateTaskModal, "Iz3ozxQ+abMaAIcGIvU8cKUcBeo=");
_c = CreateTaskModal;
var _c;
__turbopack_context__.k.register(_c, "CreateTaskModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/hooks/useTaskFilters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTaskFilters",
    ()=>useTaskFilters
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/task.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function useTaskFilters(tasks) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    if ($[0] !== "cc4c4d23220ff8ba33082e137c5f03e9fed60204e0bff750646643f0a1c07c0f") {
        for(let $i = 0; $i < 15; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cc4c4d23220ff8ba33082e137c5f03e9fed60204e0bff750646643f0a1c07c0f";
    }
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [filterStatus, setFilterStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("ALL");
    const [filterPriority, setFilterPriority] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("ALL");
    let t0;
    if ($[1] !== filterPriority || $[2] !== filterStatus || $[3] !== search || $[4] !== tasks) {
        const safeTasks = tasks ?? [];
        let t1;
        if ($[6] !== filterPriority || $[7] !== filterStatus || $[8] !== search) {
            t1 = ({
                "useTaskFilters[safeTasks.filter()]": (task)=>{
                    const s = search.toLowerCase();
                    const matchSearch = task.title.toLowerCase().includes(s) || task.description?.toLowerCase().includes(s) || task.projectName.toLowerCase().includes(s);
                    const matchStatus = filterStatus === "ALL" || task.status === filterStatus;
                    const matchPriority = filterPriority === "ALL" || task.priority === filterPriority;
                    return matchSearch && matchStatus && matchPriority;
                }
            })["useTaskFilters[safeTasks.filter()]"];
            $[6] = filterPriority;
            $[7] = filterStatus;
            $[8] = search;
            $[9] = t1;
        } else {
            t1 = $[9];
        }
        t0 = safeTasks.filter(t1).sort(_useTaskFiltersAnonymous);
        $[1] = filterPriority;
        $[2] = filterStatus;
        $[3] = search;
        $[4] = tasks;
        $[5] = t0;
    } else {
        t0 = $[5];
    }
    const filteredTasks = t0;
    let t1;
    if ($[10] !== filterPriority || $[11] !== filterStatus || $[12] !== filteredTasks || $[13] !== search) {
        t1 = {
            search,
            setSearch,
            filterStatus,
            setFilterStatus,
            filterPriority,
            setFilterPriority,
            filteredTasks
        };
        $[10] = filterPriority;
        $[11] = filterStatus;
        $[12] = filteredTasks;
        $[13] = search;
        $[14] = t1;
    } else {
        t1 = $[14];
    }
    return t1;
}
_s(useTaskFilters, "muIUgeQS0PGLMesnWgN4nhmkWDc=");
function _useTaskFiltersAnonymous(a, b) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["priorityOrder"][a.priority] - __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$task$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["priorityOrder"][b.priority];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/dashboard/TasksSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TasksSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/@dnd-kit/core/dist/core.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/@dnd-kit/sortable/dist/sortable.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useModal.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$dashboard$2f$TaskCardList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/dashboard/TaskCardList.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$dashboard$2f$KanbanColumn$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/dashboard/KanbanColumn.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$CreateTaskModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/CreateTaskModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useTaskFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useTaskFilters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/@heroicons/react/24/outline/esm/MagnifyingGlassIcon.js [app-client] (ecmascript) <export default as MagnifyingGlassIcon>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
const COLUMNS = [
    {
        id: "TODO",
        label: "À faire"
    },
    {
        id: "IN_PROGRESS",
        label: "En cours"
    },
    {
        id: "DONE",
        label: "Terminées"
    }
];
function TasksSection(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(77);
    if ($[0] !== "1a02a2ed3b75a3a24ec0c15ebd76aaf08b08243d29886400e072cbe277716b2d") {
        for(let $i = 0; $i < 77; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "1a02a2ed3b75a3a24ec0c15ebd76aaf08b08243d29886400e072cbe277716b2d";
    }
    const { tasks, projects, loading, error, view, onUpdateTaskStatus, updateTask } = t0;
    const [editingTask, setEditingTask] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { isOpen, openModal, closeModal } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModal"])();
    const { search, setSearch, filterStatus, setFilterStatus, filterPriority, setFilterPriority, filteredTasks } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useTaskFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTaskFilters"])(tasks);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            coordinateGetter: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortableKeyboardCoordinates"]
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const sensors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensors"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensor"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointerSensor"]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensor"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KeyboardSensor"], t1));
    let t2;
    if ($[2] !== openModal) {
        t2 = function handleEdit(task) {
            setEditingTask(task);
            openModal("editTask");
        };
        $[2] = openModal;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const handleEdit = t2;
    let t3;
    if ($[4] !== onUpdateTaskStatus || $[5] !== tasks) {
        t3 = function handleDragEnd(event) {
            const { active, over } = event;
            if (!over) {
                return;
            }
            const task_0 = tasks.find({
                "TasksSection[handleDragEnd > tasks.find()]": (t)=>t.id === active.id
            }["TasksSection[handleDragEnd > tasks.find()]"]);
            if (!task_0) {
                return;
            }
            const overTask = tasks.find({
                "TasksSection[handleDragEnd > tasks.find()]": (t_0)=>t_0.id === over.id
            }["TasksSection[handleDragEnd > tasks.find()]"]);
            const newStatus = overTask ? overTask.status : over.id;
            if (task_0.status !== newStatus) {
                onUpdateTaskStatus(task_0.id, task_0.projectId, newStatus);
            }
        };
        $[4] = onUpdateTaskStatus;
        $[5] = tasks;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const handleDragEnd = t3;
    let t4;
    if ($[7] !== editingTask?.projectId || $[8] !== projects) {
        let t5;
        if ($[10] !== editingTask?.projectId) {
            t5 = ({
                "TasksSection[projects.find()]": (p)=>p.id === editingTask?.projectId
            })["TasksSection[projects.find()]"];
            $[10] = editingTask?.projectId;
            $[11] = t5;
        } else {
            t5 = $[11];
        }
        t4 = projects.find(t5);
        $[7] = editingTask?.projectId;
        $[8] = projects;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    const editingTaskProject = t4;
    let t5;
    if ($[12] !== editingTaskProject?.members) {
        t5 = editingTaskProject?.members ?? [];
        $[12] = editingTaskProject?.members;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    const editingTaskMembers = t5;
    const editingTaskOwnerId = editingTaskProject?.owner?.id;
    let t6;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-0.5",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    id: "tasks-title",
                    className: "text-[18px] font-semibold text-text-primary",
                    children: "Mes tâches assignées"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
                    lineNumber: 160,
                    columnNumber: 49
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-[16px] text-text-secondary",
                    children: "Par ordre de priorité"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
                    lineNumber: 160,
                    columnNumber: 151
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 160,
            columnNumber: 10
        }, this);
        $[14] = t6;
    } else {
        t6 = $[14];
    }
    let t7;
    if ($[15] !== setFilterStatus) {
        t7 = ({
            "TasksSection[<select>.onChange]": (e)=>setFilterStatus(e.target.value)
        })["TasksSection[<select>.onChange]"];
        $[15] = setFilterStatus;
        $[16] = t7;
    } else {
        t7 = $[16];
    }
    let t10;
    let t11;
    let t12;
    let t8;
    let t9;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "ALL",
            children: "Tous les statuts"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 181,
            columnNumber: 10
        }, this);
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "TODO",
            children: "À faire"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 182,
            columnNumber: 10
        }, this);
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "IN_PROGRESS",
            children: "En cours"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 183,
            columnNumber: 11
        }, this);
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "DONE",
            children: "Terminées"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 184,
            columnNumber: 11
        }, this);
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "CANCELLED",
            children: "Annulées"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 185,
            columnNumber: 11
        }, this);
        $[17] = t10;
        $[18] = t11;
        $[19] = t12;
        $[20] = t8;
        $[21] = t9;
    } else {
        t10 = $[17];
        t11 = $[18];
        t12 = $[19];
        t8 = $[20];
        t9 = $[21];
    }
    let t13;
    if ($[22] !== filterStatus || $[23] !== t7) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
            title: "Filtrer par statut",
            "aria-label": "Filtrer par statut",
            value: filterStatus,
            onChange: t7,
            className: "text-sm border border-system-neutral rounded-[8px] px-3 py-2 bg-bg-content text-text-primary transition",
            children: [
                t8,
                t9,
                t10,
                t11,
                t12
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 200,
            columnNumber: 11
        }, this);
        $[22] = filterStatus;
        $[23] = t7;
        $[24] = t13;
    } else {
        t13 = $[24];
    }
    let t14;
    if ($[25] !== setFilterPriority) {
        t14 = ({
            "TasksSection[<select>.onChange]": (e_0)=>setFilterPriority(e_0.target.value)
        })["TasksSection[<select>.onChange]"];
        $[25] = setFilterPriority;
        $[26] = t14;
    } else {
        t14 = $[26];
    }
    let t15;
    let t16;
    let t17;
    let t18;
    let t19;
    if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "ALL",
            children: "Toutes les priorités"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 223,
            columnNumber: 11
        }, this);
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "URGENT",
            children: "Urgente"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 224,
            columnNumber: 11
        }, this);
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "HIGH",
            children: "Haute"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 225,
            columnNumber: 11
        }, this);
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "MEDIUM",
            children: "Moyenne"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 226,
            columnNumber: 11
        }, this);
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "LOW",
            children: "Basse"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 227,
            columnNumber: 11
        }, this);
        $[27] = t15;
        $[28] = t16;
        $[29] = t17;
        $[30] = t18;
        $[31] = t19;
    } else {
        t15 = $[27];
        t16 = $[28];
        t17 = $[29];
        t18 = $[30];
        t19 = $[31];
    }
    let t20;
    if ($[32] !== filterPriority || $[33] !== t14) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
            title: "Filtrer par priorit\xE9",
            "aria-label": "Filtrer par priorit\xE9",
            value: filterPriority,
            onChange: t14,
            className: "text-sm border border-system-neutral rounded-[8px] px-3 py-2 bg-bg-content text-text-primary transition",
            children: [
                t15,
                t16,
                t17,
                t18,
                t19
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 242,
            columnNumber: 11
        }, this);
        $[32] = filterPriority;
        $[33] = t14;
        $[34] = t20;
    } else {
        t20 = $[34];
    }
    let t21;
    if ($[35] !== setSearch) {
        t21 = ({
            "TasksSection[<input>.onChange]": (e_1)=>setSearch(e_1.target.value)
        })["TasksSection[<input>.onChange]"];
        $[35] = setSearch;
        $[36] = t21;
    } else {
        t21 = $[36];
    }
    let t22;
    if ($[37] !== search || $[38] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "search",
            value: search,
            onChange: t21,
            placeholder: "Rechercher une t\xE2che",
            className: "pl-4 pr-4 py-2 text-sm border border-system-neutral rounded-[8px] bg-bg-content text-text-primary w-56 transition"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 261,
            columnNumber: 11
        }, this);
        $[37] = search;
        $[38] = t21;
        $[39] = t22;
    } else {
        t22 = $[39];
    }
    let t23;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__["MagnifyingGlassIcon"], {
            className: "absolute right-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-text-secondary pointer-events-none"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 270,
            columnNumber: 11
        }, this);
        $[40] = t23;
    } else {
        t23 = $[40];
    }
    let t24;
    if ($[41] !== t22) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative",
            children: [
                t22,
                t23
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 277,
            columnNumber: 11
        }, this);
        $[41] = t22;
        $[42] = t24;
    } else {
        t24 = $[42];
    }
    let t25;
    if ($[43] !== t13 || $[44] !== t20 || $[45] !== t24) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-between flex-wrap gap-3 my-3",
            children: [
                t6,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3 flex-wrap",
                    children: [
                        t13,
                        t20,
                        t24
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
                    lineNumber: 285,
                    columnNumber: 87
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 285,
            columnNumber: 11
        }, this);
        $[43] = t13;
        $[44] = t20;
        $[45] = t24;
        $[46] = t25;
    } else {
        t25 = $[46];
    }
    let t26;
    if ($[47] !== error || $[48] !== filteredTasks || $[49] !== handleEdit || $[50] !== loading || $[51] !== projects || $[52] !== view) {
        t26 = !loading && !error && view === "list" && filteredTasks.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-3",
            children: filteredTasks.map({
                "TasksSection[filteredTasks.map()]": (task_1)=>{
                    const taskProject = projects.find({
                        "TasksSection[filteredTasks.map() > projects.find()]": (p_0)=>p_0.id === task_1.projectId
                    }["TasksSection[filteredTasks.map() > projects.find()]"]);
                    const taskOwnerId = taskProject?.owner?.id;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$dashboard$2f$TaskCardList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        task: task_1,
                        ownerId: taskOwnerId,
                        onEdit: handleEdit
                    }, task_1.id, false, {
                        fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
                        lineNumber: 301,
                        columnNumber: 18
                    }, this);
                }
            }["TasksSection[filteredTasks.map()]"])
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 295,
            columnNumber: 80
        }, this);
        $[47] = error;
        $[48] = filteredTasks;
        $[49] = handleEdit;
        $[50] = loading;
        $[51] = projects;
        $[52] = view;
        $[53] = t26;
    } else {
        t26 = $[53];
    }
    let t27;
    if ($[54] !== error || $[55] !== filteredTasks || $[56] !== handleDragEnd || $[57] !== handleEdit || $[58] !== loading || $[59] !== projects || $[60] !== sensors || $[61] !== view) {
        t27 = !loading && !error && view === "kanban" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndContext"], {
            sensors: sensors,
            collisionDetection: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["closestCenter"],
            onDragEnd: handleDragEnd,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-4 items-start mt-4 pb-4",
                children: COLUMNS.map({
                    "TasksSection[COLUMNS.map()]": (col)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$dashboard$2f$KanbanColumn$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            id: col.id,
                            title: col.label,
                            tasks: filteredTasks?.filter({
                                "TasksSection[COLUMNS.map() > (anonymous)()]": (t_1)=>t_1.status === col.id
                            }["TasksSection[COLUMNS.map() > (anonymous)()]"]) ?? [],
                            projects: projects,
                            onEdit: handleEdit
                        }, col.id, false, {
                            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
                            lineNumber: 317,
                            columnNumber: 49
                        }, this)
                }["TasksSection[COLUMNS.map()]"])
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
                lineNumber: 316,
                columnNumber: 145
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 316,
            columnNumber: 54
        }, this);
        $[54] = error;
        $[55] = filteredTasks;
        $[56] = handleDragEnd;
        $[57] = handleEdit;
        $[58] = loading;
        $[59] = projects;
        $[60] = sensors;
        $[61] = view;
        $[62] = t27;
    } else {
        t27 = $[62];
    }
    let t28;
    if ($[63] !== t25 || $[64] !== t26 || $[65] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-bg-content rounded-[8px] shadow-card px-6 py-5 flex flex-col gap-6",
            children: [
                t25,
                t26,
                t27
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 335,
            columnNumber: 11
        }, this);
        $[63] = t25;
        $[64] = t26;
        $[65] = t27;
        $[66] = t28;
    } else {
        t28 = $[66];
    }
    let t29;
    if ($[67] !== closeModal || $[68] !== editingTask || $[69] !== editingTaskMembers || $[70] !== editingTaskOwnerId || $[71] !== isOpen || $[72] !== updateTask) {
        t29 = isOpen("editTask") && editingTask && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$CreateTaskModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            members: editingTaskMembers,
            initialTask: editingTask,
            ownerId: editingTaskOwnerId,
            onClose: {
                "TasksSection[<CreateTaskModal>.onClose]": ()=>{
                    closeModal();
                    setEditingTask(null);
                }
            }["TasksSection[<CreateTaskModal>.onClose]"],
            onSubmit: {
                "TasksSection[<CreateTaskModal>.onSubmit]": async (title, description, dueDate, assigneeIds, status, priority)=>{
                    await updateTask(editingTask.id, {
                        title,
                        description,
                        dueDate: dueDate ?? undefined,
                        assigneeIds,
                        status,
                        priority
                    });
                    closeModal();
                    setEditingTask(null);
                }
            }["TasksSection[<CreateTaskModal>.onSubmit]"]
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 345,
            columnNumber: 48
        }, this);
        $[67] = closeModal;
        $[68] = editingTask;
        $[69] = editingTaskMembers;
        $[70] = editingTaskOwnerId;
        $[71] = isOpen;
        $[72] = updateTask;
        $[73] = t29;
    } else {
        t29 = $[73];
    }
    let t30;
    if ($[74] !== t28 || $[75] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            "aria-labelledby": "tasks-title",
            children: [
                t28,
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/dashboard/TasksSection.tsx",
            lineNumber: 376,
            columnNumber: 11
        }, this);
        $[74] = t28;
        $[75] = t29;
        $[76] = t30;
    } else {
        t30 = $[76];
    }
    return t30;
}
_s(TasksSection, "COVF9Mpef3iYwLYLQ79yUNDY68A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModal"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useTaskFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTaskFilters"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensors"]
    ];
});
_c = TasksSection;
var _c;
__turbopack_context__.k.register(_c, "TasksSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/api/users.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getUsers",
    ()=>getUsers,
    "searchUsers",
    ()=>searchUsers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
;
async function searchUsers(query) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/users/search?query=${encodeURIComponent(query)}`);
}
async function getUsers() {
    const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])("/users");
    return res.data?.users ?? [];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/ui/ContributorSearch.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContributorSearch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$users$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/users.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ContributorSearch(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(50);
    if ($[0] !== "07ecb7b3715facea8e6f57e6f46f639dd21737f69da0bbeae2e1c6ad953e147c") {
        for(let $i = 0; $i < 50; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "07ecb7b3715facea8e6f57e6f46f639dd21737f69da0bbeae2e1c6ad953e147c";
    }
    const { selectedUsers, excludeUserIds: t1, onAdd, onRemove, label: t2, ownerId, buttonLabel: t3 } = t0;
    let t4;
    if ($[1] !== t1) {
        t4 = t1 === undefined ? [] : t1;
        $[1] = t1;
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    const excludeUserIds = t4;
    const label = t2 === undefined ? "Contributeurs" : t2;
    const buttonLabel = t3 === undefined ? "Choisir un ou plusieurs collaborateurs" : t3;
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t5;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = [];
        $[3] = t5;
    } else {
        t5 = $[3];
    }
    const [allUsers, setAllUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t5);
    let t6;
    let t7;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "ContributorSearch[useEffect()]": ()=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$users$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUsers"])().then({
                    "ContributorSearch[useEffect() > (anonymous)()]": (users)=>setAllUsers(users)
                }["ContributorSearch[useEffect() > (anonymous)()]"]);
            }
        })["ContributorSearch[useEffect()]"];
        t7 = [];
        $[4] = t6;
        $[5] = t7;
    } else {
        t6 = $[4];
        t7 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t6, t7);
    let t10;
    let t11;
    let t12;
    let t13;
    let t8;
    let t9;
    if ($[6] !== allUsers || $[7] !== buttonLabel || $[8] !== excludeUserIds || $[9] !== isOpen || $[10] !== label || $[11] !== onAdd || $[12] !== onRemove || $[13] !== ownerId || $[14] !== selectedUsers) {
        let t14;
        if ($[21] !== excludeUserIds || $[22] !== selectedUsers) {
            t14 = ({
                "ContributorSearch[allUsers.filter()]": (u)=>!selectedUsers.find({
                        "ContributorSearch[allUsers.filter() > selectedUsers.find()]": (s)=>s.id === u.id
                    }["ContributorSearch[allUsers.filter() > selectedUsers.find()]"]) && !excludeUserIds.includes(u.id)
            })["ContributorSearch[allUsers.filter()]"];
            $[21] = excludeUserIds;
            $[22] = selectedUsers;
            $[23] = t14;
        } else {
            t14 = $[23];
        }
        const availableUsers = allUsers.filter(t14);
        let t15;
        if ($[24] !== onAdd) {
            t15 = function handleAdd(user) {
                onAdd(user);
                setIsOpen(false);
            };
            $[24] = onAdd;
            $[25] = t15;
        } else {
            t15 = $[25];
        }
        const handleAdd = t15;
        t11 = "flex flex-col gap-1";
        if ($[26] !== label) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm text-text-primary",
                children: label
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 107,
                columnNumber: 13
            }, this);
            $[26] = label;
            $[27] = t12;
        } else {
            t12 = $[27];
        }
        if ($[28] !== onRemove || $[29] !== ownerId || $[30] !== selectedUsers) {
            t13 = selectedUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-2 mb-1",
                children: selectedUsers.map({
                    "ContributorSearch[selectedUsers.map()]": (u_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1.5 bg-bg-grey-light rounded-full px-2 py-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${u_0.id === ownerId ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `text-[9px] ${u_0.id === ownerId ? "text-text-primary" : "text-text-secondary"}`,
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(u_0.name)
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                        lineNumber: 115,
                                        columnNumber: 301
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 115,
                                    columnNumber: 156
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs text-text-primary",
                                    children: u_0.name
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 115,
                                    columnNumber: 436
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: {
                                        "ContributorSearch[selectedUsers.map() > <button>.onClick]": ()=>onRemove(u_0.id)
                                    }["ContributorSearch[selectedUsers.map() > <button>.onClick]"],
                                    className: "text-text-secondary hover:text-system-error text-xs ml-0.5",
                                    "aria-label": `Retirer ${u_0.name}`,
                                    children: "×"
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 115,
                                    columnNumber: 497
                                }, this)
                            ]
                        }, u_0.id, true, {
                            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                            lineNumber: 115,
                            columnNumber: 60
                        }, this)
                }["ContributorSearch[selectedUsers.map()]"])
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 114,
                columnNumber: 41
            }, this);
            $[28] = onRemove;
            $[29] = ownerId;
            $[30] = selectedUsers;
            $[31] = t13;
        } else {
            t13 = $[31];
        }
        t8 = "relative";
        let t16;
        if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
            t16 = ({
                "ContributorSearch[<button>.onClick]": ()=>setIsOpen(_ContributorSearchButtonOnClickSetIsOpen)
            })["ContributorSearch[<button>.onClick]"];
            $[32] = t16;
        } else {
            t16 = $[32];
        }
        let t17;
        if ($[33] !== buttonLabel) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-text-secondary",
                children: buttonLabel
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 138,
                columnNumber: 13
            }, this);
            $[33] = buttonLabel;
            $[34] = t17;
        } else {
            t17 = $[34];
        }
        const t18 = `h-6 w-6 text-btn-black transition-transform ${isOpen ? "rotate-180" : ""}`;
        let t19;
        if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
            t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M5 8l5 5 5-5"
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 147,
                columnNumber: 13
            }, this);
            $[35] = t19;
        } else {
            t19 = $[35];
        }
        let t20;
        if ($[36] !== t18) {
            t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: t18,
                viewBox: "0 0 20 20",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: 1.5,
                children: t19
            }, void 0, false, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 154,
                columnNumber: 13
            }, this);
            $[36] = t18;
            $[37] = t20;
        } else {
            t20 = $[37];
        }
        if ($[38] !== t17 || $[39] !== t20) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: t16,
                className: "w-full h-13.25 flex items-center justify-between border border-system-neutral rounded-[8px] px-4 py-3 text-sm bg-bg-content transition",
                children: [
                    t17,
                    t20
                ]
            }, void 0, true, {
                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                lineNumber: 161,
                columnNumber: 12
            }, this);
            $[38] = t17;
            $[39] = t20;
            $[40] = t9;
        } else {
            t9 = $[40];
        }
        t10 = isOpen && availableUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-full left-0 right-0 z-20 bg-bg-content border border-system-neutral rounded-[8px] shadow-modal mt-1 overflow-hidden max-h-48 overflow-y-auto",
            children: availableUsers.map({
                "ContributorSearch[availableUsers.map()]": (u_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: {
                            "ContributorSearch[availableUsers.map() > <button>.onClick]": ()=>handleAdd(u_1)
                        }["ContributorSearch[availableUsers.map() > <button>.onClick]"],
                        className: "w-full flex items-center gap-2 px-4 py-2 text-sm text-text-secondary hover:bg-bg-grey-light transition",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${u_1.id === ownerId ? "bg-brand-light" : "bg-bg-grey-border"}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `text-[9px] font-semibold ${u_1.id === ownerId ? "text-text-primary" : "text-text-secondary"}`,
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(u_1.name)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                    lineNumber: 171,
                                    columnNumber: 334
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                lineNumber: 171,
                                columnNumber: 189
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `px-2 py-0.5 rounded-full text-sm ${u_1.id === ownerId ? "bg-brand-light text-text-primary" : "bg-bg-grey-border text-text-secondary"}`,
                                children: u_1.name
                            }, void 0, false, {
                                fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                                lineNumber: 171,
                                columnNumber: 483
                            }, this)
                        ]
                    }, u_1.id, true, {
                        fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
                        lineNumber: 169,
                        columnNumber: 59
                    }, this)
            }["ContributorSearch[availableUsers.map()]"])
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
            lineNumber: 168,
            columnNumber: 50
        }, this);
        $[6] = allUsers;
        $[7] = buttonLabel;
        $[8] = excludeUserIds;
        $[9] = isOpen;
        $[10] = label;
        $[11] = onAdd;
        $[12] = onRemove;
        $[13] = ownerId;
        $[14] = selectedUsers;
        $[15] = t10;
        $[16] = t11;
        $[17] = t12;
        $[18] = t13;
        $[19] = t8;
        $[20] = t9;
    } else {
        t10 = $[15];
        t11 = $[16];
        t12 = $[17];
        t13 = $[18];
        t8 = $[19];
        t9 = $[20];
    }
    let t14;
    if ($[41] !== t10 || $[42] !== t8 || $[43] !== t9) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t8,
            children: [
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
            lineNumber: 198,
            columnNumber: 11
        }, this);
        $[41] = t10;
        $[42] = t8;
        $[43] = t9;
        $[44] = t14;
    } else {
        t14 = $[44];
    }
    let t15;
    if ($[45] !== t11 || $[46] !== t12 || $[47] !== t13 || $[48] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t11,
            children: [
                t12,
                t13,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/ui/ContributorSearch.tsx",
            lineNumber: 208,
            columnNumber: 11
        }, this);
        $[45] = t11;
        $[46] = t12;
        $[47] = t13;
        $[48] = t14;
        $[49] = t15;
    } else {
        t15 = $[49];
    }
    return t15;
}
_s(ContributorSearch, "0MGr9tRE1P5jAGVda6z1I3Fhqgc=");
_c = ContributorSearch;
function _ContributorSearchButtonOnClickSetIsOpen(v) {
    return !v;
}
var _c;
__turbopack_context__.k.register(_c, "ContributorSearch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/forms/ProjectForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$ContributorSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/ui/ContributorSearch.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/utils/initials.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ProjectForm(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(59);
    if ($[0] !== "2492284460de39344344b9fe362117072d989e282ac6370753fde79ef61e10c6") {
        for(let $i = 0; $i < 59; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2492284460de39344344b9fe362117072d989e282ac6370753fde79ef61e10c6";
    }
    const { initialName: t1, initialDescription: t2, initialMembers: t3, totalContributors, submitLabel, loading, error, onSubmit, onDelete, projectId, onAddContributor, onRemoveContributor, selectedContributors: t4, ownerId } = t0;
    const initialName = t1 === undefined ? "" : t1;
    const initialDescription = t2 === undefined ? "" : t2;
    const initialMembers = t3 === undefined ? [] : t3;
    let t5;
    if ($[1] !== t4) {
        t5 = t4 === undefined ? [] : t4;
        $[1] = t4;
        $[2] = t5;
    } else {
        t5 = $[2];
    }
    const selectedContributors = t5;
    const [name, setName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialName);
    const [description, setDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialDescription);
    let t6;
    if ($[3] !== description || $[4] !== name || $[5] !== onSubmit || $[6] !== selectedContributors) {
        t6 = async function handleSubmit(e) {
            e.preventDefault();
            const contributorEmails = selectedContributors.map(_ProjectFormHandleSubmitSelectedContributorsMap);
            await onSubmit(name, description, contributorEmails);
        };
        $[3] = description;
        $[4] = name;
        $[5] = onSubmit;
        $[6] = selectedContributors;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    const handleSubmit = t6;
    const excludeUserIds = initialMembers.map(_ProjectFormInitialMembersMap);
    let t7;
    if ($[8] !== ownerId) {
        t7 = ({
            "ProjectForm[initialMembers.find()]": (m_0)=>m_0.user.id === ownerId
        })["ProjectForm[initialMembers.find()]"];
        $[8] = ownerId;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    const ownerMember = initialMembers.find(t7);
    const ownerName = ownerMember?.user.name ?? "";
    const ownerInitials = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(ownerName);
    let t8;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            htmlFor: "project-name",
            className: "text-sm text-police-black",
            children: [
                "Titre ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    "aria-hidden": "true",
                    children: "*"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 97,
                    columnNumber: 84
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 97,
            columnNumber: 10
        }, this);
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] !== setName) {
        t9 = ({
            "ProjectForm[<input>.onChange]": (e_0)=>setName(e_0.target.value)
        })["ProjectForm[<input>.onChange]"];
        $[11] = setName;
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    let t10;
    if ($[13] !== name || $[14] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t8,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    id: "project-name",
                    type: "text",
                    value: name,
                    onChange: t9,
                    className: "h-13.25 px-4 py-2.5 text-sm text-police-black bg-bg-content transition",
                    placeholder: "Nom du projet",
                    required: true,
                    autoFocus: true
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 114,
                    columnNumber: 52
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 114,
            columnNumber: 11
        }, this);
        $[13] = name;
        $[14] = t9;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    let t11;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            htmlFor: "project-description",
            className: "text-sm text-text-primary",
            children: "Description"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 123,
            columnNumber: 11
        }, this);
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    let t12;
    if ($[17] !== setDescription) {
        t12 = ({
            "ProjectForm[<textarea>.onChange]": (e_1)=>setDescription(e_1.target.value)
        })["ProjectForm[<textarea>.onChange]"];
        $[17] = setDescription;
        $[18] = t12;
    } else {
        t12 = $[18];
    }
    let t13;
    if ($[19] !== description || $[20] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-1",
            children: [
                t11,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                    id: "project-description",
                    value: description,
                    onChange: t12,
                    className: "px-4 py-2.5 h-13.25 text-sm text-police-black bg-bg-content transition resize-none",
                    placeholder: "Description du projet"
                }, void 0, false, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 140,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 140,
            columnNumber: 11
        }, this);
        $[19] = description;
        $[20] = t12;
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    let t14;
    if ($[22] !== onRemoveContributor || $[23] !== ownerInitials || $[24] !== ownerMember || $[25] !== ownerName || $[26] !== selectedContributors || $[27] !== totalContributors) {
        t14 = onRemoveContributor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-sm font-medium text-text-primary",
                    children: [
                        "Contributeurs actuels (",
                        totalContributors,
                        ")"
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 149,
                    columnNumber: 71
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-wrap items-center gap-2",
                    children: [
                        ownerMember && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1 px-2.5 rounded-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-5 h-5 rounded-full flex items-center justify-center bg-brand-light",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[10px] font-semibold text-btn-black",
                                        children: ownerInitials
                                    }, void 0, false, {
                                        fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                        lineNumber: 149,
                                        columnNumber: 391
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                    lineNumber: 149,
                                    columnNumber: 305
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[10px] px-2 py-0.5 rounded-full bg-brand-light text-text-primary",
                                    children: ownerName
                                }, void 0, false, {
                                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                    lineNumber: 149,
                                    columnNumber: 478
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                            lineNumber: 149,
                            columnNumber: 244
                        }, this),
                        selectedContributors.map({
                            "ProjectForm[selectedContributors.map()]": (user)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-1 px-2.5 rounded-full",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-5 h-5 rounded-full flex items-center justify-center bg-bg-grey-border",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[10px] font-semibold text-text-secondary",
                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$utils$2f$initials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(user.name)
                                            }, void 0, false, {
                                                fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                                lineNumber: 150,
                                                columnNumber: 226
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                            lineNumber: 150,
                                            columnNumber: 137
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[10px] px-2 py-0.5 rounded-full bg-bg-grey-border text-text-secondary",
                                            children: user.name
                                        }, void 0, false, {
                                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                            lineNumber: 150,
                                            columnNumber: 327
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: {
                                                "ProjectForm[selectedContributors.map() > <button>.onClick]": ()=>onRemoveContributor(user.id)
                                            }["ProjectForm[selectedContributors.map() > <button>.onClick]"],
                                            className: "text-text-secondary mb-1 hover:text-brand-dark transition",
                                            "aria-label": `Retirer ${user.name}`,
                                            children: "×"
                                        }, void 0, false, {
                                            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                            lineNumber: 150,
                                            columnNumber: 438
                                        }, this)
                                    ]
                                }, user.id, true, {
                                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                                    lineNumber: 150,
                                    columnNumber: 62
                                }, this)
                        }["ProjectForm[selectedContributors.map()]"])
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
                    lineNumber: 149,
                    columnNumber: 177
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 149,
            columnNumber: 34
        }, this);
        $[22] = onRemoveContributor;
        $[23] = ownerInitials;
        $[24] = ownerMember;
        $[25] = ownerName;
        $[26] = selectedContributors;
        $[27] = totalContributors;
        $[28] = t14;
    } else {
        t14 = $[28];
    }
    let t15;
    if ($[29] !== excludeUserIds || $[30] !== onAddContributor || $[31] !== onRemoveContributor || $[32] !== ownerId || $[33] !== selectedContributors) {
        t15 = onAddContributor && onRemoveContributor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$ui$2f$ContributorSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            selectedUsers: selectedContributors,
            excludeUserIds: excludeUserIds,
            onAdd: onAddContributor,
            onRemove: onRemoveContributor,
            label: "Ajouter un contributeur",
            ownerId: ownerId,
            buttonLabel: selectedContributors.length > 0 ? `${selectedContributors.length} collaborateur${selectedContributors.length > 1 ? "s" : ""}` : "Choisir un ou plusieurs collaborateurs"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 166,
            columnNumber: 54
        }, this);
        $[29] = excludeUserIds;
        $[30] = onAddContributor;
        $[31] = onRemoveContributor;
        $[32] = ownerId;
        $[33] = selectedContributors;
        $[34] = t15;
    } else {
        t15 = $[34];
    }
    let t16;
    if ($[35] !== error) {
        t16 = error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            role: "alert",
            "aria-live": "assertive",
            className: "text-sm text-text-error",
            children: error
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 178,
            columnNumber: 20
        }, this);
        $[35] = error;
        $[36] = t16;
    } else {
        t16 = $[36];
    }
    let t17;
    if ($[37] !== loading || $[38] !== name) {
        t17 = loading || !name.trim();
        $[37] = loading;
        $[38] = name;
        $[39] = t17;
    } else {
        t17 = $[39];
    }
    const t18 = loading ? "En cours..." : submitLabel;
    let t19;
    if ($[40] !== t17 || $[41] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            disabled: t17,
            className: "w-46.25 h-12.5 py-2.5 bg-system-neutral text-text-neutral text-base rounded-[10px] hover:border border-brand-dark hover:text-brand-dark hover:bg-bg-content transition",
            children: t18
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 196,
            columnNumber: 11
        }, this);
        $[40] = t17;
        $[41] = t18;
        $[42] = t19;
    } else {
        t19 = $[42];
    }
    let t20;
    if ($[43] !== onDelete || $[44] !== projectId) {
        t20 = onDelete && projectId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            className: "text-text-error hover:text-red-700 text-sm",
            onClick: onDelete,
            children: "Supprimer le projet"
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 205,
            columnNumber: 36
        }, this);
        $[43] = onDelete;
        $[44] = projectId;
        $[45] = t20;
    } else {
        t20 = $[45];
    }
    let t21;
    if ($[46] !== t19 || $[47] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-row justify-between mt-4",
            children: [
                t19,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 214,
            columnNumber: 11
        }, this);
        $[46] = t19;
        $[47] = t20;
        $[48] = t21;
    } else {
        t21 = $[48];
    }
    let t22;
    if ($[49] !== t10 || $[50] !== t13 || $[51] !== t14 || $[52] !== t15 || $[53] !== t16 || $[54] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-113 mx-auto overflow-y-auto flex flex-col gap-4 pr-1",
            children: [
                t10,
                t13,
                t14,
                t15,
                t16,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 223,
            columnNumber: 11
        }, this);
        $[49] = t10;
        $[50] = t13;
        $[51] = t14;
        $[52] = t15;
        $[53] = t16;
        $[54] = t21;
        $[55] = t22;
    } else {
        t22 = $[55];
    }
    let t23;
    if ($[56] !== handleSubmit || $[57] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: handleSubmit,
            className: "flex flex-col gap-4",
            noValidate: true,
            children: t22
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/forms/ProjectForm.tsx",
            lineNumber: 236,
            columnNumber: 11
        }, this);
        $[56] = handleSubmit;
        $[57] = t22;
        $[58] = t23;
    } else {
        t23 = $[58];
    }
    return t23;
}
_s(ProjectForm, "p8e3PxGPGSdEGKqdDTcGONQjRj0=");
_c = ProjectForm;
function _ProjectFormInitialMembersMap(m) {
    return m.user.id;
}
function _ProjectFormHandleSubmitSelectedContributorsMap(c) {
    return c.email;
}
var _c;
__turbopack_context__.k.register(_c, "ProjectForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/components/modals/CreateProjectModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CreateProjectModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/BaseModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$ProjectForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/forms/ProjectForm.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function CreateProjectModal({ onClose, onSubmit }) {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedContributors, setSelectedContributors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    async function handleSubmit(name, description) {
        setError(null);
        setLoading(true);
        try {
            await onSubmit(name, description, selectedContributors);
            onClose();
        } catch (err) {
            if (err instanceof Error) setError(err.message);
            else setError("Une erreur est survenue");
        } finally{
            setLoading(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$BaseModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        id: "create-project-title",
        title: "Créer un projet",
        onClose: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$forms$2f$ProjectForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            submitLabel: "Créer",
            loading: loading,
            error: error,
            onSubmit: handleSubmit,
            // 🔹 Pas de membres initiaux lors de la création
            initialMembers: [],
            // 🔹 Aucun contributeur au début
            projectContributors: selectedContributors,
            // 🔹 Total = contributeurs sélectionnés + owner (owner sera ajouté après création)
            totalContributors: selectedContributors.length,
            // 🔹 Gestion des contributeurs
            selectedContributors: selectedContributors,
            onAddContributor: (user)=>setSelectedContributors((prev)=>[
                        ...prev,
                        user
                    ]),
            onRemoveContributor: (userId)=>setSelectedContributors((prev_0)=>prev_0.filter((u)=>u.id !== userId)),
            // 🔹 Pas de suppression de projet ici
            onDelete: ()=>{}
        }, void 0, false, {
            fileName: "[project]/frontend/src/components/modals/CreateProjectModal.tsx",
            lineNumber: 31,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/frontend/src/components/modals/CreateProjectModal.tsx",
        lineNumber: 30,
        columnNumber: 10
    }, this);
}
_s(CreateProjectModal, "bzuncdVN93XlwhF2yV41O5EILHA=");
_c = CreateProjectModal;
var _c;
__turbopack_context__.k.register(_c, "CreateProjectModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/lib/api/tasks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createComment",
    ()=>createComment,
    "createTask",
    ()=>createTask,
    "deleteTask",
    ()=>deleteTask,
    "updateTask",
    ()=>updateTask
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/client.ts [app-client] (ecmascript)");
;
async function createTask(projectId, title, description, dueDate, assigneeIds, status, priority) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks`, {
        method: "POST",
        body: {
            title,
            description,
            priority,
            dueDate: dueDate || null,
            assigneeIds
        }
    });
}
async function updateTask(projectId, taskId, data) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks/${taskId}`, {
        method: "PATCH",
        body: {
            ...data,
            dueDate: data.dueDate || null
        }
    });
}
async function deleteTask(projectId, taskId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks/${taskId}`, {
        method: "DELETE"
    });
}
async function createComment(projectId, taskId, content) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiRequest"])(`/projects/${projectId}/tasks/${taskId}/comments`, {
        method: "POST",
        body: {
            content
        }
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/src/app/dashboard/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DashboardPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useAuth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useDashboard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useDashboard.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useModal.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/hooks/useProjects.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$dashboard$2f$DashboardHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/dashboard/DashboardHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$dashboard$2f$TasksSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/dashboard/TasksSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$CreateProjectModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/components/modals/CreateProjectModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$tasks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/src/lib/api/tasks.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
function DashboardPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(28);
    if ($[0] !== "df6f472c6a3f58a5c0ca2173f2d1fc33f41e1a1506505ca70a635b5db7da0a06") {
        for(let $i = 0; $i < 28; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "df6f472c6a3f58a5c0ca2173f2d1fc33f41e1a1506505ca70a635b5db7da0a06";
    }
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const { tasks, projects, loading, error, updateTaskStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useDashboard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDashboard"])();
    const { createProject, fetchProjects } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjects"])();
    const { isOpen, openModal, closeModal } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModal"])();
    const [view, setView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("list");
    let t0;
    if ($[1] !== tasks) {
        t0 = async function handleUpdateTask(taskId, data) {
            const task = tasks.find({
                "DashboardPage[handleUpdateTask > tasks.find()]": (t)=>t.id === taskId
            }["DashboardPage[handleUpdateTask > tasks.find()]"]);
            if (!task) {
                return;
            }
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$lib$2f$api$2f$tasks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateTask"])(task.projectId, taskId, data);
        };
        $[1] = tasks;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const handleUpdateTask = t0;
    let t1;
    if ($[3] !== createProject || $[4] !== fetchProjects) {
        t1 = async function handleCreateProject(name, description, contributors) {
            const contributorEmails = contributors.map(_DashboardPageHandleCreateProjectContributorsMap);
            const projectId = await createProject(name, description, contributorEmails);
            if (!projectId) {
                return;
            }
            await fetchProjects();
        };
        $[3] = createProject;
        $[4] = fetchProjects;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    const handleCreateProject = t1;
    const t2 = user?.name ?? "";
    let t3;
    if ($[6] !== openModal) {
        t3 = ({
            "DashboardPage[<DashboardHeader>.onCreateProject]": ()=>openModal("createProject")
        })["DashboardPage[<DashboardHeader>.onCreateProject]"];
        $[6] = openModal;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    let t4;
    if ($[8] !== t2 || $[9] !== t3 || $[10] !== view) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$dashboard$2f$DashboardHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            name: t2,
            view: view,
            onCreateProject: t3,
            onViewChange: setView
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/page.tsx",
            lineNumber: 89,
            columnNumber: 10
        }, this);
        $[8] = t2;
        $[9] = t3;
        $[10] = view;
        $[11] = t4;
    } else {
        t4 = $[11];
    }
    let t5;
    if ($[12] !== error || $[13] !== handleUpdateTask || $[14] !== loading || $[15] !== projects || $[16] !== tasks || $[17] !== updateTaskStatus || $[18] !== view) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$dashboard$2f$TasksSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            tasks: tasks,
            projects: projects,
            loading: loading,
            error: error,
            view: view,
            onUpdateTaskStatus: updateTaskStatus,
            updateTask: handleUpdateTask
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/page.tsx",
            lineNumber: 99,
            columnNumber: 10
        }, this);
        $[12] = error;
        $[13] = handleUpdateTask;
        $[14] = loading;
        $[15] = projects;
        $[16] = tasks;
        $[17] = updateTaskStatus;
        $[18] = view;
        $[19] = t5;
    } else {
        t5 = $[19];
    }
    let t6;
    if ($[20] !== closeModal || $[21] !== handleCreateProject || $[22] !== isOpen) {
        t6 = isOpen("createProject") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$components$2f$modals$2f$CreateProjectModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClose: closeModal,
            onSubmit: handleCreateProject
        }, void 0, false, {
            fileName: "[project]/frontend/src/app/dashboard/page.tsx",
            lineNumber: 113,
            columnNumber: 37
        }, this);
        $[20] = closeModal;
        $[21] = handleCreateProject;
        $[22] = isOpen;
        $[23] = t6;
    } else {
        t6 = $[23];
    }
    let t7;
    if ($[24] !== t4 || $[25] !== t5 || $[26] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col",
            children: [
                t4,
                t5,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/src/app/dashboard/page.tsx",
            lineNumber: 123,
            columnNumber: 10
        }, this);
        $[24] = t4;
        $[25] = t5;
        $[26] = t6;
        $[27] = t7;
    } else {
        t7 = $[27];
    }
    return t7;
}
_s(DashboardPage, "DeXYS9N3RUpYvXOpj7iVisiayGE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useDashboard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDashboard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjects"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$src$2f$hooks$2f$useModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModal"]
    ];
});
_c = DashboardPage;
function _DashboardPageHandleCreateProjectContributorsMap(u) {
    return u.email;
}
var _c;
__turbopack_context__.k.register(_c, "DashboardPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=frontend_src_979e3847._.js.map