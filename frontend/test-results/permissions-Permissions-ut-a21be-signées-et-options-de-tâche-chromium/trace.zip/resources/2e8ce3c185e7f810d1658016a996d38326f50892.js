(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/9e883_next_e96ace8c._.js",
  "static/chunks/frontend_src_66712c34._.js"
],
    source: "dynamic"
});
