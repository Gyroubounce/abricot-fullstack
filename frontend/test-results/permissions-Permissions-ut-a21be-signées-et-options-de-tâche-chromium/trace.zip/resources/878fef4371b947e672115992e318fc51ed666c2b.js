(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/frontend_src_8880fb54._.js",
  "static/chunks/9e883_@heroicons_react_24_outline_esm_XMarkIcon_1ebb15a0.js"
],
    source: "dynamic"
});
